# Generator aset Nara (orisinal, prosedural). Jalankan: python3 make_sprites.py
# Menghasilkan: sprites/<pose>_<n>.png (tubuh 400x800), sprites/faces/<frame>_<emosi>_<mulut>.png (tambalan wajah),
# sprites/faces.json (posisi tambalan), cursor.png, ikon.
import math, os, json
from PIL import Image, ImageDraw
import numpy as np

W, H, S = 400, 800, 3
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main")
OUT = os.path.join(BASE, "assets", "sprites"); FACES = os.path.join(OUT, "faces")
os.makedirs(FACES, exist_ok=True)

SKIN=(222,178,156); SKIN_S=(176,128,116); SKIN_H=(238,200,180)
JACK=(40,44,62); JACK_S=(24,26,38); TRIM=(70,212,224)
LEG=(30,32,52); LEG_S=(18,19,32); BOOT=(16,16,22)
HAIR=(70,44,130); HAIR_S=(38,24,80); HAIR_H=(150,104,230); STREAK=(64,206,220)
INK=(24,20,32); LIP=(150,70,84); MOUTH_IN=(96,30,48); BLUSH=(235,110,130)

RNG_NOISE = np.random.default_rng(3).integers(-9, 10, size=(H, W))   # grain tetap: tambalan = tubuh persis

class Canvas:
    """Kanvas dengan region (x0,y0,w,h) dalam koordinat dasar 400x800, supersample S."""
    def __init__(self, region=(0, 0, W, H)):
        self.ox, self.oy, self.w, self.h = region
        self.im = Image.new("RGBA", (self.w*S, self.h*S), (0,0,0,0)); self.d = ImageDraw.Draw(self.im)
    def _p(self, x, y): return ((x-self.ox)*S, (y-self.oy)*S)
    def poly(self, pts, fill): self.d.polygon([self._p(x,y) for x,y in pts], fill=fill)
    def blend(self, pts, rgba):
        lay = Image.new("RGBA", self.im.size, (0,0,0,0)); ImageDraw.Draw(lay).polygon([self._p(x,y) for x,y in pts], fill=rgba)
        self.im = Image.alpha_composite(self.im, lay); self.d = ImageDraw.Draw(self.im)
    def circ(self, c, r, fill):
        x,y = self._p(*c); self.d.ellipse([x-r*S,y-r*S,x+r*S,y+r*S], fill=fill)
    def ell(self, c, rx, ry, fill):
        x,y = self._p(*c); self.d.ellipse([x-rx*S,y-ry*S,x+rx*S,y+ry*S], fill=fill)
    def line(self, a, b, w, fill): self.d.line([self._p(*a), self._p(*b)], fill=fill, width=max(1,int(w*S)))
    def limb(self, p0, p1, w0, w1, col, shade):
        dx, dy = p1[0]-p0[0], p1[1]-p0[1]; L = math.hypot(dx, dy) or 1
        nx, ny = -dy/L, dx/L
        a=(p0[0]+nx*w0, p0[1]+ny*w0); b=(p1[0]+nx*w1, p1[1]+ny*w1)
        c=(p1[0]-nx*w1, p1[1]-ny*w1); d=(p0[0]-nx*w0, p0[1]-ny*w0)
        self.poly([a,b,c,d], col); self.poly([p0,p1,c,d], shade)
        self.circ(p0, w0, col); self.circ(p1, w1, shade if col!=SKIN else col)
    def finish(self, margin=0):
        im = self.im.resize((self.w, self.h), Image.LANCZOS)
        a = np.array(im).astype(np.int16)
        n = RNG_NOISE[self.oy:self.oy+self.h, self.ox:self.ox+self.w][..., None]
        a[..., :3] = np.clip(a[..., :3] + n, 0, 255)
        return Image.fromarray(a.astype(np.uint8), "RGBA")

def end(p, a, l): return (p[0]+math.sin(math.radians(a))*l, p[1]+math.cos(math.radians(a))*l)

# ------------------------------------------------------------------ wajah & ekspresi
def eye(c, ex, ey, side, kind, look=0.0):
    """kind: open, wide, narrow, half, closed, happy, sad, angry"""
    if kind == "closed":
        c.line((ex-9,ey),(ex,ey+3),1.8,INK); c.line((ex,ey+3),(ex+9,ey),1.8,INK); return
    if kind == "happy":
        c.line((ex-8,ey+2),(ex,ey-4),2.0,INK); c.line((ex,ey-4),(ex+8,ey+2),2.0,INK); return
    hh = {"open":5, "wide":7.5, "narrow":3, "half":3.2, "sad":4.4, "angry":3.6}[kind]
    c.poly([(ex-9,ey),(ex,ey-hh),(ex+9,ey-hh*0.2),(ex+1,ey+hh*0.8)], (245,245,250))
    ir = 4.4 if kind != "wide" else 3.6
    ix = ex + look; iy = ey - 0.4 + (1.0 if kind in ("sad","half") else 0)
    c.circ((ix,iy), ir, (40,170,190)); c.circ((ix,iy), ir*0.46, (10,14,24)); c.circ((ix-1.2,iy-1.4), 0.9, (255,255,255))
    if kind == "half": c.poly([(ex-10,ey-hh-2),(ex+10,ey-hh-2),(ex+10,ey-0.6),(ex-10,ey-0.6)], SKIN)   # kelopak turun
    top = (ex-10, ey-1) , (ex, ey-hh-1), (ex+10, ey-2)
    c.line(top[0], top[1], 1.6, INK); c.line(top[1], top[2], 1.6, INK)
    if kind == "sad":
        c.circ((ex+side*7, ey+9), 1.6, (150,220,235)); c.circ((ex+side*7, ey+12.5), 1.1, (170,230,240))   # air mata

def brow(c, ex, ey, side, kind, raise_=0):
    y = ey-11-raise_
    pts = {
      "flat":  ((ex-10,y-side*0.6),(ex+10,y+side*0.6)),
      "up":    ((ex-10,y-1),(ex+10,y-2)),
      "sad":   ((ex-side*(-10),y+3),(ex+side*(-10),y-3)),     # sisi dalam naik
      "angry": ((ex+side*(-10),y-3),(ex-side*(-10),y+3)),     # sisi dalam turun
      "high":  ((ex-10,y-5),(ex+10,y-6)),
      "low":   ((ex-10,y+2),(ex+10,y+2)),
    }[kind]
    if kind in ("sad","angry"):
        a=(ex-10*side*-1,0)
    # sisi dalam = sisi yang menghadap hidung (x lebih dekat ke tengah)
    inner = ex - side*10; outer = ex + side*10
    if kind == "sad":   p0=(outer,y+2); p1=(inner,y-3)
    elif kind == "angry": p0=(outer,y-2); p1=(inner,y+3)
    elif kind == "high": p0=(outer,y-5); p1=(inner,y-5)
    elif kind == "low": p0=(outer,y+2); p1=(inner,y+2)
    elif kind == "up": p0=(outer,y-1); p1=(inner,y-3)
    else: p0=(outer,y); p1=(inner,y)
    c.line(p0, p1, 1.9, HAIR_S)

def mouth_shape(c, hc, emo, m):
    my = hc[1]+29; x = hc[0]
    if m == 0:
        if emo == "happy":
            c.poly([(x-9,my-2),(x+9,my-2),(x+6,my+4),(x,my+6),(x-6,my+4)], MOUTH_IN); c.line((x-9,my-2),(x+9,my-2),1.4,LIP)
        elif emo == "sad": c.line((x-7,my+2),(x,my-1),1.8,LIP); c.line((x,my-1),(x+7,my+2),1.8,LIP)
        elif emo == "angry": c.line((x-7,my+1),(x,my-1),1.9,LIP); c.line((x,my-1),(x+7,my+1),1.9,LIP)
        elif emo == "surprised": c.ell((x,my+1), 4, 5, MOUTH_IN)
        elif emo == "sleepy": c.line((x-4,my),(x+4,my),1.6,LIP)
        elif emo == "curious": c.line((x-7,my+1),(x+3,my),1.8,LIP); c.line((x+3,my),(x+8,my-3),1.8,LIP)
        elif emo == "shy": 
            for i in range(-2,2): c.line((x+i*4,my+(1 if i%2 else -1)),(x+i*4+4,my+(-1 if i%2 else 1)),1.6,LIP)
        else: c.line((x-8,my),(x+8,my-1),2.0,LIP)
    else:
        h = 3 + m*3
        if emo == "happy": c.poly([(x-9,my-2),(x+9,my-2),(x+6,my+h+2),(x,my+h+4),(x-6,my+h+2)], MOUTH_IN)
        elif emo == "surprised": c.ell((x,my+2), 4+m, 4+m*1.5, MOUTH_IN)
        elif emo == "angry": c.poly([(x-9,my-1),(x+9,my-1),(x+7,my+h),(x-7,my+h)], MOUTH_IN); c.line((x-8,my-1),(x+8,my-1),1.6,(235,235,240))
        elif emo == "sad": c.poly([(x-6,my+1),(x,my-1),(x+6,my+1),(x,my+h-1)], MOUTH_IN)
        else: c.poly([(x-8,my-1),(x,my-2),(x+8,my-1),(x,my+h)], MOUTH_IN)

EMO = {  # emosi -> (mata, alis, tatapan, blush, kemiringan)
 "neutral":  ("open",  "flat",  0.0, 0.0),
 "happy":    ("happy", "up",    0.0, 0.35),
 "sad":      ("sad",   "sad",   0.0, 0.0),
 "angry":    ("angry", "angry", 0.0, 0.0),
 "surprised":("wide",  "high",  0.0, 0.0),
 "sleepy":   ("half",  "low",   0.0, 0.0),
 "curious":  ("open",  "flat",  1.6, 0.0),
 "shy":      ("open",  "sad",  -2.2, 0.8),
}

def draw_face(c, hc, emo, mouth, blink=False):
    e_kind, b_kind, look, blush = EMO[emo]
    if blink and e_kind not in ("happy","half"): e_kind = "closed"
    for side in (-1, 1):
        ex = hc[0]+side*13; ey = hc[1]+2
        eye(c, ex, ey, side, e_kind, look*(1 if side else 1))
        k = b_kind
        if emo == "curious": k = "high" if side == 1 else "flat"
        brow(c, ex, ey, side, k)
    c.line((hc[0]+2,hc[1]+8),(hc[0]+5,hc[1]+19),1.2,SKIN_S); c.line((hc[0]+5,hc[1]+19),(hc[0]-1,hc[1]+20),1.2,SKIN_S)
    if blush > 0:
        for side in (-1,1):
            cx = hc[0]+side*19; cy = hc[1]+16
            c.blend([(cx-9,cy-3),(cx+9,cy-3),(cx+7,cy+5),(cx-7,cy+5)], BLUSH+(int(200*blush),))
    mouth_shape(c, hc, emo, mouth)

# ------------------------------------------------------------------ tubuh
def hc_of(pose):
    lean = pose.get("lean",0); dy = pose.get("down",0)
    return (200 + lean*(max(0,380-100)/380.0), 100 + dy)

def draw(pose, region=(0,0,W,H), face=None):
    """face=None: wajah netral bawaan pose. face=(emo,mouth,blink): hanya dipakai untuk tambalan."""
    c = Canvas(region); cx = 200
    dy = pose.get("down", 0); lean = pose.get("lean", 0); hs = pose.get("hair", 0)
    P = lambda x, y: (x + lean*(max(0, 380-y)/380.0), y + dy)
    back = [P(cx-46,60),P(cx-70,120),P(cx-84+hs,230),P(cx-66+hs,300),P(cx-78+hs*1.4,372),P(cx-44+hs,330),
            P(cx-30,380),P(cx,330),P(cx+30,396),P(cx+44-hs,330),P(cx+80-hs*1.4,368),P(cx+66-hs,296),
            P(cx+84-hs,226),P(cx+70,118),P(cx+46,60),P(cx,30)]
    c.poly(back, HAIR_S)
    c.poly([P(cx-40,70),P(cx-62,150),P(cx-70+hs,250),P(cx-30,200)], HAIR)
    legs = pose.get("legs", ((0,0),(0,0))); foot_lift = pose.get("lift", (0,0))
    for side, (th, sh), lift in ((-1, legs[0], foot_lift[0]), (1, legs[1], foot_lift[1])):
        hip = P(cx+side*21, 352)
        knee = end(hip, side*5+th, 180*pose.get("thigh_len", 1.0))
        ank  = end(knee, side*4+sh, 168*pose.get("shin_len", 1.0)); ank = (ank[0], ank[1]-lift)
        c.limb(hip, knee, 24, 17, LEG, LEG_S); c.limb(knee, ank, 17, 11, LEG, LEG_S)
        foot = (ank[0]+side*14, ank[1]+22)
        c.poly([(ank[0]-13,ank[1]-8),(ank[0]+13,ank[1]-8),(foot[0]+side*20,foot[1]+2),(ank[0]-side*16,foot[1]+2)], BOOT)
        c.line((ank[0]-side*16,foot[1]),(foot[0]+side*20,foot[1]),2.5,TRIM)
        c.line((knee[0]-6,knee[1]-2),(knee[0]+6,knee[1]+2),1.2,(60,70,110))
    tor = [P(cx-46,176),P(cx+46,176),P(cx+36,290),P(cx+48,356),P(cx-48,356),P(cx-36,290)]
    c.poly(tor, JACK)
    c.poly([P(cx,176),P(cx+46,176),P(cx+36,290),P(cx+48,356),P(cx,356)], JACK_S)
    c.poly([P(cx-6,176),P(cx+6,176),P(cx+4,356),P(cx-4,356)], TRIM)
    c.poly([P(cx-48,340),P(cx+48,340),P(cx+54,366),P(cx-54,366)], LEG_S)
    c.poly([P(cx-46,176),P(cx-20,176),P(cx-30,214)], (58,64,90)); c.poly([P(cx+46,176),P(cx+20,176),P(cx+30,214)], (30,33,48))
    c.limb(P(cx,140), P(cx,180), 11, 13, SKIN, SKIN_S)
    arms = pose.get("arms", ((0,0),(0,0)))
    for side, (up, fo) in ((-1, arms[0]), (1, arms[1])):
        sh = P(cx+side*48, 184); el = end(sh, side*10+up, 128); wr = end(el, side*6+fo, 118)
        c.limb(sh, el, 15, 11, JACK, JACK_S); c.limb(el, wr, 11, 8, JACK, JACK_S)
        c.line((el[0]-9,el[1]),(el[0]+9,el[1]),2,TRIM)
        hand = end(wr, side*6+fo, 26); c.limb(wr, hand, 8, 6, SKIN, SKIN_S)
        for k in (-1,0,1): c.line(hand, end(hand, side*6+fo+k*14, 16), 2.4, SKIN)
    hc = P(cx, 100)
    c.poly([(hc[0]-28,hc[1]-30),(hc[0]+28,hc[1]-30),(hc[0]+30,hc[1]+4),(hc[0]+17,hc[1]+34),(hc[0],hc[1]+42),(hc[0]-17,hc[1]+34),(hc[0]-30,hc[1]+4)], SKIN)
    c.poly([(hc[0],hc[1]-30),(hc[0]+28,hc[1]-30),(hc[0]+30,hc[1]+4),(hc[0]+17,hc[1]+34),(hc[0],hc[1]+42)], SKIN_S)
    c.poly([(hc[0]-26,hc[1]-6),(hc[0]-4,hc[1]-8),(hc[0]-12,hc[1]+14)], SKIN_H)
    if face is None:
        draw_face(c, hc, "neutral" , pose.get("mouth",0), blink=(pose.get("eyes",1)==0))
    else:
        draw_face(c, hc, face[0], face[1], face[2])
    c.poly([(hc[0]-34,hc[1]-8),(hc[0]-32,hc[1]-40),(hc[0],hc[1]-52),(hc[0]+34,hc[1]-40),(hc[0]+32,hc[1]-6),
            (hc[0]+20,hc[1]-24),(hc[0]+6,hc[1]-14),(hc[0]-10,hc[1]-30),(hc[0]-24,hc[1]-6)], HAIR)
    c.poly([(hc[0]-34,hc[1]-8),(hc[0]-46+hs,hc[1]+60),(hc[0]-26,hc[1]+14),(hc[0]-30,hc[1]-4)], HAIR_S)
    c.poly([(hc[0]+32,hc[1]-6),(hc[0]+44-hs,hc[1]+70),(hc[0]+24,hc[1]+10)], HAIR_S)
    c.poly([(hc[0]-6,hc[1]-50),(hc[0]+18,hc[1]-34),(hc[0]+8,hc[1]-12),(hc[0]-2,hc[1]-30)], HAIR_H)
    c.poly([(hc[0]-26,hc[1]-30),(hc[0]-20,hc[1]-8),(hc[0]-30,hc[1]+30),(hc[0]-34,hc[1]-6)], STREAK)
    return c.finish()

poses = {}
poses["idle_0"] = dict(arms=((-2,-4),(2,4)), legs=((0,0),(0,0)))
poses["idle_1"] = dict(arms=((-4,-8),(4,8)), legs=((0,0),(0,0)), hair=5, down=1)
poses["talk_0"] = dict(arms=((-4,-10),(4,10)), legs=((0,0),(0,0)), mouth=1)
poses["talk_1"] = dict(arms=((-6,-16),(6,16)), legs=((0,0),(0,0)), mouth=2, hair=3)
for i,(al,ar,ll,lr) in enumerate([(( 14, 0),(-14,-8),( 6, 4),(-6,-4)), ((0,0),(0,0),(0,0),(0,0)),
                                  ((-14,-8),( 14, 0),(-6,-4),( 6, 4)), ((0,0),(0,0),(0,0),(0,0))]):
    lift = (14,0) if i==0 else ((0,14) if i==2 else (0,0))
    poses[f"walk_{i}"] = dict(arms=(al,ar), legs=(ll,lr), lift=lift, lean=8, hair=(8 if i==0 else (-8 if i==2 else 0)), down=(3 if i in (0,2) else 0))
poses["wave_0"] = dict(arms=((-2,-4),(122,146)), legs=((0,0),(0,0)), mouth=1)
poses["wave_1"] = dict(arms=((-2,-4),(130,112)), legs=((0,0),(0,0)), mouth=1)
poses["wave_2"] = dict(arms=((-2,-4),(122,170)), legs=((0,0),(0,0)))
poses["touch_0"] = dict(arms=((-2,-4),(110,100)), legs=((0,0),(0,0)), lean=6)
poses["touch_1"] = dict(arms=((-2,-4),(118,104)), legs=((0,0),(0,0)), lean=8, mouth=1)
poses["sit_0"] = dict(arms=((-8,-14),(8,14)), legs=((-30,34),(30,-34)), thigh_len=0.5, shin_len=0.75, down=190)
poses["sit_1"] = dict(arms=((-8,-14),(8,14)), legs=((-30,34),(30,-34)), thigh_len=0.5, shin_len=0.75, down=190, mouth=1)
poses["blink_0"] = dict(arms=((-2,-4),(2,4)), legs=((0,0),(0,0)), eyes=0)
poses["sleep_0"] = dict(arms=((-6,-10),(6,10)), legs=((0,2),(0,-2)), eyes=0)

for name, p in poses.items():
    im = draw(p)
    if name.startswith("sleep"):
        im = im.rotate(90, expand=True).crop((0, 0, 800, 400))
    im.save(os.path.join(OUT, name + ".png"))

# ------------------------------------------------------------------ tambalan wajah
PW, PH, PX, PY, MARGIN = 72, 104, 36, 56, 8
manifest = {"w": PW, "h": PH, "frames": {}}
frames = [k for k in poses if not k.startswith(("sleep","blink"))]
n = 0
for name in frames:
    hc = hc_of(poses[name]); x0 = int(round(hc[0]))-PX; y0 = int(round(hc[1]))-PY
    manifest["frames"][name] = [x0, y0]
    reg = (x0-MARGIN, y0-MARGIN, PW+2*MARGIN, PH+2*MARGIN)
    def patch(emo, mouth, blink, fn):
        global n
        im = draw(poses[name], reg, (emo, mouth, blink)).crop((MARGIN, MARGIN, MARGIN+PW, MARGIN+PH))
        im.save(os.path.join(FACES, fn)); n += 1
    for emo in EMO:
        for m in (0,1,2): patch(emo, m, False, f"{name}_{emo}_{m}.png")
    patch("neutral", 0, True, f"{name}_blink.png")
json.dump(manifest, open(os.path.join(OUT, "faces.json"), "w"))

# ikon & kursor
face = draw(poses["idle_0"]).crop((120, 20, 280, 180)).resize((192,192), Image.LANCZOS)
bg = Image.new("RGBA",(192,192),(20,22,40,255)); bg.alpha_composite(face)
d = os.path.join(BASE, "res", "mipmap-xxhdpi"); os.makedirs(d, exist_ok=True)
bg.resize((144,144), Image.LANCZOS).save(os.path.join(d, "ic_launcher.png"))
cur = Image.new("RGBA",(96,96),(0,0,0,0)); dd = ImageDraw.Draw(cur)
for r,al in ((46,40),(36,90),(26,170)): dd.ellipse([48-r,48-r,48+r,48+r], outline=(70,212,224,al), width=4)
dd.ellipse([40,40,56,56], fill=(235,250,255,255)); cur.save(os.path.join(OUT, "cursor.png"))
print("bodies", len(poses), "patches", n)
