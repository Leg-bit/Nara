# Memotong sprite sheet (tools/sheet.png) menjadi frame per-baris untuk app.
# Jalankan: python3 slice_sheet.py
import os, glob
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "app", "src", "main", "assets", "sprites")
os.makedirs(OUT, exist_ok=True)
for f in glob.glob(os.path.join(OUT, "*_*.png")): os.remove(f)
for f in glob.glob(os.path.join(OUT, "faces*")):
    if os.path.isdir(f):
        for g in glob.glob(os.path.join(f, "*")): os.remove(g)
        os.rmdir(f)
    else: os.remove(f)

ROWS = [("idle", 8), ("sit", 8), ("walk", 9), ("run", 9), ("happy", 8), ("annoyed", 8)]
LABEL_X = 155      # kiri = panel label, dilewati
UP = 2             # perbesar 2x (Lanczos) supaya tidak terlalu buram di layar HP

sheet = Image.open(os.path.join(HERE, "sheet.png")).convert("RGBA")
A = np.array(sheet)[..., 3] > 20
H, W = A.shape

def runs(mask1d, offset, min_len=1):
    out, s = [], None
    for i, v in enumerate(mask1d):
        if v and s is None: s = i
        if not v and s is not None:
            if i - s >= min_len: out.append((s + offset, i + offset))
            s = None
    if s is not None: out.append((s + offset, len(mask1d) + offset))
    return out

bands = runs(A[:, LABEL_X:].any(axis=1), 0, 40)
assert len(bands) == len(ROWS), bands
frames = {}
for (name, n), (y0, y1) in zip(ROWS, bands):
    segs = runs(A[y0:y1, LABEL_X:].any(axis=0), LABEL_X, 20)[:n]
    assert len(segs) == n, (name, len(segs))
    lst = []
    for x0, x1 in segs:
        crop = sheet.crop((x0, y0, x1, y1))
        al = np.array(crop)[..., 3].astype(float)
        cx = (al.sum(axis=0) * np.arange(al.shape[1])).sum() / max(al.sum(), 1)
        lst.append((crop, cx))
    frames[name] = (lst, y1 - y0)

half = max(max(cx, c.width - cx) for lst, _ in frames.values() for c, cx in lst)
CW = int(2 * half) + 6
for name, (lst, hgt) in frames.items():
    for i, (crop, cx) in enumerate(lst):
        cell = Image.new("RGBA", (CW, hgt + 2), (0, 0, 0, 0))
        cell.alpha_composite(crop, (int(round(CW / 2 - cx)), 0))
        cell = cell.resize((cell.width * UP, cell.height * UP), Image.LANCZOS)
        cell.save(os.path.join(OUT, f"{name}_{i}.png"))
print("cell width", CW * UP, {k: v[1] * UP for k, v in frames.items()})

# ikon launcher dari kepala frame idle
idle0 = Image.open(os.path.join(OUT, "idle_0.png"))
bb = idle0.getbbox(); head = idle0.crop((bb[0], bb[1], bb[2], bb[1] + (bb[3] - bb[1]) // 2))
s = max(head.size); bg = Image.new("RGBA", (s + 40, s + 40), (20, 22, 40, 255))
bg.alpha_composite(head, ((bg.width - head.width) // 2, 20))
d = os.path.join(HERE, "..", "app", "src", "main", "res", "mipmap-xxhdpi"); os.makedirs(d, exist_ok=True)
bg.resize((144, 144), Image.LANCZOS).save(os.path.join(d, "ic_launcher.png"))
