# Nara — teman humanoid di layar Android

Nara = karakter perempuan (tinggi ±38% layar, bisa diatur) yang berjalan di atas semua aplikasi,
membaca layar, belajar dari caramu memakai HP, dan bertindak atas kehendaknya sendiri.
Semua data & belajar terjadi **di HP**, tanpa internet.

## Cara mendapatkan APK (tanpa Android Studio)
1. Buat repo baru di github.com, lalu upload SEMUA isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** → tunggu hijau (±5–8 menit). Kalau tidak jalan sendiri, klik *Run workflow*.
3. Buka run yang selesai → bagian **Artifacts** → unduh **Nara-APK** → ekstrak → install `app-debug.apk`.
   (Izinkan "Instal dari sumber tidak dikenal".)
Kalau build merah, salin teks error-nya ke Claude, nanti diperbaiki.

## Setup di HP
1. Buka Nara → **Izinkan tampil di atas aplikasi lain**.
2. **Aktifkan Akses Layar** → Aksesibilitas → Nara → ON.
3. (Opsional) **Izinkan melihat gambar layar** — hanya 4 angka ringkasan yang dipakai, gambar tidak disimpan. Perlu diulang tiap HP restart.
4. **Mulai Nara**. Redmi/MIUI: izinkan "pop-up di latar", "Mulai otomatis", dan baterai "Tanpa batasan".

## Cara Nara belajar
| Bagian | Apa | Belajar dari |
|---|---|---|
| Memori | file di HP: fakta, kejadian app, pasangan percakapan | obrolan, app yang kamu buka |
| NN keputusan (MLP) | prediksi aksi: tap / scroll atas-bawah / back | tiruan perilakumu (imitation learning) |
| NN perilaku (MLP) | jalan / duduk / tidur / lambaikan / ngomong | ketuk Nara = 👍, ketuk 2x = 👎 |
| Mini ML | Naive Bayes topik layar, regresi logistik "tombol mana yang biasa kamu sentuh", kebiasaan jam-app | layar & sentuhanmu |
| Mini LLM | model bahasa trigram yang dilatih di HP (ID+EN) | teks layar, obrolan, ketikanmu (bisa dimatikan) |
| Dorongan | energi, bosan, penasaran → memicu tidur, jalan-jalan, bertanya kata baru | waktu & isi layar |

Kendali: ketuk = 👍 · ketuk 2x = 👎 · tekan lama = obrolan · geser = pindah · notifikasi: Jeda / Stop.
Teach manual di chat: `namaku Budi`, `ingat bahwa aku suka kopi`, `kalau aku bilang ping jawab pong`.

## Batas keamanan bawaan
- Nara tidak pernah membaca kolom sandi, dan tidak membaca/menyentuh app bank, dompet digital, OTP, pengaturan, installer (daftar bisa ditambah di app).
- Tidak menyentuh tombol bertuliskan bayar/kirim/hapus/beli/izinkan/OK/setuju dll.
- Tap otomatis baru aktif setelah ≥20 contoh sentuhanmu dipelajari; Back setelah ≥200 langkah belajar.
- Tidak bertindak 8 detik setelah kamu menyentuh layar, atau saat layar terkunci/mati.
- Kalau kamu pindah app sesaat setelah Nara menyentuh layar, itu dihitung sebagai hukuman.

## Struktur
`app/src/main/java/com/nara/companion/brain/` = otak (Kotlin murni, sudah diuji di JVM) ·
`OverlayService` = tubuh/animasi · `ScreenAccessService` = mata & tangan · `CaptureService` = penglihatan opsional ·
`assets/sprites` = aset karakter (dibuat oleh `tools/make_sprites.py`; bisa diganti PNG sendiri dengan nama sama).
