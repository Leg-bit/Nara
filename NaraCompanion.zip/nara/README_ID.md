# Nara — teman humanoid di layar Android

Nara = karakter chibi bergaya neon (tinggi ±24% layar, bisa diatur) yang berjalan di atas semua aplikasi,
membaca layar, belajar dari caramu memakai HP, dan bertindak atas kehendaknya sendiri.
Semua data & belajar terjadi **di HP**, tanpa internet.

## Cara mendapatkan APK (tanpa Android Studio)
1. Buat repo baru di github.com, lalu upload SEMUA isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** → tunggu hijau (±5–8 menit). Kalau tidak jalan sendiri, klik *Run workflow*.
3. Buka run yang selesai → bagian **Artifacts** → unduh **Nara-APK** → ekstrak → install `app-debug.apk`.
   (Izinkan "Instal dari sumber tidak dikenal".)
Kalau build merah, salin teks error-nya ke Claude, nanti diperbaiki.

## Perubahan terbaru
- **Jalan tidak lagi moonwalk:** sprite jalan aslinya menghadap kiri & sprite lari menghadap kanan. Sekarang ada set kiri/kanan eksplisit (`walk_L/R`, `run_L/R`), jalan ke kanan = sprite kanan, jalan ke kiri = sprite kiri. Kecepatan dihitung dari animasi (`WALK_DIST`/`RUN_DIST` di `OverlayService.kt`) supaya kaki tidak meluncur.
- **Panel obrolan:** ketuk gelembung ucapan Nara, tombol 💬 di pojok karakter, notifikasi, atau menu tekan-lama. Keyboard langsung terbuka. Geser lewat judul, ubah ukuran lewat ◢, posisi & ukuran diingat.
- **Pembaca layar:** label satu kata kini ikut dipelajari, teks yang terlihat dibaca lebih longgar, ada cadangan jika jendela aktif tidak terbaca, dan ada diagnostik di layar utama (event, jumlah bacaan, galat terakhir). Nara juga bilang "Aku baru tahu kata: …" saat belajar kata baru.

## Setup di HP
1. Buka Nara → **Izinkan tampil di atas aplikasi lain**.
2. **Aktifkan Akses Layar** → Aksesibilitas → Nara → ON.
3. (Opsional) **Izinkan melihat gambar layar** — hanya 4 angka ringkasan yang dipakai, gambar tidak disimpan. Perlu diulang tiap HP restart.
4. **Mulai Nara**. Redmi/MIUI: izinkan "pop-up di latar", "Mulai otomatis", dan baterai "Tanpa batasan".

## Cara Nara belajar
| Bagian | Apa | Belajar dari |
|---|---|---|
| Memori | file di HP: fakta, kejadian app, pasangan percakapan | obrolan, app yang kamu buka |
| NN keputusan (MLP) | prediksi aksi: tap / scroll atas-bawah / back | tiruan perilakumu (imitation learning) |
| NN perilaku (MLP) | jalan / duduk / tidur / lambaikan / ngomong | pat/elus/peluk = 👍, colek berlebihan & "jangan begitu" = 👎 |
| Mini ML | Naive Bayes topik layar, regresi logistik "tombol mana yang biasa kamu sentuh", kebiasaan jam-app | layar & sentuhanmu |
| Mini LLM | model bahasa trigram yang dilatih di HP (ID+EN) | teks layar, obrolan, ketikanmu (bisa dimatikan) |
| Dorongan | energi, bosan, penasaran → memicu tidur, jalan-jalan, bertanya kata baru | waktu & isi layar |

## Interaksi & emosi
| Sentuhan | Efek |
|---|---|
| Ketuk kepala | **Pat** — senang / malu-malu (tergantung kedekatan) |
| Gosok kepala atau badan bolak-balik | **Elus** — nyaman, kedekatan naik |
| Ketuk badan | Colek — kaget; 4x cepat = Nara sebel |
| Geser | Angkat & pindahkan (dia kaget, lalu bereaksi saat dilepas) |
| Tekan lama | Menu: 💬 Ngobrol · 🤗 Peluk · ✋ Tos · 🍪 Camilan · 😴 Tidurlah · 👎 Jangan begitu |

- Tampilan mengikuti emosi: **senang** → pose happy, **marah/sebel** → pose annoyed (tangan bersilang, glitch merah), **sedih** → duduk meringkuk, **ngantuk/tidur** → meringkuk + 💤, lainnya (netral, penasaran, malu, kaget) → pose idle dan reaksinya muncul lewat gelembung ucapan (💗 💓 dll). Dia juga lari kalau targetnya jauh atau lagi senang.
- **Kedekatan (bond)** naik dari pat, elus, peluk, camilan, obrolan baik; turun kalau dimarahi/dihina. Di awal dia malu-malu, lama-lama manja.
- Suasana hati juga memengaruhi tingkahnya (sedih → lebih banyak duduk, senang → sering melambai, sebel → diam) dan pujian/hinaan di chat.
- Kalau lama tidak kamu sapa, dia bisa kesepian dan menyindir. Semua ini ikut tersimpan dan dipelajari.
- "👎 Jangan begitu" dan interaksi menyenangkan juga jadi sinyal belajar untuk NN perilakunya.

Kendali lain: geser = pindah · notifikasi: Jeda / Stop.
Teach manual di chat: `namaku Budi`, `ingat bahwa aku suka kopi`, `kalau aku bilang ping jawab pong`.

## Batas keamanan bawaan
- Nara tidak pernah membaca kolom sandi, dan tidak membaca/menyentuh app bank, dompet digital, OTP, pengaturan, installer (daftar bisa ditambah di app).
- Tidak menyentuh tombol bertuliskan bayar/kirim/hapus/beli/izinkan/OK/setuju dll.
- Tap otomatis baru aktif setelah ≥20 contoh sentuhanmu dipelajari; Back setelah ≥200 langkah belajar.
- Tidak bertindak 8 detik setelah kamu menyentuh layar, atau saat layar terkunci/mati.
- Kalau kamu pindah app sesaat setelah Nara menyentuh layar, itu dihitung sebagai hukuman.

## Struktur
`app/src/main/java/com/nara/companion/brain/` = otak (Kotlin murni, sudah diuji di JVM) ·
`OverlayService` = tubuh/animasi · `ScreenAccessService` = mata & tangan · `CaptureService` = penglihatan opsional ·
`assets/sprites` = frame karakter, dipotong otomatis dari `tools/sheet.png` oleh `tools/slice_sheet.py` (baris IDLE, SIT, WALK, RUN, HAPPY, ANNOYED). Mau ganti karakter: timpa `tools/sheet.png` dengan sheet berformat sama (transparan, baris sama, 8/8/9/9/8/8 frame) lalu jalankan skripnya.


## Tujuan lewat chat, NLP, dan NaraSandbox

Buka panel Nara (tekan lama) dan ketik kalimat biasa. NLP (pengupas imbuhan + jaringan 1 lapis yang dilatih) memahami:
- **kalahkan / menangkan / lawan** -> "kalahkan mittens", "kalahkan dia 3 kali" (Nara bermain catur di NaraSandbox sampai menang)
- **buatkan / bikin** -> "buatkan website portofolio" (Nara meminta app AI membuatkan, membaca jawabannya, lalu belajar)
- **tekan / klik** -> "tekan tombol merah" (Nara mencari dan menekan tombol itu di layar)
- **buka**, **tanya / cari**, **latih** ("latih dirimu catur 100 partai", "latihan tekan tombol"), **status** ("gimana progresnya"), **berhenti**
Perintah garis miring tetap ada: /ketik, /kirim, /cari.

NN: dua MLP lama digabung jadi satu `core.bin` (batang bersama + 2 kepala, parameter -45%). Hasil latihan lama dipindahkan otomatis (distilasi) lalu berkas lama dihapus.
NN catur (`chess.bin`, 768->16->1) dilatih lewat partai melawan Mittens + permainan melawan diri sendiri. NLP disimpan di `nlp.bin`.
Semua berkas ada di folder otak sehingga ikut "Cadangkan otak Nara".

## Melatih chatbot (cara yang dipakai sekarang)

Balasan memakai **pencari balasan (retrieval)**, bukan model pembangkit teks: ucapanmu dicocokkan ke bank pasangan (ucapan -> balasan)
dengan TF-IDF kata (+ kata dasar) dan TF-IDF trigram huruf (tahan typo/singkatan seperti "lg ngapain", "apa kbr").
Kalau tidak ada yang cocok (skor < 0.5), baru jatuh ke aturan lama lalu model bahasa mini.
Cara menambah/memperbaiki pengetahuan, dari yang paling efisien:
1. `/ajari pertanyaan => jawaban` di panel Nara (atau "kalau aku bilang X, jawab Y").
2. "latih obrolan": Nara meminta app AI (tanpa API key) membuatkan 10 pasang percakapan, membacanya dari layar, menyaring (tanpa tanda kutip/gema pertanyaan/URL/kata kasar), lalu menambahkannya sebagai pasangan "dari AI". Ulangi sesukamu (batas 400).
3. Elus/marahi Nara tepat setelah dia membalas: bobot balasan itu naik/turun (balasan yang baru dipakai dihindari agar tidak berulang).
4. Edit `assets/chat.txt` (format `ucapan1; ucapan2 => balasan1; balasan2`) lalu periksa dengan `python tools/check_pairs.py assets/chat.txt`.
Model bahasa n-gram sekarang hanya belajar dari teks layar yang wajar (3-25 kata, dominan huruf, bukan URL/UI KAPITAL), dan pasangan "ucapanmu -> ucapanmu berikutnya" tidak lagi dipelajari.

## Kalau Nara belum paham (tanya balik, koreksi, perintah baru)

- **Ragu (keyakinan < 60%) atau terdengar seperti perintah tapi belum dikenal** -> Nara tidak menebak: dia menampilkan tombol pilihan (Tekan tombol / Buka aplikasi / Tanya-cari / Ngobrol saja / Pelajari cara baru). Pilihanmu melatih NLP (`Nlp.teach`) dan kata kerja pembukanya diingat.
- **Perintah hanya dijalankan kalau ada kata kerja yang dikenalnya** (kamus atau yang pernah kamu ajarkan), supaya kalimat obrolan tidak salah dianggap perintah.
- **Koreksi lewat chat** (dalam 2 menit setelah perintah): "bukan itu", "salah", "bukan itu, maksudku tekan tombol merah", "bukan, cuma ngobrol". Perintah yang salah dibatalkan dan NLP belajar. Kalau tidak dikoreksi, maksud itu diperkuat sedikit.
- Tombol "✗ Bukan itu, salah paham" muncul di panel setelah perintah yang tidak menutup panel.
- **Perintah baru** ("putar lagu dari spotify"): pilih "Pelajari cara baru" -> Nara meminta app AI memecahnya jadi langkah (BUKA / KETIK / KIRIM / TEKAN / TUNGGU), menampilkan rencananya, dan baru menjalankannya setelah kamu menekan **Jalankan**. Kalau semua langkah berhasil, rencana disimpan di `skills.tsv`; lain kali perintah yang mirip langsung dijalankan.
  Pengaman: langkah yang mengandung bayar/transfer/hapus/sandi/OTP/kartu ditolak; KETIK dan KIRIM hanya di browser & app AI; app sensitif tetap diblokir.
- **Jujur kalau tidak tahu**: balasan tidak lagi dikarang dari potongan kata. Nara bilang belum tahu dan menawarkan /ajari. Ucapan yang tak terjawab disimpan dan dipakai sebagai bahan "latih obrolan" (belajar dari celah).

## Pengetahuan dari Neural & NLP Academy

`assets/knowledge.txt` berisi pasangan "pertanyaan => jawaban" hasil ekspor pelajaran Academy (`tools/export_nara_knowledge.py` di proyek Academy). Dimuat ke pencari balasan sebagai sumber `KNOW` (terlihat di statistik: "pengetahuan Academy N"). Setelah memperbarui Nara, tanya misalnya: "apa fungsi bias pada neuron", "jelaskan overfitting", "apa itu tokenisasi subkata", "beda presisi dan recall". Ucapan materi yang tidak ada di bank disimpan sebagai celah untuk "latih obrolan".
