plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
android {
    namespace = "com.nara.companion"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.nara.companion"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    // Kunci tanda tangan TETAP (bukan kunci debug acak milik runner GitHub). Tanpa ini, tiap build punya tanda tangan beda,
    // Android menolak update-di-atas-app-lama, dan kamu harus uninstall -> hasil latihan Nara hilang.
    signingConfigs {
        create("nara") {
            storeFile = file("nara.keystore"); storeType = "pkcs12"
            storePassword = "naranara"; keyAlias = "nara"; keyPassword = "naranara"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nara") }
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("nara") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
