package com.nara.companion.brain;

import java.io.*;
import java.util.*;

/**
 * NLP ringan bahasa Indonesia untuk perintah lewat chat:
 * normalisasi -> token -> stem (pengupas imbuhan, banyak kandidat) -> fitur ber-hash -> softmax (jaringan 1 lapis, bisa dilatih online).
 * Bobot awal diisi dari kamus perintah lalu dilatih dengan contoh kalimat, jadi tetap jalan walau belum pernah dilatih pengguna.
 */
public final class Nlp {
    public static final int CHAT = 0, BEAT = 1, MAKE = 2, PRESS = 3, OPEN = 4, ASK = 5, STOP = 6, STATUS = 7, TRAIN = 8, N = 9;
    public static final String[] NAMES = {"obrolan", "kalahkan", "buat", "tekan", "buka", "tanya", "berhenti", "status", "latih"};
    private static final int D = 2048, MAGIC = 0x4E4C5031;
    private final float[] w = new float[N * D];
    private final float[] bias = new float[N];
    public int trained = 0;

    public static final class Parsed {
        public final int intent; public final float conf; public final String target, tail, game; public final int count;
        Parsed(int i, float c, String t, String tl, String g, int n) { intent = i; conf = c; target = t; tail = tl; game = g; count = n; }
        public String toString() { return NAMES[intent] + "(" + (int) (conf * 100) + "%) target='" + target + "' tail='" + tail + "' game=" + game + " x" + count; }
    }

    private static final String[][] LEX = {
        {}, // CHAT
        {"kalah", "menang", "lawan", "taklukkan", "taklukan", "tumbang", "hajar", "libas", "beat", "defeat", "win", "kalahin", "menangin"},
        {"buat", "bikin", "cipta", "rancang", "bangun", "susun", "rakit", "create", "make", "build", "generate", "tulis", "kode"},
        {"tekan", "klik", "click", "tap", "ketuk", "pencet", "sentuh", "pijit", "press"},
        {"buka", "open", "launch", "mulai", "start", "jalankan", "masuk"},
        {"tanya", "cari", "telusur", "search", "ask", "googling"},
        {"henti", "stop", "batal", "cukup", "diam", "cancel"},
        {"progres", "status", "skor", "hasil", "sampai", "kemajuan", "progress", "berapa"},
        {"latih", "latihan", "belajar", "training", "train", "asah", "berlatih"},
    };
    private static final Set<String> FILL = new HashSet<String>(Arrays.asList(
        "dong", "deh", "ya", "yah", "lah", "tolong", "nara", "dia", "itu", "ini", "saja", "aja", "bisa", "kamu", "aku", "kau", "dirimu", "diri", "untuk", "ke", "di", "dan", "yang", "sekarang", "dulu", "please", "pls", "coba", "mau", "ingin", "pengen", "gua", "gue", "kita", "sampai", "dengan"));
    private static final Set<String> GAME_CHESS = new HashSet<String>(Arrays.asList("catur", "chess", "mittens", "mitten", "bot"));

    public Nlp() { for (int k = 1; k < N; k++) for (String s : LEX[k]) w[k * D + slot(s)] += 2.5f; bias[CHAT] = 0.4f; }

    // ---------------------------------------------------------------- teks
    static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim(); }
    static List<String> tokens(String s) { String n = norm(s); return n.isEmpty() ? new ArrayList<String>() : new ArrayList<String>(Arrays.asList(n.split(" "))); }
    private static int slot(String f) { return (f.hashCode() & 0x7fffffff) % D; }

    private static String cut(String s, String suf) { return s.endsWith(suf) && s.length() - suf.length() >= 3 ? s.substring(0, s.length() - suf.length()) : null; }

    /** Kandidat kata dasar (imbuhan Indonesia & bentuk gaul -in). */
    public static Set<String> stems(String word) {
        LinkedHashSet<String> out = new LinkedHashSet<String>();
        out.add(word);
        String s = word;
        for (String p : new String[]{"lah", "kah", "pun", "nya", "ku", "mu"}) { String c = cut(s, p); if (c != null) { s = c; break; } }
        List<String> bases = new ArrayList<String>(); bases.add(s);
        for (String d : new String[]{"kan", "an", "in", "i"}) { String c = cut(s, d); if (c != null) { bases.add(c); break; } }
        out.addAll(bases);
        String[][] pre = {{"meng", "", "k"}, {"meny", "s"}, {"men", "", "t"}, {"mem", "", "p"}, {"me", ""}, {"peng", "", "k"}, {"peny", "s"}, {"pen", "", "t"}, {"pem", "", "p"}, {"pe", ""},
                          {"ber", ""}, {"bel", ""}, {"be", ""}, {"ter", ""}, {"te", ""}, {"di", ""}, {"ke", ""}, {"se", ""}};
        for (String b : bases) for (String[] p : pre) {
            if (b.startsWith(p[0]) && b.length() - p[0].length() >= 3) {
                String rest = b.substring(p[0].length());
                for (int i = 1; i < p.length; i++) { String c = p[i] + rest; if (c.length() >= 3) out.add(c); }
            }
        }
        return out;
    }

    private static List<String> features(String text) {
        List<String> toks = tokens(text), f = new ArrayList<String>();
        String prev = null;
        for (String t : toks) {
            for (String s : stems(t)) f.add(s);
            if (prev != null) f.add(prev + "_" + t);
            prev = t;
        }
        return f;
    }

    // ---------------------------------------------------------------- model
    private float[] probs(List<String> feats) {
        float[] o = new float[N];
        for (int k = 0; k < N; k++) { float s = bias[k]; for (String f : feats) s += w[k * D + slot(f)]; o[k] = s; }
        float m = o[0]; for (float v : o) m = Math.max(m, v);
        float sum = 0f;
        for (int k = 0; k < N; k++) { o[k] = (float) Math.exp(o[k] - m); sum += o[k]; }
        for (int k = 0; k < N; k++) o[k] /= sum;
        return o;
    }

    /** Satu langkah latihan untuk satu kalimat berlabel. */
    public void learn(String text, int intent, float lr) {
        List<String> f = features(text);
        float[] p = probs(f);
        for (int k = 0; k < N; k++) {
            float g = (k == intent ? 1f : 0f) - p[k];
            bias[k] += lr * g * 0.2f;
            for (String ft : f) { int i = k * D + slot(ft); w[i] = Math.max(-8f, Math.min(8f, w[i] + lr * g)); }
        }
        trained++;
    }

    public void train(String[][] data, int epochs, float lr, Random r) {
        List<Integer> idx = new ArrayList<Integer>(); for (int i = 0; i < data.length; i++) idx.add(i);
        for (int e = 0; e < epochs; e++) { Collections.shuffle(idx, r); for (int i : idx) learn(data[i][0], Integer.parseInt(data[i][1]), lr); }
    }

    // ---------------------------------------------------------------- pengurai
    public Parsed parse(String text) {
        List<String> toks = tokens(text);
        if (toks.isEmpty()) return new Parsed(CHAT, 1f, "", "", "", 1);
        float[] p = probs(features(text));
        int best = 0; for (int k = 1; k < N; k++) if (p[k] > p[best]) best = k;
        String all0 = norm(text);
        // aturan tegas untuk kalimat campuran: kata latihan menang atas "tekan"; "berapa" = bertanya status
        boolean forced = false;
        if (best != TRAIN) for (String t : toks) for (String st : stems(t)) if (Arrays.asList(LEX[TRAIN]).contains(st)) { best = TRAIN; forced = true; }
        if (best != STATUS && Arrays.asList(all0.split(" ")).contains("berapa")) { best = STATUS; forced = true; }
        if (best == CHAT || (!forced && p[best] < 0.35f)) return new Parsed(CHAT, p[CHAT], "", "", "", 1);

        // kata perintah = token pertama yang kata dasarnya ada di kamus intent terpilih
        Set<String> lex = new HashSet<String>(Arrays.asList(LEX[best]));
        int verb = -1;
        for (int i = 0; i < toks.size() && verb < 0; i++) for (String s : stems(toks.get(i))) if (lex.contains(s)) { verb = i; break; }
        List<String> rest = new ArrayList<String>();
        StringBuilder tl = new StringBuilder();
        for (int i = verb + 1; i < toks.size(); i++) { if (tl.length() > 0) tl.append(' '); tl.append(toks.get(i)); }
        for (int i = verb + 1; i < toks.size(); i++) {
            String t = toks.get(i);
            boolean isVerb = false; for (String s2 : stems(t)) if (lex.contains(s2)) isVerb = true;
            if (isVerb) continue;
            if (t.matches("\\d+") || t.equals("kali") || t.equals("x") || t.equals("partai") || t.equals("ronde") || t.equals("game")) continue;
            if (!FILL.contains(t)) rest.add(t);
        }
        String game = "";
        for (String t : toks) if (GAME_CHESS.contains(t)) game = "chess";
        String all = norm(text);
        if (game.isEmpty() && (best == BEAT || best == TRAIN) && !all.contains("tombol")) game = "chess";
        if (best == TRAIN && (all.contains("tekan") || all.contains("tombol"))) game = "tap";
        int count = 1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)\\s*(kali|x|partai|game|ronde)").matcher(all);
        if (m.find()) count = Math.max(1, Math.min(200, Integer.parseInt(m.group(1))));
        else if (all.contains("dua kali")) count = 2; else if (all.contains("tiga kali")) count = 3;
        StringBuilder sb = new StringBuilder();
        for (String t : rest) { if (best == BEAT && GAME_CHESS.contains(t) && !t.equals("mittens") && !t.equals("mitten")) continue; if (sb.length() > 0) sb.append(' '); sb.append(t); }
        return new Parsed(best, forced ? Math.max(p[best], 0.9f) : p[best], sb.toString(), tl.toString(), game, count);
    }

    // ---------------------------------------------------------------- simpan (jarang: hanya bobot bukan nol)
    public void save(File f) throws IOException {
        DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
        try {
            int nz = 0; for (float v : w) if (v != 0f) nz++;
            o.writeInt(MAGIC); o.writeInt(trained); o.writeInt(nz);
            for (int i = 0; i < w.length; i++) if (w[i] != 0f) { o.writeShort(i); o.writeFloat(w[i]); }
            for (float b : bias) o.writeFloat(b);
        } finally { o.close(); }
    }

    public boolean load(File f) {
        if (!f.exists()) return false;
        try {
            DataInputStream i = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));
            try {
                if (i.readInt() != MAGIC) return false;
                trained = i.readInt(); int nz = i.readInt();
                float[] nw = new float[w.length];
                for (int k = 0; k < nz; k++) { int idx = i.readUnsignedShort(); nw[idx] = i.readFloat(); }
                for (int k = 0; k < N; k++) bias[k] = i.readFloat();
                System.arraycopy(nw, 0, w, 0, w.length);
                return true;
            } finally { i.close(); }
        } catch (IOException e) { return false; }
    }

    // ---------------------------------------------------------------- contoh latihan awal
    public static final String[][] SEED = {
        {"kalahkan dia", "1"}, {"kalahkan mittens", "1"}, {"kalahkan bot itu", "1"}, {"menangkan permainan catur", "1"}, {"menangkan pertandingan ini", "1"},
        {"lawan bot mittens di catur", "1"}, {"hajar mittens", "1"}, {"taklukkan bot kucing itu", "1"}, {"kalahin dia dong", "1"}, {"aku mau kamu menang lawan mittens", "1"},
        {"buatkan website portofolio", "2"}, {"buatkan web toko online", "2"}, {"bikinin aku aplikasi catatan", "2"}, {"tolong buat halaman web sederhana", "2"}, {"bikin web untuk sekolah", "2"},
        {"buatkan kode python kalkulator", "2"}, {"ciptakan desain landing page", "2"}, {"rancang website kafe", "2"}, {"buatkan aku sebuah game", "2"}, {"bikin script otomatis", "2"},
        {"tekan tombol merah", "3"}, {"klik tombol kirim", "3"}, {"ketuk tombol biru", "3"}, {"pencet tombol mulai", "3"}, {"tolong tekan tombol itu", "3"},
        {"tap tombol hijau", "3"}, {"sentuh tombol menu", "3"}, {"klik ok", "3"}, {"tekan yang kuning", "3"},
        {"buka chrome", "4"}, {"buka aplikasi catur", "4"}, {"jalankan sandbox", "4"}, {"buka youtube", "4"}, {"mulai aplikasi sandbox", "4"}, {"open chatgpt", "4"},
        {"tanya ai apa itu lubang hitam", "5"}, {"tanyakan ke chatgpt cara membuat web", "5"}, {"cari resep nasi goreng", "5"}, {"telusuri berita hari ini", "5"}, {"tanyain gemini soal matahari", "5"}, {"ask ai about space", "5"},
        {"berhenti", "6"}, {"stop", "6"}, {"batalkan tujuan itu", "6"}, {"sudah cukup", "6"}, {"hentikan sekarang", "6"}, {"batal", "6"}, {"jangan dilanjutkan", "6"},
        {"gimana progresnya", "7"}, {"sudah menang berapa kali", "7"}, {"kalah berapa kali", "7"}, {"menang berapa", "7"}, {"cari tutorial python", "5"}, {"cari tutorial html", "5"}, {"cari info", "5"}, {"sudah sampai mana", "7"}, {"berapa skor kamu", "7"}, {"bagaimana hasilnya", "7"}, {"status tujuan sekarang", "7"}, {"kemajuanmu gimana", "7"},
        {"latih dirimu main catur", "8"}, {"berlatih catur lawan mittens", "8"}, {"latihan tekan tombol", "8"}, {"belajar catur dong", "8"}, {"training dulu ya", "8"}, {"asah kemampuan caturmu", "8"},
        {"halo nara", "0"}, {"apa kabar", "0"}, {"kamu lucu banget", "0"}, {"aku lagi sedih", "0"}, {"terima kasih ya", "0"}, {"hari ini cuacanya panas", "0"}, {"siapa namamu", "0"}, {"aku suka kamu", "0"}, {"kamu lagi apa", "0"}, {"selamat malam", "0"}, {"ceritakan sesuatu", "0"}, {"aku bosan", "0"},
    };

    public void seedTrain() { train(SEED, 30, 0.25f, new Random(42)); }
}
