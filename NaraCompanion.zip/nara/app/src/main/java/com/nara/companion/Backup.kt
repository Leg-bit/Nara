package com.nara.companion

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Cadangan seluruh "otak" Nara (bahasa, ingatan, kebiasaan, jaringan) ke satu berkas zip pilihanmu, dan pemulihannya. */
object Backup {
    @Volatile var restoring = false

    fun export(ctx: Context, uri: Uri): Int {
        NaraApp.brain.save()
        var n = 0
        ctx.contentResolver.openOutputStream(uri)?.use { os ->
            ZipOutputStream(os.buffered()).use { z ->
                File(ctx.filesDir, "brain").listFiles()?.forEach { f ->
                    z.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry(); n++
                }
            }
        }
        return n
    }

    fun import(ctx: Context, uri: Uri): Int {
        restoring = true                       // cegah penyimpanan otomatis menimpa hasil pemulihan
        val dir = File(ctx.filesDir, "brain"); dir.mkdirs()
        var n = 0
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            ZipInputStream(ins.buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val name = File(e.name).name          // buang path: aman dari path traversal
                    if (!e.isDirectory && name.isNotEmpty()) { File(dir, name).outputStream().use { z.copyTo(it) }; n++ }
                    e = z.nextEntry
                }
            }
        }
        return n
    }
}
