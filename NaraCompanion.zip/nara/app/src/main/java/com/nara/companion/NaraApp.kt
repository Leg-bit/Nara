package com.nara.companion

import android.app.Application
import android.content.Context
import android.graphics.Rect
import com.nara.companion.brain.Brain
import com.nara.companion.brain.ScreenStats
import java.io.File

class NaraApp : Application() {
    lateinit var brain: Brain
    override fun onCreate() {
        super.onCreate()
        instance = this
        brain = Brain(File(filesDir, "brain"))
        val seed = try { assets.open("seed.txt").bufferedReader().readText() } catch (e: Exception) { null }
        brain.load(seed)
    }
    companion object {
        lateinit var instance: NaraApp
        val brain: Brain get() = instance.brain
    }
}

/** Status bersama antar service. Semua diakses dari main thread kecuali [visual]. */
object Shared {
    @Volatile var visual = FloatArray(4)
    @Volatile var lastUa = 0
    @Volatile var lastUserTouch = 0L
    @Volatile var selfActUntil = 0L
    @Volatile var lastSelfActionTime = 0L
    @Volatile var paused = false
    @Volatile var curPkg = ""
    @Volatile var curLabel = ""
    @Volatile var curTexts: List<String> = emptyList()
    @Volatile var curStats = ScreenStats()
    @Volatile var charRect = Rect()
    // diagnostik pembaca layar (ditampilkan di aplikasi)
    @Volatile var evCount = 0L
    @Volatile var lastEv = 0L
    @Volatile var lastEvPkg = ""
    @Volatile var readCount = 0L
    @Volatile var lastReadTexts = 0
    @Volatile var lastReadPkg = ""
    @Volatile var lastErr = ""
    @Volatile var lastShot = ""
}

object Prefs {
    private fun sp() = NaraApp.instance.getSharedPreferences("nara", Context.MODE_PRIVATE)
    var autonomy: Int
        get() = sp().getInt("autonomy", 1)
        set(v) { sp().edit().putInt("autonomy", v).apply() }
    var sizePct: Int
        get() = sp().getInt("size", 24)
        set(v) { sp().edit().putInt("size", v).apply() }
    var learnTyping: Boolean
        get() = sp().getBoolean("typing", true)
        set(v) { sp().edit().putBoolean("typing", v).apply() }
    var tts: Boolean
        get() = sp().getBoolean("tts", false)
        set(v) { sp().edit().putBoolean("tts", v).apply() }
    var screenshot: Boolean
        get() = sp().getBoolean("shot", true)
        set(v) { sp().edit().putBoolean("shot", v).apply() }
    var autoType: Boolean
        get() = sp().getBoolean("autotype", true)
        set(v) { sp().edit().putBoolean("autotype", v).apply() }
    var blocklist: String
        get() = sp().getString("block", "") ?: ""
        set(v) { sp().edit().putString("block", v).apply() }
}
