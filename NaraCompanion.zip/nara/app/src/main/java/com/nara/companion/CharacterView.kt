package com.nara.companion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View

/** Menggambar tubuh + tambalan wajah (ekspresi) di atasnya. */
class CharacterView(ctx: Context) : View(ctx) {
    private var body: Bitmap? = null
    private var patch: Bitmap? = null
    private var px = 0
    private var py = 0

    fun show(b: Bitmap, p: Bitmap?, x: Int, y: Int) {
        val old = body
        val resized = old == null || old.width != b.width || old.height != b.height
        body = b; patch = p; px = x; py = y
        if (resized) requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(body?.width ?: 1, body?.height ?: 1) }

    override fun onDraw(c: Canvas) {
        body?.let { c.drawBitmap(it, 0f, 0f, null) }
        patch?.let { c.drawBitmap(it, px.toFloat(), py.toFloat(), null) }
    }
}
