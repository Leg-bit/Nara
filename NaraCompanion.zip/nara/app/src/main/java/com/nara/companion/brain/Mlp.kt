package com.nara.companion.brain

import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.Random
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.tanh

/** Neural network mini: input -> hidden(tanh) -> softmax. Belajar online (SGD) di HP. */
class Mlp(val nIn: Int, val nHid: Int, val nOut: Int, seed: Long = 7L) {
    private val rnd = Random(seed)
    var w1 = FloatArray(nIn * nHid) { (rnd.nextGaussian() * sqrt(2.0 / nIn)).toFloat() }
    var b1 = FloatArray(nHid)
    var w2 = FloatArray(nHid * nOut) { (rnd.nextGaussian() * sqrt(1.0 / nHid)).toFloat() }
    var b2 = FloatArray(nOut)
    var steps = 0L

    private fun hidden(x: FloatArray): FloatArray {
        val h = FloatArray(nHid)
        for (j in 0 until nHid) {
            var s = b1[j]
            for (i in 0 until nIn) { val xi = x[i]; if (xi != 0f) s += xi * w1[i * nHid + j] }
            h[j] = tanh(s)
        }
        return h
    }

    private fun softmax(o: FloatArray): FloatArray {
        var m = o[0]; for (v in o) m = max(m, v)
        var sum = 0f
        val p = FloatArray(o.size)
        for (k in o.indices) { p[k] = exp((o[k] - m).toDouble()).toFloat(); sum += p[k] }
        for (k in p.indices) p[k] /= sum
        return p
    }

    fun forward(x: FloatArray): FloatArray {
        val h = hidden(x)
        val o = FloatArray(nOut)
        for (k in 0 until nOut) {
            var s = b2[k]
            for (j in 0 until nHid) s += h[j] * w2[j * nOut + k]
            o[k] = s
        }
        return softmax(o)
    }

    /**
     * Satu langkah gradient. weight > 0: naikkan peluang [target]; weight < 0: turunkan (hukuman).
     * Mengembalikan cross-entropy sebelum update.
     */
    fun train(x: FloatArray, target: Int, weight: Float = 1f, lr: Float = 0.05f): Float {
        val w = weight.coerceIn(-1f, 1f)
        val h = hidden(x)
        val o = FloatArray(nOut)
        for (k in 0 until nOut) {
            var s = b2[k]
            for (j in 0 until nHid) s += h[j] * w2[j * nOut + k]
            o[k] = s
        }
        val p = softmax(o)
        val loss = -kotlin.math.ln(max(p[target], 1e-6f))
        if (w < 0f && p[target] < 0.08f) return loss   // sudah cukup jarang: jangan dihukum terus (cegah runtuh ke satu aksi)
        val dO = FloatArray(nOut) { k -> w * (p[k] - (if (k == target) 1f else 0f)) }
        val dH = FloatArray(nHid)
        for (j in 0 until nHid) {
            var s = 0f
            for (k in 0 until nOut) {
                s += dO[k] * w2[j * nOut + k]
                w2[j * nOut + k] = (w2[j * nOut + k] - lr * dO[k] * h[j]).coerceIn(-6f, 6f)
            }
            dH[j] = s * (1f - h[j] * h[j])
        }
        for (k in 0 until nOut) b2[k] = (b2[k] - lr * dO[k]).coerceIn(-6f, 6f)
        for (j in 0 until nHid) {
            val g = dH[j]
            if (g != 0f) for (i in 0 until nIn) {
                val xi = x[i]
                if (xi != 0f) w1[i * nHid + j] = (w1[i * nHid + j] - lr * g * xi).coerceIn(-6f, 6f)
            }
            b1[j] -= lr * g
        }
        steps++
        return loss
    }

    fun write(o: DataOutputStream) {
        o.writeInt(nIn); o.writeInt(nHid); o.writeInt(nOut); o.writeLong(steps)
        for (a in arrayOf(w1, b1, w2, b2)) for (v in a) o.writeFloat(v)
    }

    /** false kalau ukuran tidak cocok (mis. setelah update app) -> mulai dari awal. */
    fun read(i: DataInputStream): Boolean {
        if (i.readInt() != nIn || i.readInt() != nHid || i.readInt() != nOut) return false
        steps = i.readLong()
        for (a in arrayOf(w1, b1, w2, b2)) for (k in a.indices) a[k] = i.readFloat()
        return true
    }
}
