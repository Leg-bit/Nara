package com.nara.companion

/** Perintah ketik dari panel obrolan: /ketik, /kirim, /cari. Contoh: "/kirim ke chatgpt: apa itu lubang hitam" */
object TypeCmd {
    class Cmd(val app: String?, val text: String, val submit: Boolean, val search: Boolean)

    private val OPT = setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    private val SLASH = Regex("^\\s*/(ketik|type|kirim|send|cari|search)\\b\\s*(.*)$", OPT)
    private val PLAIN = Regex("^\\s*(ketik|type)\\s+((?:di|ke|in|to|on)\\s+[^:：]{1,40}\\s*[:：].+)$", OPT)
    private val APP = Regex("^(?:di|ke|in|to|on)\\s+([^:：]{1,40}?)\\s*[:：]\\s*(.+)$", OPT)

    fun parse(s: String): Cmd? {
        val m = SLASH.find(s) ?: PLAIN.find(s) ?: return null
        val verb = m.groupValues[1].lowercase()
        var rest = m.groupValues[2].trim()
        var app: String? = null
        APP.find(rest)?.let { app = it.groupValues[1].trim(); rest = it.groupValues[2].trim() }
        if (rest.isEmpty()) return null
        val search = verb == "cari" || verb == "search"
        return Cmd(app, rest, verb == "kirim" || verb == "send" || search, search)
    }
}
