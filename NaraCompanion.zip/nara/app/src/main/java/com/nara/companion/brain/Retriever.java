package com.nara.companion.brain;

import java.io.*;
import java.util.*;

/**
 * Pencari balasan (retrieval chatbot): mencocokkan ucapan pengguna dengan bank pasangan (ucapan -> balasan) memakai
 * TF-IDF kata (+ kata dasar) dan TF-IDF trigram huruf (tahan salah ketik/singkatan). Balasan berbobot: reaksi pengguna
 * (elus/marah) menaikkan atau menurunkan peluang sebuah balasan; balasan yang baru dipakai dihindari.
 * Seluruh isi bank berasal dari data bersih (seed, ajaran pengguna, pasangan hasil AI yang lolos saringan), bukan teks acak dari layar.
 */
public final class Retriever {
    public static final int SEED = 0, USER = 1, AI = 2;
    public static final class Hit { public final String reply; public final int id; public final float score; Hit(String r, int i, float s) { reply = r; id = i; score = s; } }

    private static final class E { String prompt, reply; float w = 1f; int src; HashMap<String, Float> wv, cv; float wn, cn; }
    private static final Set<String> STOP = new HashSet<String>(Arrays.asList("dong", "deh", "ya", "yah", "sih", "kok", "nih", "tuh", "lah", "kan", "aja", "saja", "yang", "di", "ke", "dan", "itu", "ini", "nya", "dulu", "banget", "bgt", "sekali", "nih"));
    public static float MIN_SCORE = 0.50f, A_WORD = 0.35f, A_CHAR = 0.65f;

    private final ArrayList<E> bank = new ArrayList<E>();
    private final HashMap<String, Integer> dfW = new HashMap<String, Integer>(), dfC = new HashMap<String, Integer>();
    private boolean dirty = true;
    private final ArrayDeque<String> recent = new ArrayDeque<String>();
    private final Random rnd = new Random();
    public int lastId = -1;

    public int size() { return bank.size(); }
    public int count(int src) { int n = 0; for (E e : bank) if (e.src == src) n++; return n; }

    // ------------------------------------------------------------ fitur
    private static HashMap<String, Float> wordFeats(String text) {
        HashMap<String, Float> m = new HashMap<String, Float>();
        for (String t : Nlp.tokens(text)) {
            if (STOP.contains(t)) continue;
            inc(m, "w:" + t, 1f);
            Set<String> st = Nlp.stems(t);
            if (st.size() > 1) { float each = 0.5f / (st.size() - 1); for (String s : st) if (!s.equals(t)) inc(m, "s:" + s, each); }
        }
        return m;
    }

    private static HashMap<String, Float> charFeats(String text) {
        HashMap<String, Float> m = new HashMap<String, Float>();
        for (String t : Nlp.tokens(text)) {
            if (STOP.contains(t)) continue;
            String p = "_" + t + "_";
            for (int i = 0; i + 3 <= p.length(); i++) inc(m, p.substring(i, i + 3), 1f);
        }
        return m;
    }

    private static void inc(HashMap<String, Float> m, String k, float v) { Float o = m.get(k); m.put(k, o == null ? v : o + v); }

    private float idf(HashMap<String, Integer> df, String f) { Integer d = df.get(f); return (float) Math.log(1.0 + bank.size() / (1.0 + (d == null ? 0 : d))); }

    private void rebuild() {
        dfW.clear(); dfC.clear();
        for (E e : bank) {
            if (e.wv == null) { e.wv = wordFeats(e.prompt); e.cv = charFeats(e.prompt); }
            for (String f : e.wv.keySet()) { Integer d = dfW.get(f); dfW.put(f, d == null ? 1 : d + 1); }
            for (String f : e.cv.keySet()) { Integer d = dfC.get(f); dfC.put(f, d == null ? 1 : d + 1); }
        }
        for (E e : bank) { e.wn = norm(e.wv, dfW); e.cn = norm(e.cv, dfC); }
        dirty = false;
    }

    private float norm(HashMap<String, Float> v, HashMap<String, Integer> df) {
        double s = 0; for (Map.Entry<String, Float> x : v.entrySet()) { float w = x.getValue() * idf(df, x.getKey()); s += w * w; }
        return (float) Math.sqrt(s);
    }

    private float cos(HashMap<String, Float> q, float qn, E e, HashMap<String, Float> ev, float en, HashMap<String, Integer> df) {
        if (qn == 0f || en == 0f) return 0f;
        double dot = 0;
        for (Map.Entry<String, Float> x : q.entrySet()) { Float o = ev.get(x.getKey()); if (o != null) { float i = idf(df, x.getKey()); dot += x.getValue() * i * o * i; } }
        return (float) (dot / (qn * en));
    }

    // ------------------------------------------------------------ jawab
    public Hit answer(String text) {
        if (bank.isEmpty() || text == null || text.trim().isEmpty()) return null;
        if (dirty) rebuild();
        HashMap<String, Float> qw = wordFeats(text), qc = charFeats(text);
        float qwn = norm(qw, dfW), qcn = norm(qc, dfC);
        float[] sc = new float[bank.size()];
        float best = 0f;
        for (int i = 0; i < sc.length; i++) {
            E e = bank.get(i);
            sc[i] = A_WORD * cos(qw, qwn, e, e.wv, e.wn, dfW) + A_CHAR * cos(qc, qcn, e, e.cv, e.cn, dfC);
            if (sc[i] > best) best = sc[i];
        }
        if (best < MIN_SCORE) return null;
        ArrayList<Integer> cand = new ArrayList<Integer>(); ArrayList<Float> wt = new ArrayList<Float>(); float tot = 0f;
        for (int i = 0; i < sc.length; i++) if (sc[i] >= best - 0.03f) {
            float w = bank.get(i).w * (recent.contains(bank.get(i).reply) ? 0.25f : 1f);
            cand.add(i); wt.add(w); tot += w;
        }
        float r = rnd.nextFloat() * tot; int pick = cand.get(cand.size() - 1);
        for (int k = 0; k < cand.size(); k++) { r -= wt.get(k); if (r <= 0f) { pick = cand.get(k); break; } }
        E e = bank.get(pick);
        recent.addLast(e.reply); while (recent.size() > 6) recent.removeFirst();
        lastId = pick;
        return new Hit(e.reply, pick, best);
    }

    /** Reaksi pengguna atas balasan [id]: r>0 elus/senang, r<0 marah/tidak suka. */
    public void reward(int id, float r) {
        if (id < 0 || id >= bank.size()) return;
        E e = bank.get(id);
        e.w = Math.max(0.15f, Math.min(3f, e.w * (1f + 0.3f * Math.max(-1f, Math.min(1f, r)))));
    }

    // ------------------------------------------------------------ data
    private static String clean(String s, int max) { s = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim(); return s.length() > max ? s.substring(0, max) : s; }

    public boolean has(String prompt) { String p = clean(prompt, 160).toLowerCase(Locale.ROOT); for (E e : bank) if (e.prompt.toLowerCase(Locale.ROOT).equals(p)) return true; return false; }

    /** Tambah pasangan; true kalau baru. Pasangan yang sama persis hanya menaikkan bobot. */
    public boolean add(String prompt, String reply, float w, int src) {
        String p = clean(prompt, 160), r = clean(reply, 240);
        if (p.length() < 2 || r.length() < 2) return false;
        for (E e : bank) if (e.prompt.equalsIgnoreCase(p) && e.reply.equals(r)) { e.w = Math.min(3f, e.w + 0.2f); return false; }
        E e = new E(); e.prompt = p; e.reply = r; e.w = w; e.src = src;
        bank.add(e); dirty = true;
        return true;
    }

    /** Format seed: "prompt1; prompt2 => balasan1; balasan2" (satu aturan per baris). Mengembalikan jumlah pasangan baru. */
    public int loadSeed(String text) {
        int n = 0;
        for (String line : text.split("\n")) {
            int i = line.indexOf("=>"); if (i < 0) continue;
            String[] ps = line.substring(0, i).split(";"), rs = line.substring(i + 2).split(";");
            for (String p : ps) for (String r : rs) if (add(p, r, 1f, SEED)) n++;
        }
        return n;
    }

    public void save(File f) throws IOException {
        BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
        try { for (E e : bank) w.write(e.src + "\t" + e.w + "\t" + e.prompt + "\t" + e.reply + "\n"); } finally { w.close(); }
    }

    public int load(File f) {
        if (!f.exists()) return 0;
        int n = 0;
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
            try {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] p = line.split("\t", 4); if (p.length < 4) continue;
                    E e = new E(); e.src = Integer.parseInt(p[0]); e.w = Float.parseFloat(p[1]); e.prompt = p[2]; e.reply = p[3];
                    bank.add(e); n++;
                }
            } finally { r.close(); }
        } catch (Exception ex) { /* berkas rusak: lewati sisanya */ }
        dirty = true;
        return n;
    }
}
