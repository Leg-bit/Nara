package com.nara.companion.brain;

/** Papan catur lengkap (langkah legal, rokade, en passant, promosi). Dipakai Nara (agen) dan Sandbox (permainan). */
public final class Chess {
    public static final int P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
    private static final int[] VAL = {0, 1, 3, 3, 5, 9, 0};
    private static final int[] KN = {1, 2, 2, 1, 2, -1, 1, -2, -1, 2, -2, 1, -1, -2, -2, -1};
    private static final int[] KG = {1, 0, -1, 0, 0, 1, 0, -1, 1, 1, 1, -1, -1, 1, -1, -1};

    /** b[sq]: sq = rank*8+file (a1=0 .. h8=63). Putih positif (1..6), hitam negatif. */
    public final int[] b = new int[64];
    public int side = 1;       // 1 = putih jalan, -1 = hitam jalan
    public int castle = 15;    // 1=O-O putih, 2=O-O-O putih, 4=O-O hitam, 8=O-O-O hitam
    public int ep = -1;        // kotak en passant
    public int half = 0, ply = 0;

    public static Chess start() {
        Chess c = new Chess();
        int[] back = {R, N, B, Q, K, B, N, R};
        for (int f = 0; f < 8; f++) {
            c.b[f] = back[f]; c.b[8 + f] = P; c.b[48 + f] = -P; c.b[56 + f] = -back[f];
        }
        return c;
    }

    public Chess copy() {
        Chess c = new Chess();
        System.arraycopy(b, 0, c.b, 0, 64);
        c.side = side; c.castle = castle; c.ep = ep; c.half = half; c.ply = ply;
        return c;
    }

    public static String name(int sq) { return "" + (char) ('a' + (sq & 7)) + (char) ('1' + (sq >> 3)); }
    public static int index(String s) { return (s.charAt(1) - '1') * 8 + (s.charAt(0) - 'a'); }
    public static int move(int from, int to, int promo) { return from | (to << 6) | (promo << 12); }
    public static int from(int m) { return m & 63; }
    public static int to(int m) { return (m >> 6) & 63; }
    public static int promo(int m) { return (m >> 12) & 7; }

    public int material() {
        int m = 0;
        for (int i = 0; i < 64; i++) { int p = b[i]; if (p > 0) m += VAL[p]; else if (p < 0) m -= VAL[-p]; }
        return m;
    }

    private int kingSq(int s) {
        for (int i = 0; i < 64; i++) if (b[i] == s * K) return i;
        return -1;
    }

    /** Apakah kotak sq diserang oleh pihak [by]. */
    public boolean attacked(int sq, int by) {
        int f = sq & 7, r = sq >> 3;
        int pr = r - by;   // pion putih menyerang ke atas: dia berada satu baris di bawah
        if (pr >= 0 && pr < 8) {
            if (f > 0 && b[pr * 8 + f - 1] == by * P) return true;
            if (f < 7 && b[pr * 8 + f + 1] == by * P) return true;
        }
        for (int i = 0; i < 16; i += 2) {
            int nf = f + KN[i], nr = r + KN[i + 1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] == by * N) return true;
        }
        for (int i = 0; i < 16; i += 2) {
            int nf = f + KG[i], nr = r + KG[i + 1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] == by * K) return true;
        }
        for (int i = 0; i < 16; i += 2) {
            int df = KG[i], dr = KG[i + 1];
            boolean diag = df != 0 && dr != 0;
            int nf = f + df, nr = r + dr;
            while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                int p = b[nr * 8 + nf];
                if (p != 0) {
                    if (p * by > 0) {
                        int t = Math.abs(p);
                        if (t == Q || (diag && t == B) || (!diag && t == R)) return true;
                    }
                    break;
                }
                nf += df; nr += dr;
            }
        }
        return false;
    }

    public boolean inCheck(int s) { int k = kingSq(s); return k >= 0 && attacked(k, -s); }

    private int[] buf = new int[256]; private int n;
    private void add(int from, int to, int promo, boolean allPromos) {
        if (promo == 0) { buf[n++] = move(from, to, 0); return; }
        if (allPromos) { buf[n++] = move(from, to, N); buf[n++] = move(from, to, B); buf[n++] = move(from, to, R); }
        buf[n++] = move(from, to, Q);
    }

    private void pseudo(boolean allPromos) {
        n = 0;
        for (int sq = 0; sq < 64; sq++) {
            int p = b[sq];
            if (p * side <= 0) continue;
            int t = Math.abs(p), f = sq & 7, r = sq >> 3;
            if (t == P) {
                int nr = r + side, last = side == 1 ? 7 : 0;
                if (nr >= 0 && nr < 8) {
                    int one = nr * 8 + f;
                    if (b[one] == 0) {
                        add(sq, one, nr == last ? Q : 0, allPromos);
                        int startRank = side == 1 ? 1 : 6;
                        if (r == startRank && b[one + side * 8] == 0) add(sq, one + side * 8, 0, allPromos);
                    }
                    for (int df = -1; df <= 1; df += 2) {
                        int nf = f + df; if (nf < 0 || nf > 7) continue;
                        int to = nr * 8 + nf;
                        if ((b[to] * side < 0) || to == ep) add(sq, to, nr == last ? Q : 0, allPromos);
                    }
                }
            } else if (t == N || t == K) {
                int[] d = t == N ? KN : KG;
                for (int i = 0; i < 16; i += 2) {
                    int nf = f + d[i], nr = r + d[i + 1];
                    if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                    int to = nr * 8 + nf;
                    if (b[to] * side <= 0) add(sq, to, 0, allPromos);
                }
                if (t == K) castling(sq);
            } else {
                for (int i = 0; i < 16; i += 2) {
                    int df = KG[i], dr = KG[i + 1];
                    boolean diag = df != 0 && dr != 0;
                    if (t == B && !diag) continue;
                    if (t == R && diag) continue;
                    int nf = f + df, nr = r + dr;
                    while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                        int to = nr * 8 + nf;
                        if (b[to] * side > 0) break;
                        add(sq, to, 0, allPromos);
                        if (b[to] != 0) break;
                        nf += df; nr += dr;
                    }
                }
            }
        }
    }

    private void castling(int sq) {
        int home = side == 1 ? 4 : 60;
        if (sq != home) return;
        int kRight = side == 1 ? 1 : 4, qRight = side == 1 ? 2 : 8;
        int base = side == 1 ? 0 : 56;
        if ((castle & kRight) != 0 && b[base + 5] == 0 && b[base + 6] == 0 && b[base + 7] == side * R
                && !attacked(home, -side) && !attacked(base + 5, -side) && !attacked(base + 6, -side))
            buf[n++] = move(home, base + 6, 0);
        if ((castle & qRight) != 0 && b[base + 3] == 0 && b[base + 2] == 0 && b[base + 1] == 0 && b[base] == side * R
                && !attacked(home, -side) && !attacked(base + 3, -side) && !attacked(base + 2, -side))
            buf[n++] = move(home, base + 2, 0);
    }

    /** Terapkan langkah (tanpa cek legal). */
    public void apply(int m) {
        int from = from(m), to = to(m), promo = promo(m);
        int p = b[from], t = Math.abs(p), cap = b[to];
        if (t == P && to == ep && cap == 0 && (from & 7) != (to & 7)) { b[to - side * 8] = 0; cap = -side * P; }
        b[to] = p; b[from] = 0;
        if (promo != 0) b[to] = side * promo;
        if (t == K && Math.abs(to - from) == 2) {
            if (to > from) { b[to - 1] = b[to + 1]; b[to + 1] = 0; } else { b[to + 1] = b[to - 2]; b[to - 2] = 0; }
        }
        if (t == K) castle &= side == 1 ? ~3 : ~12;
        if (from == 0 || to == 0) castle &= ~2;
        if (from == 7 || to == 7) castle &= ~1;
        if (from == 56 || to == 56) castle &= ~8;
        if (from == 63 || to == 63) castle &= ~4;
        ep = (t == P && Math.abs(to - from) == 16) ? (from + to) / 2 : -1;
        half = (t == P || cap != 0) ? 0 : half + 1;
        side = -side; ply++;
    }

    /** Semua langkah legal. allPromos=false: promosi hanya ke ratu. */
    public int[] moves(boolean allPromos) {
        pseudo(allPromos);
        int[] tmp = new int[n]; int k = 0;
        int me = side;
        for (int i = 0; i < n; i++) {
            Chess c = copy(); c.apply(buf[i]);
            if (!c.inCheck(me)) tmp[k++] = buf[i];
        }
        int[] out = new int[k]; System.arraycopy(tmp, 0, out, 0, k);
        return out;
    }

    public boolean isLegal(int m) { for (int x : moves(true)) if (x == m || (from(x) == from(m) && to(x) == to(m) && promo(x) == Q && promo(m) == 0)) return true; return false; }

    /** Cari langkah legal dari->ke (promosi otomatis ratu); -1 kalau tidak legal. */
    public int find(int from, int to) {
        for (int x : moves(false)) if (from(x) == from && to(x) == to) return x;
        return -1;
    }

    private boolean insufficient() {
        int minors = 0;
        for (int i = 0; i < 64; i++) {
            int t = Math.abs(b[i]);
            if (t == P || t == R || t == Q) return false;
            if (t == N || t == B) minors++;
        }
        return minors <= 1;
    }

    /** 0 lanjut, 1 putih menang, -1 hitam menang, 2 seri. */
    public int result(int[] legal, int maxPly) {
        if (legal.length == 0) return inCheck(side) ? -side : 2;
        if (half >= 100 || insufficient() || ply >= maxPly) return 2;
        return 0;
    }

    public long perft(int depth) {
        int[] mv = moves(true);
        if (depth == 1) return mv.length;
        long total = 0;
        for (int m : mv) { Chess c = copy(); c.apply(m); total += c.perft(depth - 1); }
        return total;
    }

    /** "wP", "bK" atau "--". */
    public static String code(int p) {
        if (p == 0) return "--";
        return (p > 0 ? "w" : "b") + "?PNBRQK".charAt(Math.abs(p));
    }

    public static int parseCode(String s) {
        if (s.equals("--")) return 0;
        int t = "PNBRQK".indexOf(s.charAt(1)) + 1;
        return s.charAt(0) == 'w' ? t : -t;
    }
}
