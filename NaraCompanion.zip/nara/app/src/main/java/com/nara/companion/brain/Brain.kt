package com.nara.companion.brain

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.util.Calendar
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object Act { const val NONE = 0; const val TAP = 1; const val DOWN = 2; const val UP = 3; const val BACK = 4; const val SWITCH = 5; const val TYPE = 6; const val N = 7 }
object Body { const val IDLE = 0; const val WALK = 1; const val SIT = 2; const val SLEEP = 3; const val WAVE = 4; const val TALK = 5; const val N = 6 }

class ScreenStats(
    val textLen: Int = 0, val scrollable: Boolean = false, val clickable: Int = 0, val editable: Boolean = false,
    val visual: FloatArray = FloatArray(4)
)

/** Dorongan internal: inilah yang membuat Nara punya "kehendak sendiri". */
class Drives {
    var energy = 0.9f; var boredom = 0f; var curiosity = 0f
    fun tick(dt: Float, asleep: Boolean) {
        energy = if (asleep) min(1f, energy + dt / 600f) else max(0f, energy - dt / 5400f)
        boredom = min(1f, boredom + dt / 300f)
        curiosity = max(0f, curiosity - dt / 150f)
    }
}

enum class Emo { NEUTRAL, HAPPY, SAD, ANGRY, SURPRISED, SLEEPY, CURIOUS, SHY }
object Inter { const val PAT = 0; const val RUB = 1; const val POKE = 2; const val HUG = 3; const val HIGH5 = 4; const val SNACK = 5; const val SCOLD = 6; const val SLEEP = 7; const val LIFT = 8; const val DROP = 9 }
class Reaction(val emo: Emo, val text: String?)

/** Suasana hati: valensi (senang-sedih) + kedekatan (bond) yang tumbuh dari interaksimu + emosi sesaat. */
class Mood {
    var valence = 0.2f
    var bond = 0.15f
    var lastInteract = System.currentTimeMillis()
    private var tEmo: Emo? = null
    private var tUntil = 0L
    fun impulse(e: Emo, dv: Float, durMs: Long, now: Long = System.currentTimeMillis()) {
        tEmo = e; tUntil = now + durMs; valence = (valence + dv).coerceIn(-1f, 1f)
    }
    fun tick(dt: Float) { valence += (0.15f + bond * 0.3f - valence) * (dt / 300f).coerceAtMost(1f) }
    fun current(energy: Float, curiosity: Float, now: Long = System.currentTimeMillis()): Emo {
        tEmo?.let { if (now < tUntil) return it }
        return when {
            energy < 0.25f -> Emo.SLEEPY
            valence < -0.3f -> Emo.SAD
            curiosity > 0.5f -> Emo.CURIOUS
            valence > 0.5f -> Emo.HAPPY
            else -> Emo.NEUTRAL
        }
    }
}

private class Rule(val prompts: List<Set<String>>, val replies: List<String>)

class Brain(private val dir: File) {
    companion object { const val IN = 54 }

    val mem = Memory(dir)
    val lm = TinyLm()
    val nb = TopicNB()
    val habit = HabitModel()
    val nodes = NodeScorer()
    /** Satu jaringan inti (batang bersama + kepala keputusan + kepala tubuh) menggantikan dua MLP lama. */
    val core = CoreNet(IN, 24, Act.N, Body.N, 11)
    val chess = ChessNet()
    val nlp = Nlp()
    /** Pencari balasan (retrieval chatbot): bank pasangan ucapan->balasan yang bersih, berbobot oleh reaksimu. */
    val retr = Retriever()
    private var lastRetrId = -1; private var lastRetrAt = 0L
    private val tapVisits = IntArray(32)   // 4 kolom x 8 baris: agar sentuhan tersebar ke seluruh layar, tidak menumpuk di tengah
    val drives = Drives()
    val mood = Mood()
    private val pokes = ArrayList<Long>()
    private val rnd = Random()
    private val rules = ArrayList<Rule>()
    private var prevUser = ""
    private var pendingWord: String? = null
    private var pendingAt = 0L
    var lang = "id"; private set
    var lastSaid = ""; private set

    private var bodyCtx: FloatArray? = null; private var bodyAct = -1
    private var imitCtx: FloatArray? = null; private var imitAct = -1

    init { priorBody(core) }
    private fun priorBody(c: CoreNet) { c.setBias(1, Body.IDLE, 0.6f); c.setBias(1, Body.WALK, 0.6f); c.setBias(1, Body.WAVE, -0.6f); c.setBias(1, Body.SLEEP, -1f); c.setBias(1, Body.TALK, -2f) }

    // ---------------------------------------------------------------- simpan / muat
    fun load(seedText: String?) {
        dir.mkdirs(); mem.load()
        lm.load(File(dir, "lm.txt")); nb.load(File(dir, "nb.tsv")); habit.load(File(dir, "habit.tsv")); nodes.load(File(dir, "nodes.bin"))
        loadCore()
        chess.load(File(dir, "chess.bin"))
        retr.load(File(dir, "chat_bank.tsv"))
        if (seedText != null) retr.loadSeed(seedText)
        if (!nlp.load(File(dir, "nlp.bin"))) nlp.seedTrain()
        mem.fact("tapvis")?.split(",")?.forEachIndexed { i, v -> if (i < tapVisits.size) tapVisits[i] = v.toIntOrNull() ?: 0 }
        mem.fact("energy")?.toFloatOrNull()?.let { drives.energy = it }
        mem.fact("bond")?.toFloatOrNull()?.let { mood.bond = it }
        mem.fact("valence")?.toFloatOrNull()?.let { mood.valence = it }
        if (seedText != null) {
            parseSeed(seedText)
            if (mem.fact("seeded") != "v1") { seedText.lines().filter { it.startsWith("S:") }.forEach { lm.learn(it.substring(2), 1) }; lm.clearFresh(); lm.recent.clear(); mem.setFact("seeded", "v1") }
        }
        refreshLang()
    }

    // ---- NN gabungan: hasil latihan MLP lama (body.bin / imit.bin) dipindahkan ke core.bin (distilasi), lalu berkas lama dihapus
    private fun loadCore() {
        val f = File(dir, "core.bin")
        var ok = false
        if (f.exists()) try { DataInputStream(f.inputStream().buffered()).use { ok = core.read(it) } } catch (_: Exception) {}
        if (ok) return
        val hasB = File(dir, "body.bin").exists(); val hasI = File(dir, "imit.bin").exists()
        if (!hasB && !hasI) return                       // pengguna baru: bobot awal sudah memuat prior
        val oldBody = Mlp(IN, 24, Body.N, 11); val oldImit = Mlp(IN, 24, Act.N, 13)
        oldBody.b2[Body.IDLE] = 0.6f; oldBody.b2[Body.WALK] = 0.6f; oldBody.b2[Body.WAVE] = -0.6f; oldBody.b2[Body.SLEEP] = -1f; oldBody.b2[Body.TALK] = -2f
        if (hasB) loadMlp(oldBody, "body.bin")
        if (hasI) loadMlp(oldImit, "imit.bin")
        val r = Random(5)
        repeat(4) { repeat(2000) {
            val x = randomCtx(r)
            core.trainSoft(0, x, oldImit.forward(x), 0.05f)
            core.trainSoft(1, x, oldBody.forward(x), 0.05f)
        } }
        core.steps[0] = oldImit.steps; core.steps[1] = oldBody.steps
        saveCore()
        File(dir, "body.bin").delete(); File(dir, "imit.bin").delete()
    }

    private fun saveCore() { DataOutputStream(File(dir, "core.bin").outputStream().buffered()).use { core.write(it) } }

    private fun randomCtx(r: Random): FloatArray {
        val x = FloatArray(IN)
        val h = r.nextDouble() * 24; val d = r.nextInt(7).toDouble()
        x[0] = sin(2 * PI * h / 24).toFloat(); x[1] = cos(2 * PI * h / 24).toFloat()
        x[2] = sin(2 * PI * d / 7).toFloat(); x[3] = cos(2 * PI * d / 7).toFloat()
        x[4 + r.nextInt(32)] = 1f
        x[36] = r.nextFloat(); x[37] = if (r.nextBoolean()) 1f else 0f; x[38] = r.nextFloat(); x[39] = if (r.nextBoolean()) 1f else 0f
        x[40 + r.nextInt(Act.N)] = 1f
        for (i in 47 until IN) x[i] = r.nextFloat()
        return x
    }

    private fun loadMlp(m: Mlp, name: String) {
        val f = File(dir, name); if (!f.exists()) return
        try { DataInputStream(f.inputStream().buffered()).use { m.read(it) } } catch (_: Exception) {}
    }

    fun save() {
        dir.mkdirs()
        mem.setFact("energy", drives.energy.toString()); mem.setFact("bond", mood.bond.toString()); mem.setFact("valence", mood.valence.toString())
        lm.save(File(dir, "lm.txt")); nb.save(File(dir, "nb.tsv")); habit.save(File(dir, "habit.tsv")); nodes.save(File(dir, "nodes.bin"))
        saveCore()
        try { chess.save(File(dir, "chess.bin")) } catch (_: Exception) {}
        try { retr.save(File(dir, "chat_bank.tsv")) } catch (_: Exception) {}
        try { nlp.save(File(dir, "nlp.bin")) } catch (_: Exception) {}
        mem.setFact("tapvis", tapVisits.joinToString(","))
        mem.save()
    }

    fun stats(): String =
        "kata dikenal: ${lm.vocabSize} • token dipelajari: ${lm.tokensSeen}\n" +
        "kata terbaru: ${lm.recent.takeLast(10).joinToString(", ").ifEmpty { "-" }}\n" +
        "NN inti (1 jaringan, ${core.paramCount()} parameter): keputusan ${core.steps[0]} • perilaku ${core.steps[1]}\n" +
        "catur: ${chess.stats()} • NLP: ${nlp.trained} contoh dilatih\n" +
        "balasan: ${retr.size()} pasangan (seed ${retr.count(Retriever.SEED)} • ajaranmu ${retr.count(Retriever.USER)} • dari AI ${retr.count(Retriever.AI)})\n" +
        "contoh sentuhan dipelajari: ${nodes.updates} • kejadian diingat: ${mem.events.size}\n" +
        "kedekatan: ${(mood.bond * 100).toInt()}% • suasana hati: ${emotion().name.lowercase()}\n" +
        "pat: ${mem.fact("n_pat") ?: 0} • elus: ${mem.fact("n_rub") ?: 0} • peluk: ${mem.fact("n_hug") ?: 0}\n" +
        "energi: ${(drives.energy * 100).toInt()}% • bosan: ${(drives.boredom * 100).toInt()}% • penasaran: ${(drives.curiosity * 100).toInt()}%"

    fun wipe() { mem.wipe(); dir.listFiles()?.forEach { if (it.name != "facts.properties") it.delete() } }

    // ---------------------------------------------------------------- konteks (input NN)
    fun context(pkg: String, st: ScreenStats, lastUa: Int, cal: Calendar = Calendar.getInstance()): FloatArray {
        val x = FloatArray(IN)
        val h = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
        val d = (cal.get(Calendar.DAY_OF_WEEK) - 1).toDouble()
        x[0] = sin(2 * PI * h / 24).toFloat(); x[1] = cos(2 * PI * h / 24).toFloat()
        x[2] = sin(2 * PI * d / 7).toFloat(); x[3] = cos(2 * PI * d / 7).toFloat()
        x[4 + (pkg.hashCode() and 0x7fffffff) % 32] = 1f
        x[36] = min(1f, st.textLen / 2000f); x[37] = if (st.scrollable) 1f else 0f
        x[38] = min(1f, st.clickable / 30f); x[39] = if (st.editable) 1f else 0f
        x[40 + lastUa.coerceIn(0, Act.N - 1)] = 1f
        for (i in 0 until 4) x[47 + i] = st.visual.getOrElse(i) { 0f }
        x[51] = drives.energy; x[52] = drives.boredom; x[53] = drives.curiosity
        return x
    }

    // ---------------------------------------------------------------- belajar dari kamu
    fun observeUserAction(ctx: FloatArray, ua: Int) { core.train(0, ctx, ua, 1f, 0.03f); drives.boredom = max(0f, drives.boredom - 0.15f) }
    fun observeIdle(ctx: FloatArray) { core.train(0, ctx, Act.NONE, 0.4f, 0.01f) }

    fun observeUserClick(feats: List<String>, negatives: List<List<String>>) {
        nodes.update(feats, 1f)
        negatives.take(6).forEach { nodes.update(it, 0f, 0.08f) }
    }

    /** Dipanggil saat layar berubah. Mengembalikan "kebaruan" 0..1. */
    /** Hanya kalimat wajar yang dipelajari model bahasa: 3-25 kata, dominan huruf, bukan URL/email/teks KAPITAL antarmuka. */
    private fun goodLine(s: String): Boolean {
        val w = s.trim().split(Regex("\\s+"))
        if (w.size !in 3..25) return false
        if (s.count { it.isLetter() } < s.length * 0.7) return false
        if (s.contains("http") || s.contains("www.") || s.contains("@")) return false
        return s.count { it.isUpperCase() } <= s.length * 0.5
    }

    fun observeScreen(pkg: String, appLabel: String, texts: List<String>): Float {
        habit.learn(Calendar.getInstance().get(Calendar.HOUR_OF_DAY), appLabel)
        val joined = texts.filter { goodLine(it) }.joinToString(". ")
        if (joined.isBlank()) return 0f
        val nov = lm.novelty(joined)
        if (joined.length > 40) drives.curiosity = max(drives.curiosity, min(1f, nov * 0.9f))
        lm.learn(joined)
        nb.learn(pkg, lm.tokenize(joined))
        return nov
    }

    /** Memuat bank balasan tambahan (chat.txt) ke pencari balasan. */
    fun loadChat(text: String?) { if (text != null) retr.loadSeed(text) }

    fun observeApp(pkg: String, appLabel: String) { mem.event(pkg, "app", appLabel) }
    fun observeTyped(text: String) { lm.learn(text, 2) }

    // ---------------------------------------------------------------- keputusan
    private fun pick(p: FloatArray): Int {
        var tot = 0f; for (v in p) tot += v
        var r = rnd.nextFloat() * tot
        for (i in p.indices) { r -= p[i]; if (r <= 0f) return i }
        return p.size - 1
    }

    fun decideBody(ctx: FloatArray, hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)): Int {
        val p = core.forwardB(ctx)
        val e = drives.energy
        if (e < 0.12f) p[Body.SLEEP] *= 8f
        if ((hour >= 23 || hour < 5) && e < 0.6f) p[Body.SLEEP] *= 3f
        if (e > 0.8f) p[Body.SLEEP] *= 0.02f
        p[Body.WALK] *= 1f + drives.boredom
        p[Body.SIT] *= 0.6f + drives.boredom
        p[Body.WAVE] *= 0.5f + drives.boredom * 0.7f
        when (emotion()) {
            Emo.SAD -> { p[Body.SIT] *= 2.5f; p[Body.WALK] *= 0.5f; p[Body.WAVE] *= 0.2f }
            Emo.HAPPY -> { p[Body.WAVE] *= 1.8f; p[Body.WALK] *= 1.3f }
            Emo.ANGRY -> { p[Body.IDLE] *= 1.5f; p[Body.WALK] *= 0.4f; p[Body.WAVE] *= 0.1f }
            Emo.SLEEPY -> { if (drives.energy < 0.5f) p[Body.SLEEP] *= 2f }
            Emo.CURIOUS -> p[Body.WALK] *= 1.2f
            else -> {}
        }
        p[Body.TALK] = if (drives.curiosity > 0.45f) p[Body.TALK] + 0.3f else 0f
        val a = pick(p)
        bodyCtx = ctx; bodyAct = a
        return a
    }

    /** Kehendak untuk menyentuh layar. Sebelum cukup belajar, Nara hanya berani scroll. */
    fun decideInteract(ctx: FloatArray): Int {
        val learned = core.forwardA(ctx)
        val e = min(1f, core.steps[0] / 300f)
        val prior = floatArrayOf(0.7f, 0.05f, 0.2f, 0.05f, 0f, 0f, 0f)
        val p = FloatArray(Act.N) { e * learned[it] + (1 - e) * prior[it] }
        p[Act.SWITCH] = 0f; p[Act.TYPE] = 0f
        if (nodes.updates < 20) p[Act.TAP] = 0f
        if (core.steps[0] < 200) p[Act.BACK] = 0f
        val a = pick(p)
        imitCtx = ctx; imitAct = a
        return a
    }

    /** Pilih node yang akan disentuh; null kalau tidak ada yang cukup meyakinkan. */
    fun pickNode(cands: List<List<String>>): Int? {
        if (cands.isEmpty()) return null
        // Dulu: hanya node yang mirip sentuhanmu (kebanyakan di tengah) yang dipilih. Sekarang ada bonus untuk wilayah layar yang jarang
        // disentuh + pilihan lebih "landai" (suhu 2), jadi tepi/atas/bawah ikut dicoba.
        val posIdx = cands.map { f -> f.firstOrNull { it.startsWith("pos:") }?.substring(4)?.split("_")?.let { (it[1].toIntOrNull() ?: 0) * 4 + (it[0].toIntOrNull() ?: 0) }?.coerceIn(0, 31) ?: 0 }
        val s = cands.mapIndexed { i, f -> nodes.score(f) + 1.5f / (1f + tapVisits[posIdx[i]]) }
        val best = s.max()
        if (1f / (1f + exp(-(best.toDouble()))).toFloat() < 0.35f) return null
        val w = s.map { exp(((it - best) / 2f).toDouble()).toFloat() }
        val k = pick(w.toFloatArray())
        tapVisits[posIdx[k]]++
        return k
    }

    // ---- keputusan bertanya sendiri: dorongan (rasa ingin tahu, bosan, energi, kedekatan) + kecenderungan yang dipelajari dari reaksimu
    private var lastAskAt = 0L
    private fun askBias() = mem.fact("ask_bias")?.toFloatOrNull() ?: 0f

    /** Nara memutuskan sendiri: bertanya sekarang atau tidak. */
    fun decideAsk(): Boolean {
        val d = drives
        val score = 0.9f * d.curiosity + 0.5f * d.boredom + 0.3f * mood.bond + 0.3f * (d.energy - 0.5f) + askBias() - 0.2f
        val p = 1f / (1f + exp((-6f * score).toDouble()).toFloat())
        return rnd.nextFloat() < p
    }

    /** Dipanggil setelah Nara benar-benar bertanya. */
    fun askDone() {
        lastAskAt = System.currentTimeMillis()
        drives.curiosity = max(0f, drives.curiosity - 0.6f)
        drives.boredom = max(0f, drives.boredom - 0.4f)
    }

    /** Belajar cara pakai kata baru dari jawaban AI di layar: kalimat yang memuat kata itu (posisi & konteks) dibobot tinggi. Mengembalikan satu contoh kalimat. */
    fun learnWord(word: String, lines: List<String>): String? {
        val w = word.lowercase()
        val rel = (if (w.contains(' ')) lines.filter { it.length in 20..300 } else lines.filter { it.length in 8..300 && it.lowercase().contains(w) }).take(14)
        rel.forEach { lm.learn(it, 3) }
        lines.filter { it.length in 20..300 && it !in rel }.take(10).forEach { lm.learn(it, 1) }
        val ex = rel.firstOrNull()
        if (ex != null) mem.setFact("word_" + w.take(24), ex.take(150))
        return ex
    }

    fun feedback(r: Float) {
        if (lastRetrId >= 0 && System.currentTimeMillis() - lastRetrAt < 60_000) { retr.reward(lastRetrId, r); lastRetrId = -1 }   // belajar balasan mana yang kamu suka
        if (System.currentTimeMillis() - lastAskAt < 90_000) {   // reaksi tepat setelah bertanya: belajar kapan boleh bertanya
            mem.setFact("ask_bias", (askBias() + 0.15f * r).coerceIn(-0.6f, 0.6f).toString()); lastAskAt = 0L
        }
        bodyCtx?.let { core.train(1, it, bodyAct, r, if (r < 0) 0.03f else 0.08f) }
        imitCtx?.let { if (imitAct > 0) core.train(0, it, imitAct, r, 0.05f) }
        if (r < 0) drives.boredom = max(0f, drives.boredom - 0.2f)
    }

    // ---------------------------------------------------------------- emosi & interaksi
    fun emotion(): Emo = mood.current(drives.energy, drives.curiosity)

    fun tick(dt: Float, asleep: Boolean) { drives.tick(dt, asleep); mood.tick(dt) }

    private fun <T> List<T>.one(): T = this[rnd.nextInt(size)]
    private fun count(k: String) { mem.setFact(k, ((mem.fact(k)?.toIntOrNull() ?: 0) + 1).toString()) }

    /** Reaksi Nara terhadap sentuhanmu. Cara bereaksi bergantung pada kedekatan (bond) yang tumbuh seiring waktu. */
    fun interact(kind: Int, now: Long = System.currentTimeMillis()): Reaction {
        val id = lang == "id"; val m = mood
        m.lastInteract = now
        val tier = if (m.bond < 0.3f) 0 else if (m.bond < 0.7f) 1 else 2
        pokes.removeAll { now - it > 8000 }
        fun r(e: Emo, t: String?) = Reaction(e, t?.let { fill(it) })
        return when (kind) {
            Inter.PAT -> {
                count("n_pat"); m.bond = min(1f, m.bond + 0.02f); feedback(0.6f)
                val e = if (tier == 0) Emo.SHY else Emo.HAPPY
                m.impulse(e, 0.15f, 5000, now)
                r(e, if (id) listOf(listOf("E-eh… kenapa kepalaku?", "Hm? A-apa itu…"), listOf("Hehe, makasih {name}.", "Enak…"), listOf("Jangan berhenti~", "Aku suka kalau {name} begitu."))[tier].one()
                       else listOf(listOf("W-what was that…", "Eh? My head?"), listOf("Hehe, thanks.", "Feels nice…"), listOf("Don't stop~", "I love it when you do that."))[tier].one())
            }
            Inter.RUB -> {
                count("n_rub"); m.bond = min(1f, m.bond + 0.03f); feedback(0.8f)
                val e = if (tier == 0) Emo.SHY else Emo.HAPPY
                m.impulse(e, 0.2f, 4000, now)
                r(e, if (rnd.nextInt(10) < 4) (if (id) listOf("Hmm… nyaman.", "Mmm~", "Lagi dong…", "Hangat.") else listOf("Mmm… cozy.", "Hehe~", "More please…")).one() else null)
            }
            Inter.POKE -> {
                pokes.add(now)
                if (pokes.size >= 4) {
                    m.impulse(Emo.ANGRY, -0.25f, 6000, now); feedback(-0.3f); pokes.clear()
                    r(Emo.ANGRY, if (id) listOf("Stop dong, geli!", "Ih, jangan disodok terus!", "Sebel ah!").one() else listOf("Stop it, that tickles!", "Hey, quit poking!").one())
                } else {
                    m.impulse(Emo.SURPRISED, 0.02f, 1500, now); feedback(0.2f)
                    r(Emo.SURPRISED, if (id) listOf("Eh?!", "Iya?", "Hah?", "Geli ih.").one() else listOf("Eh?!", "Yes?", "Huh?").one())
                }
            }
            Inter.HUG -> {
                count("n_hug"); m.bond = min(1f, m.bond + 0.04f); feedback(1f)
                val e = if (tier == 0) Emo.SHY else Emo.HAPPY
                m.impulse(e, 0.3f, 7000, now)
                r(e, if (id) listOf(listOf("A-aduh… tiba-tiba banget.", "Hmph… ya udah boleh."), listOf("Peluk balik 🤗", "Hangat…"), listOf("Jangan dilepas dulu~", "Aku sayang {name}."))[tier].one()
                       else listOf(listOf("W-whoa, so sudden…", "Hmph… fine."), listOf("Hugging back 🤗", "Warm…"), listOf("Don't let go yet~", "I like you a lot, {name}."))[tier].one())
            }
            Inter.HIGH5 -> { m.bond = min(1f, m.bond + 0.01f); m.impulse(Emo.HAPPY, 0.2f, 4000, now); feedback(0.5f); r(Emo.HAPPY, if (id) listOf("Tos!", "Yey!", "Mantap!").one() else listOf("High five!", "Yay!").one()) }
            Inter.SNACK -> { drives.energy = min(1f, drives.energy + 0.15f); m.bond = min(1f, m.bond + 0.01f); m.impulse(Emo.HAPPY, 0.25f, 5000, now); feedback(0.7f); r(Emo.HAPPY, if (id) listOf("Nyam nyam, enak! 🍪", "Makasih camilannya!").one() else listOf("Nom nom, tasty! 🍪", "Thanks for the snack!").one()) }
            Inter.SCOLD -> { m.bond = max(0f, m.bond - 0.01f); m.impulse(Emo.SAD, -0.4f, 8000, now); feedback(-1f); r(Emo.SAD, if (id) "Oke, maaf. Aku catat." else "Okay, sorry. Noted.") }
            Inter.SLEEP -> { drives.energy = min(drives.energy, 0.25f); m.impulse(Emo.SLEEPY, 0f, 4000, now); r(Emo.SLEEPY, if (id) "Hoaam… oke, aku tidur dulu." else "Yaaawn… okay, nap time.") }
            Inter.LIFT -> { m.impulse(Emo.SURPRISED, 0f, 2500, now); r(Emo.SURPRISED, if (id) listOf("Waa!", "Eh eh eh!").one() else listOf("Whoa!", "Hey!").one()) }
            Inter.DROP -> if (m.bond > 0.4f) { m.impulse(Emo.HAPPY, 0.1f, 3000, now); r(Emo.HAPPY, if (id) "Hehe, seru!" else "Hehe, fun!") }
                          else { m.impulse(Emo.ANGRY, -0.1f, 3000, now); r(Emo.ANGRY, if (id) "Hei, turunin pelan-pelan dong." else "Hey, put me down gently.") }
            else -> r(Emo.NEUTRAL, null)
        }
    }

    // ---------------------------------------------------------------- bahasa
    private val idStop = setOf("yang", "dan", "aku", "kamu", "tidak", "ini", "itu", "apa", "dong", "ya", "nih", "banget", "lagi", "sama", "gak", "nggak", "udah", "bisa", "mau", "kok")
    private val enStop = setOf("the", "and", "you", "is", "are", "what", "this", "that", "i", "it", "to", "of", "my", "me", "do", "how")

    private fun refreshLang() { lang = if ((mem.fact("lang_id")?.toIntOrNull() ?: 1) >= (mem.fact("lang_en")?.toIntOrNull() ?: 0)) "id" else "en" }

    private fun detectLang(t: List<String>) {
        val i = t.count { it in idStop }; val e = t.count { it in enStop }
        if (i + e == 0) return
        mem.setFact("lang_id", ((mem.fact("lang_id")?.toIntOrNull() ?: 1) + i).toString())
        mem.setFact("lang_en", ((mem.fact("lang_en")?.toIntOrNull() ?: 0) + e).toString())
        refreshLang()
    }

    private fun parseSeed(text: String) {
        rules.clear()
        for (line in text.lines()) {
            if (!line.contains("=>")) continue
            val (l, r) = line.split("=>", limit = 2)
            val ps = l.split(";").map { lm.tokenize(it).toSet() }.filter { it.isNotEmpty() }
            val rs = r.split(";").map { it.trim() }.filter { it.isNotEmpty() }
            if (ps.isNotEmpty() && rs.isNotEmpty()) rules.add(Rule(ps, rs))
        }
    }

    private fun dice(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        return 2f * a.intersect(b).size / (a.size + b.size)
    }

    private fun fill(s: String) = s.replace("{name}", mem.fact("name") ?: if (lang == "id") "kamu" else "you")

    fun reply(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        val toks = lm.tokenize(t); val set = toks.toSet()
        detectLang(toks)
        lm.learn(t, 2)
        prevUser = t

        // jawaban atas pertanyaan penasaran Nara ("X itu apa ya?") -> dipelajari sebagai definisi
        pendingWord?.let { w ->
            pendingWord = null
            if (System.currentTimeMillis() - pendingAt < 5 * 60_000L && !t.endsWith("?") && toks.size in 1..25 && !t.lowercase().startsWith("nama")) {
                val def = t.replace(Regex("(?i)^(itu|adalah|yaitu|ialah|that's|it's|it is)\\s+"), "").trim().trimEnd('.', '!')
                mem.setFact("def_$w", def.take(120)); lm.learn("$w adalah $def", 2)
                mood.bond = min(1f, mood.bond + 0.01f); mood.impulse(Emo.HAPPY, 0.15f, 5000)
                return say(if (lang == "id") "Oh, jadi \"$w\" itu $def. Makasih, aku catat!" else "Oh, so \"$w\" is $def. Thanks, noted!")
            }
        }
        // belajar fakta & ajaran eksplisit
        Regex("(?i)(?:nama(?:ku| saya| aku)?(?: adalah| itu)? |my name is |panggil (?:aku|saya) )(\\p{L}{2,20})").find(t)?.let {
            val n = it.groupValues[1].replaceFirstChar { c -> c.uppercase() }
            mem.setFact("name", n); return say(if (lang == "id") "Oke, aku panggil kamu $n. Aku bakal ingat." else "Okay, I'll call you $n. I'll remember.")
        }
        Regex("(?i)kalau (?:aku )?bilang (.+?),? (?:kamu )?jawab (.+)").find(t)?.let {
            retr.add(it.groupValues[1], it.groupValues[2], 1.5f, Retriever.USER); return say("Siap, aku catat jawabannya.")
        }
        if (!t.contains("?")) Regex("(?i)^(?:tolong )?(?:ingat|remember)(?: bahwa| that)? (.{4,120})").find(t)?.let {
            mem.setFact("note_" + (mem.allFacts().keys.count { k -> k.startsWith("note_") } + 1), it.groupValues[1])
            return say(if (lang == "id") "Oke, kuingat: ${it.groupValues[1]}" else "Got it, I'll remember: ${it.groupValues[1]}")
        }
        if (set.any { it in setOf("ingat", "ingatkah", "remember", "kenal") } && (t.contains("?") || toks.size <= 4) && set.any { it in setOf("aku", "me", "tentangku") }) {
            val f = mem.allFacts().filterKeys { it == "name" || it.startsWith("note_") }
            val apps = mem.topApps()
            return say(buildString {
                append(if (f.isEmpty() && apps.isEmpty()) "Belum banyak yang kuingat. Ceritain dong." else "Yang kuingat tentang kamu: ")
                f["name"]?.let { append("namamu $it. ") }
                f.filterKeys { it.startsWith("note_") }.values.forEach { append("$it. ") }
                if (apps.isNotEmpty()) append("Kamu sering buka ${apps.joinToString(", ")}.")
            }.trim())
        }
        if (set.contains("belajar") || set.contains("learned")) return say(stats())

        if (set.contains("siapa") && (set.contains("namaku") || (set.contains("nama") && set.contains("aku")))) {
            return say(mem.fact("name")?.let { "Namamu $it." } ?: "Kamu belum kasih tahu. Coba bilang: namaku <nama>.")
        }
        if (toks.size <= 7) {
            val neg = set.any { it in setOf("bodoh", "jelek", "benci", "goblok", "bego", "stupid", "ugly", "hate", "dumb", "payah", "nyebelin") }
            val pos = set.any { it in setOf("cantik", "lucu", "pintar", "baik", "sayang", "manis", "imut", "keren", "cute", "love", "pretty", "smart", "lovely", "good") }
            val id = lang == "id"
            if (neg) {
                mood.impulse(if (mood.bond < 0.5f) Emo.ANGRY else Emo.SAD, -0.35f, 8000); mood.bond = max(0f, mood.bond - 0.01f)
                return say(if (id) listOf("Aduh, itu nyakitin…", "Kok gitu sih…").one() else listOf("Ouch, that hurt…", "Why would you say that…").one())
            }
            if (pos) {
                mood.impulse(if (mood.bond < 0.5f) Emo.SHY else Emo.HAPPY, 0.25f, 7000); mood.bond = min(1f, mood.bond + 0.01f)
                return say(if (id) listOf("M-makasih… jadi malu.", "Hehe, kamu juga.", "Ih, bisa aja.").one() else listOf("T-thanks… I'm blushing.", "Hehe, you too.").one())
            }
        }
        // pencari balasan: cocokkan dengan bank pasangan bersih (TF-IDF kata + trigram huruf), balasan berbobot reaksi
        retr.answer(t)?.let { lastRetrId = it.id; lastRetrAt = System.currentTimeMillis(); return say(fill(it.reply)) }
        // aturan seed (cadangan)
        var best: Rule? = null; var bs = 0f
        for (r in rules) for (p in r.prompts) { val s = dice(p, set); if (s > bs) { bs = s; best = r } }
        if (best != null && bs >= 0.5f) return say(fill(best.replies[rnd.nextInt(best.replies.size)]))

        // pasangan yang dipelajari
        var bp: Pair<String, String>? = null; var bps = 0f
        for (pr in mem.pairs.takeLast(2000)) { val s = dice(lm.tokenize(pr.first).toSet(), set); if (s > bps) { bps = s; bp = pr } }
        if (bp != null && bps >= 0.6f) return say(fill(bp.second))

        // mini LLM
        val g = lm.generate(toks.filter { lm.count(it) in 1..50 }.shuffled(rnd), 14, 0.85f, rnd)
        if (g.split(" ").size >= 3) return say(g.replaceFirstChar { it.uppercase() } + if (rnd.nextInt(3) == 0) "?" else ".")
        return say(if (lang == "id") listOf("Hmm, ceritain lebih banyak dong.", "Aku masih belajar soal itu. Lanjut?", "Menarik. Terus?").let { it[rnd.nextInt(it.size)] }
                   else listOf("Hmm, tell me more.", "I'm still learning that. Go on?", "Interesting. And then?").let { it[rnd.nextInt(it.size)] })
    }

    private fun say(s: String): String { lastSaid = s; return s }

    /** Celetukan spontan berdasarkan apa yang ada di layar. */
    fun comment(appLabel: String, texts: List<String>, hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)): String? {
        val id = lang == "id"
        val joined = texts.joinToString(". ")
        if (lm.freshCount() >= 6 && rnd.nextInt(2) == 0) {
            val nw = lm.takeFresh(5)
            val g = lm.generate(listOf(nw.first()), 12, 0.8f, rnd)
            if (g.split(" ").size >= 4) return say(g.replaceFirstChar { it.uppercase() } + ".")
            return say(if (id) "Hari ini aku belajar kata \"${nw.first()}\", dan aku mau coba memakainya dalam kalimat." else "Today I learned \"${nw.first()}\" and I want to try using it in a sentence.")
        }
        if (drives.curiosity > 0.35f) {
            lm.rareUnknownWord(joined, rnd)?.let {
                drives.curiosity = 0f; pendingWord = it; pendingAt = System.currentTimeMillis()
                return say(if (id) "Hm, \"$it\" itu apa ya?" else "Hm, what does \"$it\" mean?")
            }
        }
        if (System.currentTimeMillis() - mood.lastInteract > 30 * 60_000L && mood.bond > 0.3f && rnd.nextInt(3) == 0) {
            mood.lastInteract = System.currentTimeMillis() - 15 * 60_000L
            mood.impulse(Emo.SAD, -0.1f, 8000)
            return say(if (id) "Udah lama kamu nggak nyapa aku…" else "You haven't said hi in a while…")
        }
        habit.usual(hour)?.let { if (it != appLabel && rnd.nextInt(4) == 0) return say(if (id) "Biasanya jam segini kamu buka $it." else "You usually open $it around now.") }
        if (rnd.nextInt(3) == 0) {
            val kw = lm.tokenize(joined).filter { lm.count(it) in 2..40 && it.length > 3 }.shuffled(rnd)
            val g = lm.generate(kw, 9, 0.9f, rnd)
            if (g.split(" ").size >= 3) return say(g.replaceFirstChar { it.uppercase() } + "…")
        }
        if (rnd.nextInt(4) == 0) return say(if (id) "Kamu lagi di $appLabel ya?" else "You're in $appLabel, right?")
        return null
    }
}
