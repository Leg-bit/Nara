package com.nara.companion.brain;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Jaringan nilai catur kecil: 768 fitur (jenis bidak x kotak) -> 16 tanh -> 1.
 * Nilai posisi = tanh(keluaran jaringan + materi/4): jaringan hanya mempelajari "selisih" di atas hitungan materi,
 * jadi langsung kuat sejak awal dan terus membaik lewat latihan (TD ke hasil akhir) melawan Mittens.
 */
public final class ChessNet {
    private static final int NIN = 768, NH = 16, MAGIC = 0x43484E32;
    private final float[] w1 = new float[NIN * NH], b1 = new float[NH], w2 = new float[NH];
    private float b2 = 0f;
    public int games, wins, losses, draws;

    public ChessNet() { Random r = new Random(5); for (int i = 0; i < w1.length; i++) w1[i] = (float) (r.nextGaussian() * 0.05); for (int j = 0; j < NH; j++) w2[j] = (float) (r.nextGaussian() * 0.1); }

    private int[] active(Chess c, int[] out) {
        int k = 0;
        for (int sq = 0; sq < 64; sq++) { int p = c.b[sq]; if (p != 0) out[k++] = ((Math.abs(p) - 1) + (p < 0 ? 6 : 0)) * 64 + sq; }
        return java.util.Arrays.copyOf(out, k);
    }

    private float forward(int[] act, float[] h) {
        float o = b2;
        for (int j = 0; j < NH; j++) {
            float s = b1[j];
            for (int f : act) s += w1[f * NH + j];
            h[j] = (float) Math.tanh(s); o += w2[j] * h[j];
        }
        return o;
    }

    /** Nilai dari sudut pandang putih, -1..1. */
    public float value(Chess c) {
        float[] h = new float[NH];
        float o = forward(active(c, new int[32]), h);
        return (float) Math.tanh(o + c.material() / 4f);
    }

    /** Langkah terbaik (kedalaman 1 atau 2). explore: peluang memilih langkah acak dari 3 teratas (untuk latihan). */
    public int best(Chess c, int depth, float explore, Random rnd) {
        int[] mv = c.moves(false);
        if (mv.length == 0) return -1;
        float[] sc = new float[mv.length];
        for (int i = 0; i < mv.length; i++) {
            Chess d = c.copy(); d.apply(mv[i]);
            float s;
            if (depth <= 1) s = value(d) * c.side;
            else {
                int[] rep = d.moves(false);
                if (rep.length == 0) s = d.inCheck(d.side) ? 1f : 0f;
                else {
                    float worst = 2f;
                    for (int r : rep) { Chess e = d.copy(); e.apply(r); float v = value(e) * c.side; if (v < worst) worst = v; }
                    s = worst;
                }
            }
            sc[i] = s + rnd.nextFloat() * 1e-4f;
        }
        int[] order = new int[mv.length];
        for (int i = 0; i < order.length; i++) order[i] = i;
        for (int i = 0; i < Math.min(3, order.length); i++) for (int j = i + 1; j < order.length; j++) if (sc[order[j]] > sc[order[i]]) { int t = order[i]; order[i] = order[j]; order[j] = t; }
        if (explore > 0f && rnd.nextFloat() < explore) return mv[order[rnd.nextInt(Math.min(3, order.length))]];
        return mv[order[0]];
    }

    /** Satu langkah SGD ke target (putih menang +1 / kalah -1 / seri 0). */
    private void trainOne(Chess c, float target, float lr) {
        int[] act = active(c, new int[32]);
        float[] h = new float[NH];
        float o = forward(act, h);
        float v = (float) Math.tanh(o + c.material() / 4f);
        float dpre = (v - target) * (1f - v * v);
        for (int j = 0; j < NH; j++) {
            float dh = dpre * w2[j] * (1f - h[j] * h[j]);
            w2[j] = clip(w2[j] - lr * dpre * h[j]);
            b1[j] -= lr * dh;
            for (int f : act) w1[f * NH + j] = clip(w1[f * NH + j] - lr * dh);
        }
        b2 -= lr * dpre;
    }
    private static float clip(float x) { return x > 3f ? 3f : (x < -3f ? -3f : x); }

    /** Latih dari satu partai: tiap posisi ditarik ke hasil akhir (diskon 0.97 per langkah dari akhir). */
    public void learn(List<Chess> seen, int result, float lr) {
        float z = result == 1 ? 1f : (result == -1 ? -1f : 0f);
        int T = seen.size();
        for (int t = 0; t < T; t++) trainOne(seen.get(t), z * (float) Math.pow(0.97, T - 1 - t), lr);
    }

    public void record(int result) { games++; if (result == 1) wins++; else if (result == -1) losses++; else draws++; }

    /**
     * Latihan di latar belakang: separuh partai melawan Mittens, separuh bermain melawan dirinya sendiri (kedua warna),
     * kedalaman 2 dengan sedikit langkah acak. Hanya partai yang berakhir skakmat yang dipelajari (seri/batas langkah tidak,
     * karena itu hanya akan menghapus pengetahuan materi).
     */
    public String selfTrain(int n, Random rnd) {
        Mittens m = new Mittens(rnd.nextLong());
        int w = 0, l = 0, d = 0, learned = 0;
        for (int g = 0; g < n; g++) {
            boolean vsMittens = (g % 2 == 0);
            Chess c = Chess.start(); List<Chess> seen = new ArrayList<Chess>(); int res;
            while (true) {
                int[] lg = c.moves(false);
                res = c.result(lg, 160);
                if (res != 0) break;
                int mv = (c.side == 1 || !vsMittens) ? best(c, 2, 0.15f, rnd) : m.pick(c);
                c.apply(mv); seen.add(c.copy());
            }
            if (res == 1 || res == -1) { learn(seen, res, 0.004f); learned++; }
            if (vsMittens) { record(res); if (res == 1) w++; else if (res == -1) l++; else d++; }
        }
        return "melawan Mittens: " + w + " menang, " + l + " kalah, " + d + " seri; " + learned + " partai tamat dipelajari";
    }

    public String stats() { return games == 0 ? "belum pernah main" : wins + "M-" + losses + "K-" + draws + "S dari " + games + " partai (menang " + (wins * 100 / games) + "%)"; }

    public void save(File f) throws IOException {
        DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
        try {
            o.writeInt(MAGIC); o.writeInt(games); o.writeInt(wins); o.writeInt(losses); o.writeInt(draws);
            for (float v : w1) o.writeFloat(v);
            for (float v : b1) o.writeFloat(v);
            for (float v : w2) o.writeFloat(v);
            o.writeFloat(b2);
        } finally { o.close(); }
    }

    public void load(File f) {
        if (!f.exists()) return;
        try {
            DataInputStream i = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));
            try {
                if (i.readInt() != MAGIC) return;
                games = i.readInt(); wins = i.readInt(); losses = i.readInt(); draws = i.readInt();
                for (int k = 0; k < w1.length; k++) w1[k] = i.readFloat();
                for (int k = 0; k < NH; k++) b1[k] = i.readFloat();
                for (int k = 0; k < NH; k++) w2[k] = i.readFloat();
                b2 = i.readFloat();
            } finally { i.close(); }
        } catch (IOException e) { /* berkas rusak: pakai bobot awal */ }
    }
}
