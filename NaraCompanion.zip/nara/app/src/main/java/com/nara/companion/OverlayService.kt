package com.nara.companion

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.nara.companion.brain.Act
import com.nara.companion.brain.Body
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.max

/** Tubuh Nara: karakter humanoid yang berjalan di atas semua aplikasi dan bertindak dari dorongan internalnya. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        const val CH = "nara_main"
        const val A_PAUSE = "com.nara.companion.PAUSE"
        const val A_STOP = "com.nara.companion.STOP"
        private const val TOUCH = 10
    }

    private val h = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var img: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private var cursorBmp: Bitmap? = null
    private val sprites = HashMap<String, List<Bitmap>>()
    private val flipped = HashMap<String, List<Bitmap>>()
    private var sw = 0; private var sh = 0; private var density = 1f
    private var state = Body.IDLE
    private var stateUntil = 0L
    private var facingRight = true
    private var px = 60f; private var tx = 60f
    private var yMargin = 0
    private var frame = 0
    private var talkUntil = 0L; private var blinkUntil = 0L
    private var lastInteract = 0L; private var lastComment = 0L; private var lastIdleTrain = 0L; private var lastSave = 0L
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startFg(false)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density
        loadSprites()
        buildViews()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID") }
        ready = true
        val now = SystemClock.uptimeMillis()
        lastInteract = now; lastComment = now; lastSave = now
        h.post(animTick); h.postDelayed(thinkTick, 1000)
        h.postDelayed({ speak(if (NaraApp.brain.lang == "id") "Hai${NaraApp.brain.mem.fact("name")?.let { " $it" } ?: ""}! Aku sudah di sini." else "Hi! I'm here.") }, 800)
    }

    // ------------------------------------------------------------ notifikasi
    private fun startFg(paused: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Nara", NotificationManager.IMPORTANCE_LOW))
        fun svc(a: String) = PendingIntent.getService(this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("chat", true), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(if (paused) "Nara dijeda" else "Nara aktif").setContentText("Ketuk untuk ngobrol")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, if (paused) "Lanjut" else "Jeda", svc(A_PAUSE)).build())
            .addAction(Notification.Action.Builder(0, "Stop", svc(A_STOP)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 0x40000000 /* FOREGROUND_SERVICE_TYPE_SPECIAL_USE */) else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_PAUSE -> { Shared.paused = !Shared.paused; startFg(Shared.paused); if (ready) speak(if (Shared.paused) "Oke, aku diam dulu." else "Aku lanjut ya.") }
            A_STOP -> { stopSelf() }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------ tampilan
    private fun loadSprites() {
        val scale = (sh * Prefs.sizePct / 100f) / 800f   // tinggi karakter = % tinggi layar (kanvas sprite 800px)
        val groups = mapOf("idle" to 2, "blink" to 1, "talk" to 2, "walk" to 4, "wave" to 3, "sit" to 2, "sleep" to 1, "touch" to 2)
        for ((g, n) in groups) {
            val l = ArrayList<Bitmap>(); val f = ArrayList<Bitmap>()
            for (i in 0 until n) assets.open("sprites/${g}_$i.png").use { st ->
                val b = BitmapFactory.decodeStream(st)
                val s = Bitmap.createScaledBitmap(b, max(1, (b.width * scale).toInt()), max(1, (b.height * scale).toInt()), true)
                l.add(s); f.add(Bitmap.createBitmap(s, 0, 0, s.width, s.height, Matrix().apply { preScale(-1f, 1f) }, true))
            }
            sprites[g] = l; flipped[g] = f
        }
        cursorBmp = assets.open("sprites/cursor.png").use { BitmapFactory.decodeStream(it) }
    }

    private fun buildViews() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bubble = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; visibility = View.GONE
            setPadding((12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt())
            maxWidth = (sw * 0.6f).toInt()
            background = GradientDrawable().apply { cornerRadius = 16 * density; setColor(Color.argb(225, 20, 24, 44)); setStroke((1.5f * density).toInt(), Color.rgb(70, 212, 224)) }
        }
        img = ImageView(this)
        root.addView(bubble, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(img, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        img.setImageBitmap(sprites["idle"]!![0])
        yMargin = (sh * 0.045f).toInt()
        px = (sw * 0.1f)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = px.toInt(); y = yMargin }
        wm.addView(root, lp)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { poke(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean { scold(); return true }
            override fun onLongPress(e: MotionEvent) {
                startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("chat", true))
            }
        })
        var lastX = 0f; var lastY = 0f
        img.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX = ev.rawX; lastY = ev.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - lastX; val dy = ev.rawY - lastY
                    if (abs(dx) + abs(dy) > 3f * density) {
                        px += dx; yMargin = (yMargin - dy).toInt().coerceIn(0, sh - 200); applyPos()
                        lastX = ev.rawX; lastY = ev.rawY
                    }
                }
            }
            gd.onTouchEvent(ev)
        }
    }

    private fun poke() {
        NaraApp.brain.feedback(0.5f)
        state = Body.WAVE; stateUntil = SystemClock.uptimeMillis() + 1800
        val l = if (NaraApp.brain.lang == "id") listOf("Hehe!", "Iya?", "Aku di sini kok.", "Geli ih.") else listOf("Hehe!", "Yes?", "I'm right here.")
        speak(l[rnd.nextInt(l.size)])
    }

    private fun scold() {
        NaraApp.brain.feedback(-1f)
        state = Body.IDLE; stateUntil = SystemClock.uptimeMillis() + 5000
        speak(if (NaraApp.brain.lang == "id") "Oke, maaf. Aku catat." else "Okay, sorry. Noted.")
    }

    fun speak(t: String) {
        h.post {
            if (!ready) return@post
            bubble.text = t; bubble.visibility = View.VISIBLE
            talkUntil = SystemClock.uptimeMillis() + (1200 + t.length * 55L).coerceAtMost(6000)
            h.removeCallbacks(hideBubble); h.postDelayed(hideBubble, (2500 + t.length * 70L).coerceAtMost(9000))
            if (Prefs.tts) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nara")
            applyPos()
        }
    }
    private val hideBubble = Runnable { bubble.visibility = View.GONE }

    private fun winWidth() = if (root.width > 0) root.width else (sw * 0.3f).toInt()

    private fun applyPos() {
        px = px.coerceIn(0f, max(0f, (sw - winWidth()).toFloat()))
        lp.x = px.toInt(); lp.y = yMargin
        if (root.isAttachedToWindow) try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        val hgt = root.height
        Shared.charRect = Rect(lp.x, sh - lp.y - hgt, lp.x + winWidth(), sh - lp.y)
    }

    // ------------------------------------------------------------ animasi (±8 fps)
    private val animTick = object : Runnable { override fun run() { try { stepAnim() } catch (_: Exception) {}; h.postDelayed(this, 130) } }

    private fun stepAnim() {
        val now = SystemClock.uptimeMillis(); frame++
        if (state == Body.WALK) {
            val dir = if (tx > px) 1 else -1
            facingRight = dir > 0
            px += dir * sw * 0.0156f
            if (abs(tx - px) < sw * 0.02f) { state = Body.IDLE; stateUntil = now + 2000 + rnd.nextInt(3000) }
            applyPos()
        }
        val talking = now < talkUntil
        val name = when (state) {
            Body.WALK -> "walk"; Body.SIT -> "sit"; Body.SLEEP -> "sleep"; Body.WAVE -> "wave"; TOUCH -> "touch"
            else -> if (talking) "talk" else if (now < blinkUntil) "blink" else "idle"
        }
        if (name == "idle" && rnd.nextInt(40) == 0) blinkUntil = now + 180
        val list = (if (facingRight) sprites else flipped)[name] ?: return
        val div = when (name) { "idle" -> 8; "walk" -> 2; "wave" -> 2; "talk" -> 2; "touch" -> 3; "sit" -> 6; else -> 1 }
        var idx = (frame / div) % list.size
        if (name == "sit" && !talking) idx = 0
        img.setImageBitmap(list[idx])
    }

    // ------------------------------------------------------------ kehendak (1x/detik)
    private val thinkTick = object : Runnable { override fun run() { try { think() } catch (_: Exception) {}; h.postDelayed(this, 1000) } }

    private fun think() {
        val now = SystemClock.uptimeMillis()
        val brain = NaraApp.brain
        val dm = resources.displayMetrics; sw = dm.widthPixels; sh = dm.heightPixels
        brain.drives.tick(1f, state == Body.SLEEP)
        if (now - lastSave > 60_000) { lastSave = now; brain.save() }
        if (Shared.paused) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return

        if (now >= stateUntil) chooseBody(now)
        if (state == Body.SLEEP && brain.drives.energy > 0.95f) { state = Body.IDLE; stateUntil = now + 2000 }

        val interval = when (Prefs.autonomy) { 1 -> 90_000L; 2 -> 35_000L; 3 -> 14_000L; else -> Long.MAX_VALUE }
        if (Prefs.autonomy > 0 && now - lastInteract >= interval && state != Body.SLEEP) {
            lastInteract = now + rnd.nextInt(5000)
            tryInteract()
        }
        val ctx by lazy { brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa) }
        if (now - Shared.lastUserTouch > 20_000 && now - lastIdleTrain > 20_000 && Shared.curPkg.isNotEmpty()) { lastIdleTrain = now; brain.observeIdle(ctx) }
        if (now - lastComment > 120_000 && bubble.visibility != View.VISIBLE && state != Body.SLEEP) {
            lastComment = now + rnd.nextInt(60_000)
            brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
        }
    }

    private fun chooseBody(now: Long) {
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideBody(ctx)) {
            Body.WALK -> {
                val maxX = max(1f, (sw - winWidth()).toFloat())
                var t = rnd.nextFloat() * maxX
                if (abs(t - px) < sw * 0.15f) t = if (px < maxX / 2) maxX * 0.85f else maxX * 0.1f
                tx = t; state = Body.WALK; stateUntil = now + 20_000
            }
            Body.SIT -> { state = Body.SIT; stateUntil = now + 8_000 + rnd.nextInt(12_000) }
            Body.SLEEP -> { state = Body.SLEEP; stateUntil = now + 30_000 }
            Body.WAVE -> { state = Body.WAVE; stateUntil = now + 2500 }
            Body.TALK -> {
                state = Body.IDLE; stateUntil = now + 3000
                NaraApp.brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
            }
            else -> { state = Body.IDLE; stateUntil = now + 3000 + rnd.nextInt(5000) }
        }
    }

    // ------------------------------------------------------------ menyentuh layar
    private fun tryInteract() {
        val svc = ScreenAccessService.instance ?: return
        val now = SystemClock.uptimeMillis()
        if (!svc.canAct() || now - Shared.lastUserTouch < 8000) return
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideInteract(ctx)) {
            Act.DOWN -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(true) }
            Act.UP -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(false) }
            Act.TAP -> {
                val cands = svc.candidates()
                val i = brain.pickNode(cands.map { it.feats }) ?: return
                val c = cands[i]
                reach(c.cx, c.cy) { svc.tap(c.cx, c.cy) }
            }
            Act.BACK -> reach(sw * 0.08f, sh * 0.5f) { svc.back() }
        }
    }

    private fun reach(x1: Float, y1: Float, action: () -> Unit) {
        state = TOUCH; stateUntil = SystemClock.uptimeMillis() + 2500
        facingRight = x1 >= lp.x + winWidth() / 2f
        val x0 = lp.x + winWidth() * (if (facingRight) 0.85f else 0.15f)
        val y0 = sh - lp.y - img.height * 0.55f
        val bmp = cursorBmp ?: run { action(); return }
        val size = (48 * density).toInt()
        val c = ImageView(this).apply { setImageBitmap(bmp) }
        val clp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (x0 - size / 2).toInt(); y = (y0 - size / 2).toInt() }
        try { wm.addView(c, clp) } catch (_: Exception) { action(); return }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener {
                val t = it.animatedValue as Float
                clp.x = (x0 + (x1 - x0) * t - size / 2).toInt(); clp.y = (y0 + (y1 - y0) * t - size / 2).toInt()
                try { wm.updateViewLayout(c, clp) } catch (_: Exception) {}
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    action()
                    h.postDelayed({ try { wm.removeView(c) } catch (_: Exception) {} }, 450)
                }
            })
            start()
        }
    }

    override fun onDestroy() {
        ready = false
        instance = null
        h.removeCallbacksAndMessages(null)
        try { if (::root.isInitialized) wm.removeView(root) } catch (_: Exception) {}
        try { NaraApp.brain.save() } catch (_: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
