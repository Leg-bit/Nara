package com.nara.companion

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.nara.companion.brain.Act
import com.nara.companion.brain.Body
import com.nara.companion.brain.Emo
import com.nara.companion.brain.Chess
import com.nara.companion.brain.Inter
import com.nara.companion.brain.Nlp
import org.json.JSONObject
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Tubuh Nara: karakter humanoid yang berjalan di atas semua aplikasi dan bertindak dari dorongan internalnya. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        const val CH = "nara_main"
        const val A_PAUSE = "com.nara.companion.PAUSE"
        const val A_STOP = "com.nara.companion.STOP"
        const val A_CHAT = "com.nara.companion.CHAT"
        private const val TOUCH = 10
        private const val WALK_DIST = 0.62f   // jarak tempuh satu siklus jalan (x tinggi karakter) -> kaki tidak meluncur
        private const val RUN_DIST = 1.25f
    }

    private val h = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var img: CharacterView
    private var menu: LinearLayout? = null
    private var spriteScale = 1f
    private var running = false
    private var panel: LinearLayout? = null
    private var panelBox: LinearLayout? = null
    private var panelScroll: ScrollView? = null
    private var panelInput: EditText? = null
    private val history = ArrayList<Pair<Boolean, String>>()
    private fun dp(v: Int) = (v * density).toInt()
    private var lastHeart = 0L
    private lateinit var lp: WindowManager.LayoutParams
    private var cursorBmp: Bitmap? = null
    private val sprites = HashMap<String, List<Bitmap>>()
    private val flipped = HashMap<String, List<Bitmap>>()
    private var sw = 0; private var sh = 0; private var density = 1f
    private var state = Body.IDLE
    private var stateUntil = 0L
    private var facingRight = true
    private var px = 60f; private var tx = 60f
    private var yMargin = 0
    private var frame = 0
    private var talkUntil = 0L; private var blinkUntil = 0L
    private var lastInteract = 0L; private var lastComment = 0L; private var lastIdleTrain = 0L; private var lastSave = 0L
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startFg(false)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density
        loadSprites()
        buildViews()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID") }
        ready = true
        val now = SystemClock.uptimeMillis()
        lastInteract = now; lastComment = now; lastSave = now
        h.post(animTick); h.postDelayed(thinkTick, 1000)
        h.postDelayed({ speak(if (NaraApp.brain.lang == "id") "Hai${NaraApp.brain.mem.fact("name")?.let { " $it" } ?: ""}! Aku sudah di sini." else "Hi! I'm here.") }, 800)
    }

    // ------------------------------------------------------------ notifikasi
    private fun startFg(paused: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Nara", NotificationManager.IMPORTANCE_LOW))
        fun svc(a: String) = PendingIntent.getService(this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = svc(A_CHAT)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(if (paused) "Nara dijeda" else "Nara aktif").setContentText("Ketuk untuk membalas / ngobrol")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, if (paused) "Lanjut" else "Jeda", svc(A_PAUSE)).build())
            .addAction(Notification.Action.Builder(0, "Stop", svc(A_STOP)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 0x40000000 /* FOREGROUND_SERVICE_TYPE_SPECIAL_USE */) else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_PAUSE -> { Shared.paused = !Shared.paused; startFg(Shared.paused); if (ready) speak(if (Shared.paused) "Oke, aku diam dulu." else "Aku lanjut ya.") }
            A_STOP -> { stopSelf() }
            A_CHAT -> h.post { openChat() }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------ tampilan
    private fun loadSprites() {
        val groups = mapOf("idle" to 8, "sit" to 8, "walk_L" to 9, "walk_R" to 9, "run_L" to 9, "run_R" to 9, "happy" to 8, "annoyed" to 8)
        val refH = assets.open("sprites/idle_0.png").use { BitmapFactory.decodeStream(it).height }
        val scale = (sh * Prefs.sizePct / 100f) / refH   // tinggi karakter = % tinggi layar
        spriteScale = scale
        for ((g, n) in groups) {
            val l = ArrayList<Bitmap>()
            for (i in 0 until n) assets.open("sprites/${g}_$i.png").use { st ->
                val b = BitmapFactory.decodeStream(st)
                l.add(scaleQ(b, max(1, (b.width * scale).toInt()), max(1, (b.height * scale).toInt())))
            }
            sprites[g] = l
        }
        cursorBmp = assets.open("sprites/cursor.png").use { BitmapFactory.decodeStream(it) }
    }

    /** Perkecil bertahap (maks 2x per langkah, rata-rata piksel) supaya sprite HD tetap halus dan tidak bergerigi. */
    private fun scaleQ(b: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = b
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== b) cur.recycle()
            cur = n
        }
        val out = if (cur.width == tw && cur.height == th) cur else Bitmap.createScaledBitmap(cur, tw, th, true)
        if (cur !== b && cur !== out) cur.recycle()
        if (b !== out) b.recycle()
        return out
    }

    /** Daftar frame; versi cermin dibuat sekali saat pertama dibutuhkan (hemat memori). */
    private fun frames(name: String, right: Boolean): List<Bitmap>? {
        val l = sprites[name] ?: return null
        if (right) return l
        return flipped.getOrPut(name) { l.map { Bitmap.createBitmap(it, 0, 0, it.width, it.height, Matrix().apply { preScale(-1f, 1f) }, true) } }
    }

    private fun buildViews() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bubble = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; visibility = View.GONE
            setPadding((12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt())
            maxWidth = (sw * 0.6f).toInt()
            background = GradientDrawable().apply { cornerRadius = 16 * density; setColor(Color.argb(225, 20, 24, 44)); setStroke((1.5f * density).toInt(), Color.rgb(70, 212, 224)) }
        }
        bubble.setOnClickListener { openChat() }
        img = CharacterView(this)
        root.addView(bubble, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val frame = FrameLayout(this)
        frame.addView(img, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        val chip = TextView(this).apply {
            text = "💬"; textSize = 15f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(205, 20, 24, 44)); setStroke(dp(1), Color.rgb(70, 212, 224)) }
            setOnClickListener { openChat() }
        }
        frame.addView(chip, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END))
        root.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        img.show(sprites["idle"]!![0], null, 0, 0)
        yMargin = (sh * 0.045f).toInt()
        px = (sw * 0.1f)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = px.toInt(); y = yMargin }
        wm.addView(root, lp)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { doInteract(if (isHead(e.y)) Inter.PAT else Inter.POKE); return true }
            override fun onLongPress(e: MotionEvent) { showMenu() }
        })
        val ox = Osc(); val oy = Osc()
        var downX = 0f; var downY = 0f; var startPx = 0f; var startY = 0
        var dragging = false; var rubbing = false; var lastRev = 0
        img.setOnTouchListener { _, ev ->
            val step = 4f * density; val seg = 14f * density
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startPx = px; startY = yMargin
                    dragging = false; rubbing = false; lastRev = 0
                    ox.reset(ev.rawX); oy.reset(ev.rawY); dismissMenu()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    val dist = abs(dx) + abs(dy)
                    if (!dragging) {
                        ox.feed(ev.rawX, step, seg); oy.feed(ev.rawY, step, seg)
                        val rev = max(ox.rev, oy.rev)
                        if (rev >= 2 && dist < 70f * density) {
                            rubbing = true
                            val now = SystemClock.uptimeMillis()
                            if (rev > lastRev && now - lastRub > 700) { lastRev = rev; lastRub = now; doInteract(Inter.RUB) }
                        } else if (!rubbing && dist > 45f * density) {
                            dragging = true; doInteract(Inter.LIFT)
                        }
                    }
                    if (dragging) {
                        px = startPx + dx; yMargin = (startY - dy).toInt().coerceIn(0, sh - 200); applyPos()
                        state = Body.IDLE; stateUntil = SystemClock.uptimeMillis() + 3000
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) { doInteract(Inter.DROP); dragging = false }
                    rubbing = false
                }
            }
            gd.onTouchEvent(ev)
        }
    }

    /** Pendeteksi gerakan bolak-balik (elus). */
    private class Osc {
        var last = 0f; var dir = 0; var seg = 0f; var rev = 0
        fun reset(v: Float) { last = v; seg = v; dir = 0; rev = 0 }
        fun feed(v: Float, step: Float, minSeg: Float) {
            val d = v - last
            if (abs(d) < step) return
            val nd = if (d > 0) 1 else -1
            if (dir != 0 && nd != dir && abs(last - seg) >= minSeg) { rev++; seg = last }
            dir = nd; last = v
        }
    }
    private var lastRub = 0L

    private fun isHead(y: Float) = state != Body.SLEEP && y < img.height * 0.38f

    private fun doInteract(kind: Int) {
        val brain = NaraApp.brain
        val now = SystemClock.uptimeMillis()
        val id = brain.lang == "id"
        if (state == Body.SLEEP && kind != Inter.SLEEP && kind != Inter.SNACK && kind != Inter.DROP) {
            state = Body.IDLE; stateUntil = now + 4000
            brain.mood.impulse(if (brain.drives.energy < 0.5f) Emo.ANGRY else Emo.SURPRISED, -0.05f, 3500)
            speak(if (id) "Hmm… masih ngantuk…" else "Mmm… still sleepy…")
            return
        }
        val r = brain.interact(kind)
        when (kind) {
            Inter.HIGH5 -> { state = Body.WAVE; stateUntil = now + 1800 }
            Inter.SLEEP -> { state = Body.SLEEP; stateUntil = now + 30_000 }
            Inter.SNACK, Inter.HUG, Inter.PAT, Inter.RUB, Inter.POKE, Inter.SCOLD -> if (state == Body.WALK || state == TOUCH) { state = Body.IDLE; stateUntil = now + 3500 }
        }
        var t = r.text
        if (t == null && now - lastHeart > 2500) {
            t = when (r.emo) { Emo.HAPPY -> "💗"; Emo.SHY -> "💓"; else -> null }
            if (t != null) lastHeart = now
        }
        if (t != null) speak(t)
    }

    // ------------------------------------------------------------ menu interaksi (tekan lama)
    private fun dismissMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null; h.removeCallbacks(menuTimeout) }
    private val menuTimeout = Runnable { dismissMenu() }

    private fun showMenu() {
        dismissMenu()
        val id = NaraApp.brain.lang == "id"
        val items = listOf(
            (if (id) "💬 Ngobrol" else "💬 Chat") to { openChat() },
            (if (id) "🤗 Peluk" else "🤗 Hug") to { doInteract(Inter.HUG) },
            (if (id) "✋ Tos!" else "✋ High five") to { doInteract(Inter.HIGH5) },
            (if (id) "🍪 Kasih camilan" else "🍪 Give snack") to { doInteract(Inter.SNACK) },
            (if (id) "😴 Tidurlah" else "😴 Take a nap") to { doInteract(Inter.SLEEP) },
            (if (id) "👎 Jangan begitu" else "👎 Don't do that") to { doInteract(Inter.SCOLD) }
        )
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply { cornerRadius = 14 * density; setColor(Color.argb(235, 20, 24, 44)); setStroke((1.5f * density).toInt(), Color.rgb(70, 212, 224)) } }
        for ((label, act) in items) col.addView(TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 14f
            setPadding((12 * density).toInt(), (9 * density).toInt(), (12 * density).toInt(), (9 * density).toInt())
            setOnClickListener { dismissMenu(); act() }
        })
        val menuW = (170 * density).toInt()
        val left = px + winWidth() / 2 < sw / 2
        val mlp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (if (left) px + winWidth() + 8 * density else px - menuW - 8 * density).toInt().coerceIn(0, max(0, sw - menuW))
            y = yMargin + (img.height * 0.35f).toInt()
        }
        try { wm.addView(col, mlp); menu = col; h.postDelayed(menuTimeout, 7000) } catch (_: Exception) {}
    }

    fun speak(t: String) {
        h.post {
            if (!ready) return@post
            val talky = t.any { it.isLetter() } && t.length > 3
            if (talky) { history.add(false to t); if (history.size > 40) history.removeAt(0) }
            talkUntil = SystemClock.uptimeMillis() + (1200 + t.length * 55L).coerceAtMost(6000)
            if (Prefs.tts && talky) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nara")
            if (panel != null) { if (talky) addMsg(false, t); return@post }   // panel terbuka: tampil di panel
            val sp = SpannableString(if (talky) "$t\n↩ ketuk untuk balas" else t)
            if (talky) {
                val s0 = t.length + 1
                sp.setSpan(RelativeSizeSpan(0.75f), s0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sp.setSpan(ForegroundColorSpan(Color.rgb(120, 200, 215)), s0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            bubble.text = sp; bubble.visibility = View.VISIBLE
            h.removeCallbacks(hideBubble); h.postDelayed(hideBubble, (3500 + t.length * 80L).coerceAtMost(12000))
            applyPos()
        }
    }

    // ------------------------------------------------------------ panel balas (ketuk gelembung / menu / notifikasi)
    private fun addMsg(user: Boolean, text: String) {
        val box = panelBox ?: return
        val tv = TextView(this).apply {
            this.text = text; setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(10), dp(6), dp(10), dp(6)); maxWidth = (sw * 0.72f).toInt()
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (user) Color.argb(235, 40, 60, 140) else Color.argb(235, 26, 32, 56))
                setStroke(dp(1), if (user) Color.rgb(120, 150, 255) else Color.rgb(70, 212, 224))
            }
        }
        val lpm = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpm.topMargin = dp(5); lpm.gravity = if (user) Gravity.END else Gravity.START
        box.addView(tv, lpm)
        panelScroll?.post { panelScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private val chatTimeout = Runnable { closeChat() }

    private fun focusInput() {
        h.postDelayed({
            panelInput?.let {
                it.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, InputMethodManager.SHOW_IMPLICIT)
            }
        }, 250)
    }

    private var panelLp: WindowManager.LayoutParams? = null

    private fun savePanel() {
        val l = panelLp ?: return
        getSharedPreferences("nara", MODE_PRIVATE).edit().putInt("pw", l.width).putInt("ph", l.height).putInt("px", l.x).putInt("py", l.y).apply()
    }

    private fun openChat() {
        if (!ready) return
        dismissMenu()
        if (panel != null) { focusInput(); return }
        h.removeCallbacks(hideBubble); bubble.visibility = View.GONE
        val id = NaraApp.brain.lang == "id"
        val spf = getSharedPreferences("nara", MODE_PRIVATE)
        val pw = spf.getInt("pw", (sw * 0.94f).toInt()).coerceIn(dp(240), sw)
        val ph = spf.getInt("ph", (sh * 0.5f).toInt()).coerceIn(dp(220), sh)
        val wlp = WindowManager.LayoutParams(pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = spf.getInt("px", (sw - pw) / 2).coerceIn(0, max(0, sw - pw))
            y = spf.getInt("py", dp(40)).coerceIn(0, max(0, sh - dp(120)))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        panelLp = wlp

        val p = object : LinearLayout(this) {
            override fun dispatchKeyEvent(e: KeyEvent): Boolean {
                if (e.keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) { closeChat(); return true }
                return super.dispatchKeyEvent(e)
            }
        }
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(10), dp(8), dp(10), dp(6))
        p.background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.argb(244, 14, 17, 34)); setStroke(dp(1), Color.rgb(70, 212, 224)) }

        // header = pegangan geser panel
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "Nara  •  " + (if (id) "geser di sini" else "drag here"); setTextColor(Color.rgb(70, 212, 224)); textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(4), 0, dp(4))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply { text = "  ✕  "; setTextColor(Color.WHITE); textSize = 18f; setOnClickListener { closeChat() } })
        var dx0 = 0f; var dy0 = 0f; var sx = 0; var sy = 0
        head.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; sx = wlp.x; sy = wlp.y; true }
                MotionEvent.ACTION_MOVE -> {
                    wlp.x = (sx + e.rawX - dx0).toInt().coerceIn(0, max(0, sw - wlp.width))
                    wlp.y = (sy + e.rawY - dy0).toInt().coerceIn(0, max(0, sh - dp(80)))
                    try { wm.updateViewLayout(p, wlp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { savePanel(); true }
                else -> false
            }
        }
        p.addView(head)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(box) }
        p.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        panelBox = box; panelScroll = scroll

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = if (id) "Balas Nara…" else "Reply to Nara…"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 15f
            setRawInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 3; setHorizontallyScrolling(false)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.rgb(10, 14, 30)); setStroke(dp(1), Color.rgb(70, 110, 140)) }
            setOnEditorActionListener { _, _, _ -> sendChat(); true }
        }
        panelInput = input
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply { text = " ▶ "; setTextColor(Color.rgb(70, 212, 224)); textSize = 24f; setOnClickListener { sendChat() } })
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); rlp.topMargin = dp(6)
        p.addView(row, rlp)

        // gagang ubah ukuran (pojok kanan bawah)
        var rw = 0; var rh = 0; var rx = 0f; var ry = 0f
        val grip = TextView(this).apply {
            text = "◢"; setTextColor(Color.rgb(70, 212, 224)); textSize = 22f; gravity = Gravity.END
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { rw = wlp.width; rh = wlp.height; rx = e.rawX; ry = e.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        wlp.width = (rw + (e.rawX - rx)).toInt().coerceIn(dp(240), sw)
                        wlp.height = (rh + (e.rawY - ry)).toInt().coerceIn(dp(220), sh)
                        try { wm.updateViewLayout(p, wlp) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> { savePanel(); true }
                    else -> false
                }
            }
        }
        p.addView(grip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        for ((u, m) in history.takeLast(20)) addMsg(u, m)
        if (history.isEmpty()) addMsg(false, if (id) "Hai! Ketik apa saja, aku dengerin.\nPerintah: /ketik teks • /kirim teks • /cari teks • /kirim ke chatgpt: teks" else "Hi! Type anything.\nCommands: /ketik text • /kirim text • /cari text • /kirim ke chatgpt: text")

        try { wm.addView(p, wlp); panel = p } catch (_: Exception) { panelBox = null; panelScroll = null; panelInput = null; return }
        if (state == Body.SLEEP) { state = Body.IDLE; stateUntil = SystemClock.uptimeMillis() + 5000 }
        h.removeCallbacks(chatTimeout); h.postDelayed(chatTimeout, 180_000)
        focusInput()
    }

    private fun closeChat() {
        h.removeCallbacks(chatTimeout)
        savePanel()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelBox = null; panelScroll = null; panelInput = null
    }

    private fun sendChat() {
        val t = panelInput?.text?.toString()?.trim().orEmpty()
        if (t.isEmpty()) return
        panelInput?.setText("")
        history.add(true to t); addMsg(true, t)
        val cmd = TypeCmd.parse(t)
        if (cmd != null) { Shared.lastUserTouch = SystemClock.uptimeMillis(); runTypeCmd(cmd); return }
        val ps = NaraApp.brain.nlp.parse(t)               // NLP: kata perintah (kalahkan, buatkan, tekan, buka, tanya, latih, berhenti, status)
        if (ps.intent != Nlp.CHAT) { Shared.lastUserTouch = SystemClock.uptimeMillis(); handleIntent(ps, t); return }
        val r = NaraApp.brain.reply(t)
        Shared.lastUserTouch = SystemClock.uptimeMillis()
        if (r.isNotEmpty()) {
            history.add(false to r); addMsg(false, r)
            talkUntil = SystemClock.uptimeMillis() + (1200 + r.length * 55L).coerceAtMost(6000)
            if (Prefs.tts) tts?.speak(r, TextToSpeech.QUEUE_FLUSH, null, "nara")
        }
        h.removeCallbacks(chatTimeout); h.postDelayed(chatTimeout, 120_000)
    }

    private val hideBubble = Runnable { bubble.visibility = View.GONE }

    private fun winWidth() = if (root.width > 0) root.width else (sw * 0.3f).toInt()

    private fun applyPos() {
        px = px.coerceIn(0f, max(0f, (sw - winWidth()).toFloat()))
        lp.x = px.toInt(); lp.y = yMargin
        if (root.isAttachedToWindow) try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        val hgt = root.height
        Shared.charRect = Rect(lp.x, sh - lp.y - hgt, lp.x + winWidth(), sh - lp.y)
    }

    // ------------------------------------------------------------ animasi (±8 fps)
    private val animTick = object : Runnable {
        override fun run() { try { stepAnim() } catch (e: Throwable) { Shared.lastErr = "anim: $e" }; h.postDelayed(this, if (state == Body.WALK) 33L else 150L) }
    }
    private var shownBmp: Bitmap? = null
    private var lastAnimNow = 0L
    private var animT = 0L
    private var lastSpriteKey = ""

    private fun stepAnim() {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastAnimNow == 0L) 60L else (now - lastAnimNow).coerceIn(1L, 200L)
        lastAnimNow = now
        val emo = NaraApp.brain.emotion()
        // baris sprite, rentang frame (hi eksklusif), durasi per frame (ms)
        var name = "idle"; var lo = 0; var hi = 1; var ms = 1200L; var once = false
        when (state) {
            Body.WALK -> {
                // ARAH EKSPLISIT: sprite kanan untuk bergerak ke kanan, sprite kiri untuk ke kiri. Tidak pernah dibalik di runtime.
                val d = if (facingRight) "R" else "L"
                if (running) { name = "run_$d"; ms = 80 } else { name = "walk_$d"; ms = 100 }
                hi = 9
            }
            Body.SIT -> { name = "sit"; hi = 5; ms = 500; once = true }
            Body.SLEEP -> { name = "sit"; lo = 7; hi = 8 }
            Body.WAVE -> { name = "happy"; hi = 5; ms = 140 }
            TOUCH -> { name = "happy"; hi = 2; ms = 300 }
            else -> when (emo) {
                Emo.HAPPY -> { name = "happy"; lo = 5; hi = 6 }
                Emo.ANGRY -> { name = "annoyed"; lo = 0; hi = 1 }
                Emo.SAD -> { name = "sit"; lo = 5; hi = 6 }
                else -> {}
            }
        }
        val key = "$name:$lo:$hi"
        if (key != lastSpriteKey) { lastSpriteKey = key; animT = 0 } else animT += dt

        if (state == Body.WALK) {
            // kecepatan diturunkan dari animasi: jarak per siklus / durasi siklus
            val cycleMs = ((hi - lo) * ms).toFloat()
            val v = (if (running) RUN_DIST else WALK_DIST) * img.height.coerceAtLeast(1) / cycleMs   // px per ms
            val maxX = max(0f, (sw - winWidth()).toFloat())
            tx = tx.coerceIn(0f, maxX)
            px += (if (facingRight) 1 else -1) * v * dt
            if ((facingRight && px >= tx) || (!facingRight && px <= tx)) {
                px = tx; state = Body.IDLE; stateUntil = now + 2000 + rnd.nextInt(3000)
            }
            applyPos()
        }
        val directional = name.startsWith("walk_") || name.startsWith("run_")
        val list = frames(name, if (directional) true else facingRight) ?: return
        // diam = satu pose tetap (hanya kedip pose lain 0,3 dtk tiap 7 dtk); duduk = sekali duduk lalu tahan; hanya jalan/lari/lambai yang beranimasi
        val idx = when {
            name == "idle" -> if (animT % 7000L > 6700L) 2 else 0
            once -> min(lo + (animT / ms).toInt(), hi - 1)
            else -> lo + ((animT / ms).toInt() % (hi - lo))
        }
        val bmp = list[idx.coerceIn(0, list.size - 1)]
        if (bmp !== shownBmp) { shownBmp = bmp; img.show(bmp, null, 0, 0) }
    }

    // ------------------------------------------------------------ kehendak (1x/detik)
    private val thinkTick = object : Runnable { override fun run() { try { think() } catch (e: Throwable) { Shared.lastErr = "think: $e" }; h.postDelayed(this, 1000) } }

    private fun think() {
        val now = SystemClock.uptimeMillis()
        val brain = NaraApp.brain
        val dm = resources.displayMetrics; sw = dm.widthPixels; sh = dm.heightPixels
        brain.tick(1f, state == Body.SLEEP)
        if (now - lastSave > 60_000) { lastSave = now; if (!Backup.restoring) brain.save() }
        if (Shared.paused || panel != null) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return

        if (now >= stateUntil) chooseBody(now)
        if (state == Body.SLEEP && brain.drives.energy > 0.95f) { state = Body.IDLE; stateUntil = now + 2000 }

        goalTick(now)
        val interval = when (Prefs.autonomy) { 1 -> 90_000L; 2 -> 35_000L; 3 -> 14_000L; else -> Long.MAX_VALUE }
        if (goal == null && Prefs.autoType && now - lastAskCheck > 10_000) {      // cek tiap ~10 dtk; jeda minimal 30 dtk antar pertanyaan
            lastAskCheck = now
            if (now - Shared.lastUserTouch > 8_000 && now - lastAskAt > 30_000 && state != Body.SLEEP) {
                ScreenAccessService.instance?.let { if (tryAutoType(it)) lastAskAt = now }
            }
        }
        if (goal == null && Prefs.autonomy > 0 && now - lastInteract >= interval && state != Body.SLEEP) {
            lastInteract = now + rnd.nextInt(5000)
            tryInteract()
        }
        pendingWord?.let { pw -> if (now - pendingAt > 45_000) { pendingWord = null; learnAnswer(pw) } }
        if (goal == null && Prefs.screenshot && !ScreenReader.busy && now - lastShot > 20_000 && bubble.visibility != View.VISIBLE &&
            !(getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked) {
            lastShot = now
            ScreenReader.capture { nov, lines ->
                val t = SystemClock.uptimeMillis()
                if (nov > 0.55f && t - lastComment > 60_000 && bubble.visibility != View.VISIBLE && panel == null && state != Body.SLEEP) {
                    lastComment = t
                    brain.comment(Shared.curLabel.ifEmpty { "HP" }, lines)?.let { speak(it) }
                }
            }
        }
        val ctx by lazy { brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa) }
        if (now - Shared.lastUserTouch > 20_000 && now - lastIdleTrain > 20_000 && Shared.curPkg.isNotEmpty()) { lastIdleTrain = now; brain.observeIdle(ctx) }
        if (now - lastComment > 120_000 && bubble.visibility != View.VISIBLE && state != Body.SLEEP) {
            lastComment = now + rnd.nextInt(60_000)
            brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
        }
    }

    private fun chooseBody(now: Long) {
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideBody(ctx)) {
            Body.WALK -> {
                if (rnd.nextInt(100) >= 30) { state = Body.IDLE; stateUntil = now + 10_000 + rnd.nextInt(15_000); return }   // lebih sering diam
                val maxX = max(1f, (sw - winWidth()).toFloat())
                var t = (px + (rnd.nextFloat() * 2f - 1f) * sw * 0.3f).coerceIn(0f, maxX)      // jalan pendek, tidak keliling layar
                if (abs(t - px) < sw * 0.08f) t = if (px < maxX / 2) kotlin.math.min(maxX, px + sw * 0.2f) else max(0f, px - sw * 0.2f)
                tx = t; facingRight = t > px; state = Body.WALK; stateUntil = now + 20_000
                running = abs(t - px) > sw * 0.6f
            }
            Body.SIT -> { state = Body.SIT; stateUntil = now + 8_000 + rnd.nextInt(12_000) }
            Body.SLEEP -> { state = Body.SLEEP; stateUntil = now + 30_000; speak("💤") }
            Body.WAVE -> { state = Body.WAVE; stateUntil = now + 2500 }
            Body.TALK -> {
                state = Body.IDLE; stateUntil = now + 3000
                NaraApp.brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
            }
            else -> { state = Body.IDLE; stateUntil = now + 8_000 + rnd.nextInt(10_000) }
        }
    }

    // ------------------------------------------------------------ menyentuh layar
    private var lastShot = 0L
    private val typeOk = listOf("chrome", "googlequicksearchbox", "openai", "chatgpt", "gemini", "anthropic", "claude", "perplexity", "brave", "firefox", "duckduckgo", "opera", "edge", "copilot", "deepseek")

    private val aiPkgs = listOf("openai", "chatgpt", "gemini", "bard", "anthropic", "claude", "perplexity", "copilot", "deepseek")
    private var lastAskCheck = 0L
    private var lastAskAt = 0L
    private var pendingQ = ""
    private var pendingWord: String? = null
    private var pendingAt = 0L

    /**
     * Rasa ingin tahu: menemukan kata yang belum dikenal di layar -> (kalau dia memutuskan) bertanya ke AI cara memakainya,
     * di mana letaknya dalam kalimat, dan contoh kalimat. Di browser dia mencari. Kalau belum di app AI/browser dan kamu sedang diam >1 menit,
     * dia membuka app AI sendiri. Jawabannya dibaca ~40 detik kemudian lalu dipelajari.
     */
    private fun tryAutoType(svc: ScreenAccessService): Boolean {
        if (pendingWord != null) return false
        val brain = NaraApp.brain
        val pkg = Shared.curPkg.lowercase()
        val inApp = typeOk.any { pkg.contains(it) }
        if (!inApp && SystemClock.uptimeMillis() - Shared.lastUserTouch < 20_000) return false
        val lines = Shared.curTexts + ScreenReader.lastLines
        val word = brain.lm.rareUnknownWord(lines.joinToString(". "), rnd)
        // tidak ada kata baru -> minta AI membuatkan kalimat tentang apa yang sedang dilihat
        val topic = if (word == null) lines.filter { it.length in 25..120 && it.count { c -> c.isLetter() } > 15 }.shuffled(rnd).firstOrNull() else null
        val key = word ?: topic ?: return false
        val pos = if (inApp) (svc.editableCenter() ?: return false) else null
        val intent = if (inApp) null else (launchFor("ai") ?: return false)
        if (!brain.decideAsk()) return false   // dia sendiri yang memutuskan: bertanya atau tidak
        brain.askDone()
        val id = brain.lang == "id"
        val ai = !inApp || aiPkgs.any { pkg.contains(it) }
        val q = when {
            ai && word != null -> if (id) "Aku menemukan kata baru: \"$word\". Jelaskan artinya, lalu buatkan 5 kalimat lengkap yang memakai kata itu (letakkan di posisi berbeda: awal, tengah, akhir kalimat) dan jelaskan di mana letaknya yang benar."
                else "I found a new word: \"$word\". Explain it, then write 5 complete sentences using it (put it in different positions: start, middle, end) and explain where it belongs."
            ai -> if (id) "Buatkan 5 kalimat lengkap yang berkaitan dengan: \"$key\". Pakai bahasa sehari-hari." else "Write 5 complete sentences related to: \"$key\". Use everyday language."
            word != null -> if (id) "arti kata $word contoh kalimat" else "$word meaning example sentence"
            else -> key.take(60)
        }
        speak(if (word != null) (if (id) "Ada kata baru: \"$word\". Aku minta AI buatkan kalimatnya ya." else "New word: \"$word\". I'll ask an AI for sentences.")
              else (if (id) "Aku penasaran soal ini, aku minta AI buatkan kalimatnya ya." else "I'm curious about this, let me ask an AI for sentences."))
        pendingWord = key; pendingQ = q; pendingAt = SystemClock.uptimeMillis()
        if (pos != null) {
            reach(pos.first, pos.second) { svc.typeInto(q, true) }
        } else if (intent != null) {
            try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            typeWhenReady(svc, TypeCmd.Cmd(null, q, true, false), 0)
        }
        return true
    }

    /** ~45 detik setelah bertanya: baca jawaban (kalimat) di layar dan pelajari. */
    private fun learnAnswer(w: String) {
        val brain = NaraApp.brain
        val pkg = Shared.curPkg.lowercase()
        if (typeOk.none { pkg.contains(it) }) return
        val head = pendingQ.take(20)
        val lines = ((ScreenAccessService.instance?.freshTexts() ?: Shared.curTexts) + ScreenReader.lastLines).distinct().filter { !it.startsWith(head) }
        val ex = brain.learnWord(w, lines)
        val id = brain.lang == "id"
        if (ex != null) speak(if (id) "Oh, begini kalimatnya: ${ex.take(120)}" else "Oh, like this: ${ex.take(120)}")
        else if (lines.size > 3) speak(if (id) "Aku sudah baca kalimat-kalimatnya." else "I read the sentences.")
    }

    // ------------------------------------------------------------ perintah ketik dari panel
    private fun launchFor(name: String): Intent? {
        val pm = packageManager
        val q = name.trim().lowercase()
        val keys = if (q == "ai") listOf("chatgpt", "gemini", "claude", "copilot", "perplexity", "deepseek") else listOf(q)
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        for (k in keys) {
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(k) || it.activityInfo.packageName.lowercase().contains(k) } ?: continue
            if (ScreenAccessService.isBlocked(hit.activityInfo.packageName)) return null
            return pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        }
        return null
    }

    private fun searchIntent(): Intent {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        if (packageManager.getLaunchIntentForPackage("com.android.chrome") != null) i.setPackage("com.android.chrome")
        return i
    }

    private fun runTypeCmd(c: TypeCmd.Cmd) {
        val id = NaraApp.brain.lang == "id"
        val svc = ScreenAccessService.instance
        if (svc == null) {
            val on = (android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains("ScreenAccessService")
            addMsg(false, if (on) (if (id) "Aksesibilitas Nara tampak ON tapi belum tersambung. Matikan lalu hidupkan lagi di Pengaturan → Aksesibilitas → Nara, lalu coba lagi." else "Nara's accessibility looks ON but isn't connected. Turn it off and on again, then retry.")
                else (if (id) "Akses layar belum diaktifkan di Pengaturan → Aksesibilitas → Nara." else "Screen access isn't enabled in Settings → Accessibility → Nara."))
            return
        }
        val intent = when {
            c.app != null -> launchFor(c.app) ?: run { addMsg(false, if (id) "Aplikasi \"${c.app}\" tidak ketemu (atau diblokir)." else "App \"${c.app}\" not found (or blocked)."); return }
            c.search -> searchIntent()
            else -> null
        }
        closeChat()
        if (intent != null) try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        speak(if (id) "Oke, aku ketik ya." else "Okay, typing.")
        typeWhenReady(svc, c, 0)
    }

    private fun typeWhenReady(svc: ScreenAccessService, c: TypeCmd.Cmd, n: Int) {
        h.postDelayed({
            if (svc.typeInto(c.text, c.submit)) return@postDelayed
            if (n < 8) typeWhenReady(svc, c, n + 1)
            else if (c.search) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(c.text))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            } else {
                speak(if (NaraApp.brain.lang == "id") "Aku tidak menemukan kolom untuk mengetik." else "I couldn't find a text field.")
            }
        }, if (n == 0) 1200L else 800L)
    }

    // ------------------------------------------------------------ tujuan (goal) lewat chat
    private val SANDBOX = "com.nara.sandbox"
    private var goal: Goal? = null
    private var training = false

    private fun tell(t: String) { history.add(false to t); if (panel != null) addMsg(false, t) else speak(t) }

    private fun svcOrTell(): ScreenAccessService? {
        val svc = ScreenAccessService.instance
        if (svc == null) {
            val id = NaraApp.brain.lang == "id"
            tell(if (id) "Akses layar belum tersambung. Matikan lalu hidupkan lagi Aksesibilitas Nara, ya." else "Screen access isn't connected. Toggle Nara's accessibility off and on.")
        }
        return svc
    }

    private fun startGoal(g: Goal, msg: String) {
        if (svcOrTell() == null) return
        goal = g
        tell(msg); closeChat(); speak(msg)
        g.busyUntil = SystemClock.uptimeMillis() + 1500
    }

    private fun statusText(): String {
        val id = NaraApp.brain.lang == "id"
        val g = goal
        val gs = when {
            g == null -> if (id) "Saat ini aku tidak punya tujuan aktif." else "I have no active goal right now."
            g.kind == Nlp.BEAT -> if (id) "Tujuan: kalahkan ${g.target} di catur • menang ${g.wins}, kalah ${g.losses}, seri ${g.draws} • butuh ${g.left} kemenangan lagi." else "Goal: beat ${g.target} • ${g.wins}W ${g.losses}L ${g.draws}D • ${g.left} wins to go."
            g.kind == Nlp.TRAIN -> if (id) "Tujuan: latihan menekan tombol • sisa ${g.left} ronde." else "Goal: button practice • ${g.left} rounds left."
            else -> if (id) "Tujuan: tekan \"${g.target}\"." else "Goal: press \"${g.target}\"."
        }
        return gs + "\n" + (if (id) "Catur: " else "Chess: ") + NaraApp.brain.chess.stats()
    }

    private fun trainChess(n: Int) {
        val id = NaraApp.brain.lang == "id"
        if (training) { tell(if (id) "Aku masih berlatih, tunggu sebentar ya." else "Still training, one moment."); return }
        training = true
        val games = n.coerceIn(30, 200)
        tell(if (id) "Oke, aku berlatih catur $games partai di latar belakang…" else "Okay, training $games chess games in the background…")
        Thread {
            val s = try { NaraApp.brain.chess.selfTrain(games, Random()) } catch (e: Throwable) { "gagal: $e" }
            h.post {
                training = false
                tell((if (id) "Selesai berlatih: " else "Training done: ") + s + ". " + NaraApp.brain.chess.stats())
                if (!Backup.restoring) NaraApp.brain.save()
            }
        }.start()
    }

    private fun handleIntent(ps: Nlp.Parsed, raw: String) {
        val brain = NaraApp.brain
        val id = brain.lang == "id"
        when (ps.intent) {
            Nlp.STOP -> {
                val had = goal != null; goal = null
                tell(if (had) (if (id) "Oke, tujuanku kuhentikan." else "Okay, goal stopped.") else (if (id) "Aku memang sedang tidak mengejar tujuan apa pun." else "I'm not chasing any goal."))
            }
            Nlp.STATUS -> tell(statusText())
            Nlp.TRAIN -> if (ps.game == "tap") startGoal(Goal(Nlp.TRAIN, "tap", ps.count.coerceAtLeast(10), "tap"),
                    if (id) "Siap, aku latihan menekan tombol di NaraSandbox." else "Okay, practicing button presses in NaraSandbox.")
                else trainChess(ps.count)
            Nlp.BEAT -> {
                val who = if (ps.target.isEmpty()) "mittens" else ps.target
                startGoal(Goal(Nlp.BEAT, who, ps.count, "chess"),
                    if (id) "Siap! Aku akan mengalahkan ${who.replaceFirstChar { it.uppercase() }} di catur. Aku buka NaraSandbox dulu." else "On it! I'll beat ${who.replaceFirstChar { it.uppercase() }} at chess. Opening NaraSandbox.")
            }
            Nlp.PRESS -> {
                val label = ps.target.replace("tombol", "").trim().ifEmpty { ps.target }
                if (label.isEmpty()) { tell(if (id) "Tombol yang mana?" else "Which button?"); return }
                startGoal(Goal(Nlp.PRESS, label, 1, ""), if (id) "Oke, aku tekan \"$label\"." else "Okay, pressing \"$label\".")
            }
            Nlp.OPEN -> {
                val name = ps.target.replace("aplikasi", "").trim()
                val i = if (name.isEmpty()) null else launchFor(name)
                if (i == null) { tell(if (id) "Aplikasi \"$name\" tidak ketemu (atau diblokir)." else "App \"$name\" not found (or blocked)."); return }
                tell(if (id) "Oke, kubuka $name." else "Okay, opening $name."); closeChat()
                try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
            Nlp.ASK -> {
                val low = raw.trim().lowercase()
                val search = low.startsWith("cari") || low.startsWith("telusuri") || low.startsWith("search")
                var tail = ps.tail
                var app: String? = null
                val first = tail.substringBefore(' ')
                if (first in setOf("ai", "chatgpt", "gemini", "claude", "copilot", "perplexity", "deepseek", "chrome", "google")) { app = first; tail = tail.substringAfter(' ', "") }
                if (tail.isEmpty()) { tell(if (id) "Mau tanya apa?" else "What should I ask?"); return }
                runTypeCmd(TypeCmd.Cmd(if (search || app == "chrome" || app == "google") null else (app ?: "ai"), tail, true, search || app == "chrome" || app == "google"))
            }
            Nlp.MAKE -> {
                val what = ps.tail.ifEmpty { ps.target }
                if (what.isEmpty()) { tell(if (id) "Mau dibuatkan apa?" else "What should I make?"); return }
                val q = if (id) "Buatkan $what. Berikan hasil yang lengkap dan siap dipakai." else "Make $what. Give a complete, ready-to-use result."
                pendingWord = what.take(60); pendingQ = q; pendingAt = SystemClock.uptimeMillis()
                runTypeCmd(TypeCmd.Cmd("ai", q, true, false))
            }
        }
    }

    private fun goalTick(now: Long) {
        val g = goal ?: return
        val svc = ScreenAccessService.instance ?: return
        if (g.thinking || now < g.busyUntil) return
        if (now - g.startedAt > 40 * 60_000L) { tell("Waktunya habis, tujuanku kuhentikan."); goal = null; return }
        when (g.kind) {
            Nlp.BEAT -> goalBeat(g, svc, now)
            Nlp.TRAIN -> goalTapTrain(g, svc, now)
            Nlp.PRESS -> goalPress(g, svc, now)
            else -> goal = null
        }
    }

    private fun ensureSandbox(g: Goal, now: Long): Boolean {
        if (Shared.curPkg == SANDBOX) return true
        if (now - g.lastActAt > 10_000) {
            g.lastActAt = now
            val i = packageManager.getLaunchIntentForPackage(SANDBOX)
            if (i == null) { tell(if (NaraApp.brain.lang == "id") "NaraSandbox belum terpasang. Pasang APK sandbox-nya dulu ya." else "NaraSandbox isn't installed."); goal = null; return false }
            try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            g.busyUntil = now + 3500
        }
        return false
    }

    private fun clickText(svc: ScreenAccessService, g: Goal, now: Long, text: String): Boolean {
        val c = svc.candidates().firstOrNull { it.text.contains(text, true) }
        if (c == null) { g.busyUntil = now + 1500; return false }
        reach(c.cx, c.cy) { svc.tap(c.cx, c.cy) }
        g.busyUntil = now + 2800
        return true
    }

    private fun parseCastle(status: String): Int {
        val m = Regex("CR=([KQkq-]+)").find(status)?.groupValues?.get(1) ?: return 0
        var r = 0
        if ('K' in m) r = r or 1; if ('Q' in m) r = r or 2; if ('k' in m) r = r or 4; if ('q' in m) r = r or 8
        return r
    }

    private fun parseEp(status: String): Int {
        val m = Regex("EP=([a-h][1-8])").find(status)?.groupValues?.get(1) ?: return -1
        return Chess.index(m)
    }

    private fun goalBeat(g: Goal, svc: ScreenAccessService, now: Long) {
        if (!ensureSandbox(g, now)) return
        val b = svc.readBoard()
        if (b == null || b.found < 64) { clickText(svc, g, now, "Catur"); return }
        if (b.result.isNotEmpty()) { onChessResult(g, svc, b, now); return }
        g.recorded = false
        if (!b.status.contains("GILIRAN_PUTIH")) return
        val c = Chess()
        for (i in 0 until 64) c.b[i] = b.sq[i]
        c.side = 1; c.castle = parseCastle(b.status); c.ep = parseEp(b.status)
        g.thinking = true
        val net = NaraApp.brain.chess
        Thread {
            val mv = try { net.best(c, 2, 0f, Random()) } catch (e: Throwable) { -1 }
            h.post {
                g.thinking = false
                if (goal !== g) return@post
                val t0 = SystemClock.uptimeMillis()
                if (mv < 0) { g.busyUntil = t0 + 2000; return@post }
                val after = c.copy(); after.apply(mv); g.seen.add(after)
                val f = Chess.from(mv); val t = Chess.to(mv)
                reach(b.cx[f], b.cy[f]) { svc.tap(b.cx[f], b.cy[f]) }
                h.postDelayed({ if (goal === g) reach(b.cx[t], b.cy[t]) { svc.tap(b.cx[t], b.cy[t]) } }, 1500)
                g.busyUntil = t0 + 3600
            }
        }.start()
    }

    private fun onChessResult(g: Goal, svc: ScreenAccessService, b: ScreenAccessService.Board, now: Long) {
        val brain = NaraApp.brain
        val id = brain.lang == "id"
        if (!g.recorded) {
            g.recorded = true
            val res = when { b.result.contains("MENANG") -> 1; b.result.contains("KALAH") -> -1; else -> 2 }
            if (res == 1 || res == -1) brain.chess.learn(g.seen, res, 0.01f)
            brain.chess.record(res)
            g.attempts++; g.seen.clear()
            if (res == 1) { g.wins++; g.left-- } else if (res == -1) g.losses++ else g.draws++
            if (!Backup.restoring) brain.save()
            if (g.left <= 0) {
                val m = (if (id) "Aku menang melawan ${g.target.replaceFirstChar { it.uppercase() }}! (${g.wins} menang, ${g.losses} kalah, ${g.draws} seri)" else "I beat ${g.target}! (${g.wins}W ${g.losses}L ${g.draws}D)")
                goal = null; tell(m); history.add(false to m)
                return
            }
            if (g.attempts >= 20) { goal = null; tell(if (id) "Sudah 20 partai, aku menyerah dulu. Latih aku lagi ya." else "20 games in, giving up for now."); return }
        }
        clickText(svc, g, now, "Main lagi")
    }

    private fun goalTapTrain(g: Goal, svc: ScreenAccessService, now: Long) {
        if (!ensureSandbox(g, now)) return
        val goalT = svc.freshTexts().firstOrNull { it.startsWith("TUJUAN: Tekan tombol") }
        if (goalT == null) { clickText(svc, g, now, "Latihan Tekan"); return }
        val want = Regex("'([^']+)'").find(goalT)?.groupValues?.get(1) ?: run { g.busyUntil = now + 1200; return }
        val cands = svc.candidates()
        val hit = cands.firstOrNull { it.text.trim().equals(want, true) }
        if (hit == null) {
            g.busyUntil = now + 1200
            g.miss++
            if (g.miss >= 2) { g.miss = 0; px = if (px + winWidth() / 2f < sw / 2f) (sw - winWidth()).toFloat() else 0f; tx = px; applyPos() }   // mungkin Nara menutupi tombolnya: geser
            return
        }
        val brain = NaraApp.brain
        brain.nodes.update(hit.feats, 1f)
        cands.filter { it !== hit }.shuffled(rnd).take(4).forEach { brain.nodes.update(it.feats, 0f, 0.08f) }
        reach(hit.cx, hit.cy) { svc.tap(hit.cx, hit.cy) }
        g.left--
        g.busyUntil = now + 2600
        if (g.left <= 0) { goal = null; tell(if (brain.lang == "id") "Latihan menekan tombol selesai. Aku makin paham tombol di seluruh layar." else "Button practice finished."); if (!Backup.restoring) brain.save() }
    }

    private fun goalPress(g: Goal, svc: ScreenAccessService, now: Long) {
        val id = NaraApp.brain.lang == "id"
        val words = g.target.lowercase().split(" ").filter { it.isNotEmpty() }
        svc.allowDanger = true
        val cands = try { svc.candidates() } finally { svc.allowDanger = false }
        val best = cands.map { it to words.count { w -> it.text.lowercase().contains(w) } }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<ScreenAccessService.Cand, Int>> { it.second }.thenBy { it.first.text.length }).firstOrNull()?.first
        if (best == null) {
            g.attempts++
            if (g.attempts >= 3) { goal = null; tell(if (id) "Aku tidak menemukan tombol \"${g.target}\" di layar." else "I couldn't find the \"${g.target}\" button.") }
            else g.busyUntil = now + 1500
            return
        }
        goal = null
        reach(best.cx, best.cy) { svc.tap(best.cx, best.cy) }
    }

    private fun tryInteract() {
        val svc = ScreenAccessService.instance ?: return
        val now = SystemClock.uptimeMillis()
        if (!svc.canAct() || now - Shared.lastUserTouch < 8000) return
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideInteract(ctx)) {
            Act.DOWN -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(true) }
            Act.UP -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(false) }
            Act.TAP -> {
                val cands = svc.candidates()
                val i = brain.pickNode(cands.map { it.feats }) ?: return
                val c = cands[i]
                reach(c.cx, c.cy) { svc.tap(c.cx, c.cy) }
            }
            Act.BACK -> reach(sw * 0.08f, sh * 0.5f) { svc.back() }
        }
    }

    private fun reach(x1: Float, y1: Float, action: () -> Unit) {
        state = TOUCH; stateUntil = SystemClock.uptimeMillis() + 2500
        facingRight = x1 >= lp.x + winWidth() / 2f
        val x0 = lp.x + winWidth() * (if (facingRight) 0.85f else 0.15f)
        val y0 = sh - lp.y - img.height * 0.55f
        val bmp = cursorBmp ?: run { action(); return }
        val size = (48 * density).toInt()
        val c = ImageView(this).apply { setImageBitmap(bmp) }
        val clp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (x0 - size / 2).toInt(); y = (y0 - size / 2).toInt() }
        try { wm.addView(c, clp) } catch (_: Exception) { action(); return }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener {
                val t = it.animatedValue as Float
                clp.x = (x0 + (x1 - x0) * t - size / 2).toInt(); clp.y = (y0 + (y1 - y0) * t - size / 2).toInt()
                try { wm.updateViewLayout(c, clp) } catch (_: Exception) {}
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    action()
                    h.postDelayed({ try { wm.removeView(c) } catch (_: Exception) {} }, 450)
                }
            })
            start()
        }
    }

    override fun onDestroy() {
        ready = false
        instance = null
        h.removeCallbacksAndMessages(null)
        dismissMenu(); closeChat(); ScreenReader.wipe()
        try { if (::root.isInitialized) wm.removeView(root) } catch (_: Exception) {}
        try { if (!Backup.restoring) NaraApp.brain.save() } catch (_: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
