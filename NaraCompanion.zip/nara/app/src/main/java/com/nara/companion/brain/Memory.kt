package com.nara.companion.brain

import java.io.File
import java.util.Properties

/** Memori jangka panjang berbasis file (tanpa server): fakta, kejadian, pasangan percakapan. */
class Memory(private val dir: File) {
    private val factsF = File(dir, "facts.properties")
    private val eventsF = File(dir, "events.tsv")
    private val pairsF = File(dir, "pairs.tsv")
    private val facts = Properties()
    val events = ArrayList<List<String>>()   // ts, pkg, kind, text
    val pairs = ArrayList<Pair<String, String>>() // prompt -> reply
    private var dirty = false

    fun load() {
        if (factsF.exists()) factsF.inputStream().use { facts.load(it) }
        if (eventsF.exists()) eventsF.forEachLine { l -> val p = l.split('\t'); if (p.size >= 4) events.add(p) }
        if (pairsF.exists()) pairsF.forEachLine { l -> val p = l.split('\t'); if (p.size >= 2) pairs.add(p[0] to p[1]) }
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').take(200)

    fun fact(k: String): String? = facts.getProperty(k)
    fun setFact(k: String, v: String) { facts.setProperty(k, v); dirty = true }
    fun allFacts(): Map<String, String> = facts.stringPropertyNames().associateWith { facts.getProperty(it) }

    fun event(pkg: String, kind: String, text: String) {
        events.add(listOf(System.currentTimeMillis().toString(), pkg, kind, clean(text)))
        if (events.size > 6000) { repeat(1000) { events.removeAt(0) } }
        dirty = true
    }

    fun pair(prompt: String, reply: String) {
        if (prompt.isBlank() || reply.isBlank()) return
        pairs.add(clean(prompt) to clean(reply))
        if (pairs.size > 4000) pairs.removeAt(0)
        dirty = true
    }

    fun topApps(days: Int = 7, n: Int = 3): List<String> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        return events.filter { (it[0].toLongOrNull() ?: 0) > since && it[2] == "app" }
            .groupingBy { it[3] }.eachCount().entries.sortedByDescending { it.value }.take(n).map { it.key }
    }

    fun save() {
        if (!dirty) return
        factsF.outputStream().use { facts.store(it, null) }
        eventsF.bufferedWriter().use { w -> events.forEach { w.write(it.joinToString("\t") + "\n") } }
        pairsF.bufferedWriter().use { w -> pairs.forEach { w.write(it.first + "\t" + it.second + "\n") } }
        dirty = false
    }

    fun wipe() { facts.clear(); events.clear(); pairs.clear(); factsF.delete(); eventsF.delete(); pairsF.delete() }
}
