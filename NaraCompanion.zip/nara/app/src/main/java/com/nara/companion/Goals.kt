package com.nara.companion

import android.os.SystemClock
import com.nara.companion.brain.Chess

/** Satu tujuan yang sedang dikejar Nara (diberikan lewat chat dan dipahami NLP). */
class Goal(val kind: Int, val target: String, var left: Int, val game: String) {
    companion object { const val PLAN = 100 }
    val startedAt = SystemClock.uptimeMillis()
    var busyUntil = 0L
    var lastActAt = 0L
    var thinking = false
    var recorded = false
    var attempts = 0; var wins = 0; var losses = 0; var draws = 0
    var miss = 0
    val seen = ArrayList<Chess>()   // posisi yang Nara mainkan, untuk belajar dari hasil partai
    val steps = ArrayList<Pair<String, String>>()   // rencana: (BUKA|KETIK|KIRIM|TEKAN|TUNGGU, argumen)
    var idx = 0
    var save = false                                  // simpan sebagai keterampilan baru kalau semua langkah berhasil
}
