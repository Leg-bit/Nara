package com.nara.companion.brain;

import java.io.*;
import java.util.Random;

/**
 * Satu jaringan inti untuk seluruh perilaku Nara: batang bersama (masukan -> tanh) dan dua kepala softmax:
 * kepala 0 = keputusan menyentuh layar (Act), kepala 1 = perilaku tubuh (Body).
 * Menggantikan dua MLP terpisah: parameter ~45% lebih sedikit, satu kali hitung maju, satu berkas (core.bin).
 */
public final class CoreNet {
    private static final int MAGIC = 0x434F5245;
    public final int nIn, nHid;
    private final int[] nOut = new int[2];
    private final float[] w1, b1;
    private final float[][] wo = new float[2][], bo = new float[2][];
    public final long[] steps = new long[2];

    public CoreNet(int nIn, int nHid, int nA, int nB, long seed) {
        this.nIn = nIn; this.nHid = nHid; nOut[0] = nA; nOut[1] = nB;
        Random r = new Random(seed);
        w1 = new float[nIn * nHid]; b1 = new float[nHid];
        for (int i = 0; i < w1.length; i++) w1[i] = (float) (r.nextGaussian() * Math.sqrt(2.0 / nIn));
        for (int k = 0; k < 2; k++) {
            wo[k] = new float[nHid * nOut[k]]; bo[k] = new float[nOut[k]];
            for (int i = 0; i < wo[k].length; i++) wo[k][i] = (float) (r.nextGaussian() * Math.sqrt(1.0 / nHid));
        }
    }

    public void setBias(int head, int k, float v) { bo[head][k] = v; }

    private float[] hidden(float[] x) {
        float[] h = new float[nHid];
        for (int j = 0; j < nHid; j++) {
            float s = b1[j];
            for (int i = 0; i < nIn; i++) { float xi = x[i]; if (xi != 0f) s += xi * w1[i * nHid + j]; }
            h[j] = (float) Math.tanh(s);
        }
        return h;
    }

    private float[] probs(int hd, float[] h) {
        int n = nOut[hd];
        float[] o = new float[n];
        float m = -1e30f;
        for (int k = 0; k < n; k++) {
            float s = bo[hd][k];
            for (int j = 0; j < nHid; j++) s += h[j] * wo[hd][j * n + k];
            o[k] = s; if (s > m) m = s;
        }
        float sum = 0f;
        for (int k = 0; k < n; k++) { o[k] = (float) Math.exp(o[k] - m); sum += o[k]; }
        for (int k = 0; k < n; k++) o[k] /= sum;
        return o;
    }

    public float[] forwardA(float[] x) { return probs(0, hidden(x)); }
    public float[] forwardB(float[] x) { return probs(1, hidden(x)); }

    private float step(int hd, float[] x, float[] q, float lr) {
        float[] h = hidden(x);
        float[] p = probs(hd, h);
        int n = nOut[hd];
        float loss = 0f;
        for (int k = 0; k < n; k++) if (q[k] > 0f) loss -= q[k] * (float) Math.log(Math.max(p[k], 1e-6f));
        float[] dO = new float[n];
        for (int k = 0; k < n; k++) dO[k] = p[k] - q[k];
        updateOut(hd, x, h, dO, lr);
        steps[hd]++;
        return loss;
    }

    private void updateOut(int hd, float[] x, float[] h, float[] dO, float lr) {
        int n = nOut[hd];
        float[] dH = new float[nHid];
        for (int j = 0; j < nHid; j++) {
            float s = 0f;
            for (int k = 0; k < n; k++) {
                s += dO[k] * wo[hd][j * n + k];
                wo[hd][j * n + k] = clip(wo[hd][j * n + k] - lr * dO[k] * h[j]);
            }
            dH[j] = s * (1f - h[j] * h[j]);
        }
        for (int k = 0; k < n; k++) bo[hd][k] = clip(bo[hd][k] - lr * dO[k]);
        for (int j = 0; j < nHid; j++) {
            float g = dH[j];
            if (g != 0f) for (int i = 0; i < nIn; i++) { float xi = x[i]; if (xi != 0f) w1[i * nHid + j] = clip(w1[i * nHid + j] - lr * g * xi); }
            b1[j] -= lr * g;
        }
    }

    private static float clip(float v) { return v > 6f ? 6f : (v < -6f ? -6f : v); }

    /** Seperti MLP lama: weight>0 menaikkan peluang target, weight<0 menghukum (berhenti kalau sudah jarang). */
    public float train(int hd, float[] x, int target, float weight, float lr) {
        float w = Math.max(-1f, Math.min(1f, weight));
        float[] h = hidden(x);
        float[] p = probs(hd, h);
        float loss = -(float) Math.log(Math.max(p[target], 1e-6f));
        if (w < 0f && p[target] < 0.08f) return loss;
        int n = nOut[hd];
        float[] dO = new float[n];
        for (int k = 0; k < n; k++) dO[k] = w * (p[k] - (k == target ? 1f : 0f));
        updateOut(hd, x, h, dO, lr);
        steps[hd]++;
        return loss;
    }

    /** Belajar menirukan distribusi q (dipakai memindahkan hasil latihan dari jaringan lama). */
    public float trainSoft(int hd, float[] x, float[] q, float lr) { return step(hd, x, q, lr); }

    public void write(DataOutputStream o) throws IOException {
        o.writeInt(MAGIC); o.writeInt(nIn); o.writeInt(nHid); o.writeInt(nOut[0]); o.writeInt(nOut[1]);
        o.writeLong(steps[0]); o.writeLong(steps[1]);
        for (float v : w1) o.writeFloat(v);
        for (float v : b1) o.writeFloat(v);
        for (int k = 0; k < 2; k++) { for (float v : wo[k]) o.writeFloat(v); for (float v : bo[k]) o.writeFloat(v); }
    }

    /** false kalau berkas tidak cocok. */
    public boolean read(DataInputStream i) throws IOException {
        if (i.readInt() != MAGIC || i.readInt() != nIn || i.readInt() != nHid || i.readInt() != nOut[0] || i.readInt() != nOut[1]) return false;
        steps[0] = i.readLong(); steps[1] = i.readLong();
        for (int k = 0; k < w1.length; k++) w1[k] = i.readFloat();
        for (int k = 0; k < nHid; k++) b1[k] = i.readFloat();
        for (int h = 0; h < 2; h++) { for (int k = 0; k < wo[h].length; k++) wo[h][k] = i.readFloat(); for (int k = 0; k < bo[h].length; k++) bo[h][k] = i.readFloat(); }
        return true;
    }

    public int paramCount() { return w1.length + b1.length + wo[0].length + wo[1].length + bo[0].length + bo[1].length; }
}
