package com.nara.companion

import android.graphics.Bitmap
import android.os.Build
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/**
 * Mata Nara yang sebenarnya: ambil screenshot -> simpan SATU berkas -> baca isinya (OCR di HP, tanpa internet) -> belajar.
 * Setiap screenshot baru, berkas sebelumnya dihapus (setelah isi screenshot baru selesai dipelajari). Hanya satu berkas ada pada satu waktu.
 */
object ScreenReader {
    private const val MAX_SIDE = 1600
    @Volatile var busy = false
    @Volatile var shots = 0
    @Volatile var lastLines: List<String> = emptyList()

    private val dir get() = File(NaraApp.instance.filesDir, "shot")
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Hapus semua berkas screenshot (dipanggil saat Nara dihentikan). */
    fun wipe() { try { dir.listFiles()?.forEach { it.delete() } } catch (_: Exception) {} }

    private fun fromProjection(): Bitmap? {
        val b = CaptureService.latest ?: return null
        return if (SystemClock.uptimeMillis() - CaptureService.latestAt > 6000) null else b
    }

    /** [onLearned] dipanggil di main thread: (kebaruan 0..1, baris teks yang terbaca). */
    fun capture(onLearned: (Float, List<String>) -> Unit) {
        if (busy) return
        val pkg = Shared.curPkg
        if (pkg.isEmpty() || pkg == NaraApp.instance.packageName || ScreenAccessService.isBlocked(pkg)) return
        val label = Shared.curLabel.ifEmpty { pkg }
        busy = true
        val got: (Bitmap?) -> Unit = { bmp ->
            if (bmp == null) { busy = false } else { handle(bmp, pkg, label, onLearned) }
        }
        val svc = ScreenAccessService.instance
        if (Build.VERSION.SDK_INT >= 30 && svc != null) svc.shoot { b -> got(b ?: fromProjection()) } else got(fromProjection())
    }

    private fun shrink(src: Bitmap): Bitmap {
        val s = MAX_SIDE.toFloat() / max(src.width, src.height)
        return if (s >= 1f) src else Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true)
    }

    private fun brightness(b: Bitmap): Float {
        var sum = 0f; var n = 0
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                sum += (0.299f * ((p shr 16) and 0xff) + 0.587f * ((p shr 8) and 0xff) + 0.114f * (p and 0xff)) / 255f
                n++; x += 24
            }
            y += 24
        }
        return if (n == 0) 0.5f else sum / n
    }

    private fun handle(src: Bitmap, pkg: String, label: String, cb: (Float, List<String>) -> Unit) {
        try {
            val bmp = shrink(src)
            val d = dir; d.mkdirs()
            val f = File(d, "shot_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            val bright = brightness(bmp)
            rec.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { t -> onText(t.textBlocks.flatMap { b -> b.lines }.map { l -> l.text }, pkg, label, bright, f, cb) }
                .addOnFailureListener { e -> Shared.lastErr = "ocr: $e"; cleanup(f); busy = false }
        } catch (e: Throwable) { Shared.lastErr = "shot: $e"; busy = false }
    }

    private fun onText(raw: List<String>, pkg: String, label: String, bright: Float, f: File, cb: (Float, List<String>) -> Unit) {
        try {
            val lines = raw.map { it.trim() }.filter { it.length in 2..200 && it.any { c -> c.isLetter() } }.distinct().take(120)
            lastLines = lines; shots++
            val brain = NaraApp.brain
            var nov = 0f
            if (lines.isNotEmpty()) {
                nov = brain.observeScreen(pkg, label, lines)
                brain.mem.event(pkg, "saw", label + ": " + lines.take(8).joinToString(" | "))
            }
            val tone = if (bright < 0.25f) "gelap" else if (bright > 0.7f) "terang" else "sedang"
            Shared.lastShot = "$label • ${lines.size} baris teks • layar $tone"
            cb(nov, lines)
        } catch (e: Throwable) {
            Shared.lastErr = "learn: $e"
        } finally {
            cleanup(f); busy = false
        }
    }

    /** Sisakan hanya berkas terbaru [keep]; yang sebelumnya dihapus. */
    private fun cleanup(keep: File) {
        try { dir.listFiles()?.forEach { if (it.absolutePath != keep.absolutePath) it.delete() } } catch (_: Exception) {}
    }
}
