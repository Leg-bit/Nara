package com.nara.companion

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.nara.companion.brain.Act
import com.nara.companion.brain.ScreenStats

/**
 * Mata & tangan Nara: membaca teks layar (bukan kolom sandi), mengamati sentuhanmu untuk belajar,
 * dan (bila diizinkan) melakukan scroll / tap / back.
 */
class ScreenAccessService : AccessibilityService() {
    class Cand(val cx: Float, val cy: Float, val feats: List<String>, val text: String)
    private class Acc { var count = 0; var clickable = 0; var scrollable = false; var editable = false; val texts = ArrayList<String>(); val cands = ArrayList<Cand>() }

    companion object {
        @Volatile var instance: ScreenAccessService? = null
        private val SENSITIVE = listOf("bank", "wallet", "pay", "gopay", "ovo", "dana", "bca", "bni", "mandiri", "jenius", "password", "authenticator",
            "lastpass", "keepass", "bitwarden", "otp", "com.android.settings", "packageinstaller", "permissioncontroller", "securitycenter", "securitycore")
        private val SEND_TXT = Regex("(?i)(kirim|send|cari|search|telusuri|submit)")
        private val SEND_ID = Regex("(?i)(send|submit|search_go|search_button|btn_search)")
        private val NOISE = listOf("com.android.systemui", "inputmethod", "keyboard")
        private val DANGER = Regex("(?i)(bayar|pay|transfer|hapus|delete|kirim|send|beli|buy|konfirmasi|confirm|logout|log out|keluar|sign out|uninstall|reset|izinkan|allow|setuju|agree|install|unduh|download|order|pesan|checkout|submit|post|unfollow|block|blokir|report|laporkan|tolak|accept|terima|^ok$|^ya$|^yes$)")

        fun isBlocked(pkg: String): Boolean {
            val p = pkg.lowercase()
            if (SENSITIVE.any { p.contains(it) }) return true
            return Prefs.blocklist.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { p.contains(it) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastRead = 0L
    private var lastScrollEvt = 0L
    private var lastScrollY = 0
    private var lastCands: List<Cand> = emptyList()
    private var typedBuf = ""
    private val flushTyped = Runnable {
        if (typedBuf.length > 3) NaraApp.brain.observeTyped(typedBuf)
        typedBuf = ""
    }

    override fun onServiceConnected() { instance = this; handler.postDelayed({ try { readScreen(true) } catch (ex: Throwable) { Shared.lastErr = "connect: $ex" } }, 1000) }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg.substringAfterLast('.') }

    private fun ua(a: Int) {
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        brain.observeUserAction(ctx, a)
        Shared.lastUa = a
        Shared.lastUserTouch = SystemClock.uptimeMillis()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        Shared.evCount++; Shared.lastEv = SystemClock.uptimeMillis(); Shared.lastEvPkg = e.packageName?.toString() ?: ""
        try { handle(e) } catch (ex: Throwable) { Shared.lastErr = "event: $ex" }   // jangan crash, tapi catat supaya terlihat di aplikasi
    }

    private fun handle(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || NOISE.any { pkg.contains(it) }) return
        val now = SystemClock.uptimeMillis()
        val self = now < Shared.selfActUntil
        val brain = NaraApp.brain
        if (isBlocked(pkg)) { if (Shared.curPkg != pkg) { Shared.curPkg = pkg; Shared.curTexts = emptyList(); Shared.curStats = ScreenStats() }; return }

        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (pkg != Shared.curPkg) {
                    Shared.curPkg = pkg; Shared.curLabel = label(pkg)
                    brain.observeApp(pkg, Shared.curLabel)
                    if (!self) ua(Act.SWITCH)
                    // kalau kamu pindah app sesaat setelah Nara menyentuh layar, anggap itu tanda "jangan"
                    if (now - Shared.lastSelfActionTime < 3000) brain.feedback(-0.6f)
                }
                readScreen(true)
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> if (!self) {
                val src = e.source
                if (src != null) {
                    val feats = featsOf(src, pkg)
                    val neg = lastCands.filter { it.feats != feats }.shuffled().take(6).map { it.feats }
                    brain.observeUserClick(feats, neg)
                }
                ua(Act.TAP)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> if (!self && now - lastScrollEvt > 700) {
                lastScrollEvt = now
                var dy = if (Build.VERSION.SDK_INT >= 28) e.scrollDeltaY else 0
                if (dy == 0) dy = e.scrollY - lastScrollY
                lastScrollY = e.scrollY
                if (dy != 0) ua(if (dy > 0) Act.DOWN else Act.UP)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> if (!self && !e.isPassword && Prefs.learnTyping) {
                typedBuf = e.text.joinToString(" ")
                handler.removeCallbacks(flushTyped); handler.postDelayed(flushTyped, 2500)
                ua(Act.TYPE)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> readScreen(false)
        }
    }

    private fun featsOf(n: AccessibilityNodeInfo, pkg: String): List<String> {
        val r = Rect(); n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        val f = ArrayList<String>()
        val cls = n.className?.toString() ?: "?"
        f.add("cls:$cls"); f.add("app:$pkg")
        n.viewIdResourceName?.let { f.add("id:$it"); f.add("a+id:$pkg|$it") }
        f.add("pos:${(r.centerX() * 4 / dm.widthPixels).coerceIn(0, 3)}_${(r.centerY() * 8 / dm.heightPixels).coerceIn(0, 7)}")
        f.add("a+c:$pkg|$cls")
        val txt = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
        NaraApp.brain.lm.tokenize(txt).take(5).forEach { f.add("w:$it") }
        return f
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, acc: Acc, pkg: String) {
        if (n == null || depth > 30 || acc.count > 500) return
        acc.count++
        if (n.isPassword) return
        val dm = resources.displayMetrics
        val r = Rect(); n.getBoundsInScreen(r)
        val onScreen = r.right > 0 && r.bottom > 0 && r.left < dm.widthPixels && r.top < dm.heightPixels && !r.isEmpty
        if (onScreen) {
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank() && t.length in 2..600) acc.texts.add(t.trim())
            if (n.isScrollable) acc.scrollable = true
            if (n.isEditable) acc.editable = true
            if (n.isClickable && n.isEnabled) {
                acc.clickable++
                val area = r.width().toLong() * r.height()
                if (r.width() >= 24 && r.height() >= 24 && area < 0.6 * dm.widthPixels * dm.heightPixels &&
                    !(t != null && DANGER.containsMatchIn(t.trim())) && !Rect.intersects(r, Shared.charRect)) {
                    acc.cands.add(Cand(r.exactCenterX(), r.exactCenterY(), featsOf(n, pkg), t ?: ""))
                }
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, acc, pkg)
    }

    private fun activeRoot(): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { return it }
        try {
            windows?.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root != null }?.root?.let { return it }
        } catch (_: Exception) {}
        return null
    }

    private fun readScreen(force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastRead < 2500) return
        lastRead = now
        val root = activeRoot()
        if (root == null) { Shared.lastErr = "pembaca layar: jendela aktif tidak terbaca (root null)"; return }
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || isBlocked(pkg)) return
        val acc = Acc()
        walk(root, 0, acc, pkg)
        lastCands = acc.cands
        val texts = acc.texts.distinct().take(80)
        Shared.curTexts = texts
        Shared.curStats = ScreenStats(texts.sumOf { it.length }, acc.scrollable, acc.clickable, acc.editable, Shared.visual)
        if (Shared.curPkg.isEmpty() || Shared.curPkg != pkg) { Shared.curPkg = pkg; Shared.curLabel = label(pkg) }
        Shared.readCount++; Shared.lastReadTexts = texts.size; Shared.lastReadPkg = pkg
        NaraApp.brain.observeScreen(pkg, Shared.curLabel.ifEmpty { label(pkg) }, texts)
    }

    // ------------------------------------------------------------ screenshot (Android 11+)
    fun shoot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hb = result.hardwareBuffer
                        bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (e: Throwable) { Shared.lastErr = "shot: $e" }
                    cb(bmp)
                }
                override fun onFailure(errorCode: Int) { cb(null) }
            })
        } catch (e: Throwable) { Shared.lastErr = "shot: $e"; cb(null) }
    }

    // ------------------------------------------------------------ mengetik
    private fun editableNodes(n: AccessibilityNodeInfo?, out: ArrayList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 30 || out.size > 20 || n.isPassword) return
        if (n.isEditable && n.isVisibleToUser) out.add(n)
        for (i in 0 until n.childCount) editableNodes(n.getChild(i), out, depth + 1)
    }

    private fun targetField(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let { if (it.isEditable && !it.isPassword) return it }
        val l = ArrayList<AccessibilityNodeInfo>()
        editableNodes(root, l, 0)
        return l.firstOrNull()
    }

    private fun typingRoot(): AccessibilityNodeInfo? {
        val root = activeRoot() ?: return null
        val pkg = root.packageName?.toString() ?: return null
        if (pkg == packageName || isBlocked(pkg)) return null
        return root
    }

    /** Posisi kolom ketik di layar (untuk animasi kursor), atau null kalau tidak ada. */
    fun editableCenter(): Pair<Float, Float>? {
        val node = targetField(typingRoot() ?: return null) ?: return null
        val r = Rect(); node.getBoundsInScreen(r)
        return Pair(r.exactCenterX(), r.exactCenterY())
    }

    /** Mengetik [text] ke kolom yang sedang fokus (atau kolom ketik pertama di layar). Bukan kolom sandi / app sensitif. */
    fun typeInto(text: String, submit: Boolean): Boolean {
        val root = typingRoot() ?: return false
        val node = targetField(root) ?: return false
        markSelf(2500)
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit) handler.postDelayed({ try { submitNow() } catch (e: Throwable) { Shared.lastErr = "submit: $e" } }, 600)
        return ok
    }

    private fun findSend(n: AccessibilityNodeInfo?, d: Int): AccessibilityNodeInfo? {
        if (n == null || d > 30) return null
        if (n.isClickable && n.isEnabled && n.isVisibleToUser) {
            val t = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
            val id = n.viewIdResourceName ?: ""
            if ((t.length in 1..24 && SEND_TXT.containsMatchIn(t)) || SEND_ID.containsMatchIn(id)) return n
        }
        for (i in 0 until n.childCount) findSend(n.getChild(i), d + 1)?.let { return it }
        return null
    }

    private fun submitNow() {
        val root = typingRoot() ?: return
        markSelf(1500)
        val btn = findSend(root, 0)
        if (btn != null) { btn.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        if (Build.VERSION.SDK_INT >= 30) {
            val f = targetField(root) ?: return
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    // ------------------------------------------------------------ tindakan Nara
    fun canAct(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return pm.isInteractive && !km.isKeyguardLocked && Shared.curPkg.isNotEmpty() && !isBlocked(Shared.curPkg) && !Shared.paused
    }

    /** Baca ulang layar sekarang dan kembalikan teksnya (mis. jawaban AI). */
    fun freshTexts(): List<String> { try { readScreen(true) } catch (_: Throwable) {}; return Shared.curTexts }

    fun candidates(): List<Cand> { readScreen(true); return lastCands }

    private fun markSelf(durMs: Long) {
        val now = SystemClock.uptimeMillis()
        Shared.selfActUntil = now + durMs + 1200
        Shared.lastSelfActionTime = now
    }

    private fun gesture(p: Path, dur: Long) {
        markSelf(dur)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    fun swipe(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val y1 = dm.heightPixels * (if (down) 0.68f else 0.35f)
        val y2 = dm.heightPixels * (if (down) 0.35f else 0.68f)
        gesture(Path().apply { moveTo(x, y1); lineTo(x, y2) }, 320)
    }

    fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }, 60)

    fun back() { markSelf(300); performGlobalAction(GLOBAL_ACTION_BACK) }
}
