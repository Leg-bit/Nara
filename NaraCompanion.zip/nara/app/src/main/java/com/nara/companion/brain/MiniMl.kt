package com.nara.companion.brain

import java.io.File
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Mini ML #1: Naive Bayes — menebak "jenis konten" (app) dari kata-kata di layar. */
class TopicNB {
    private val wc = HashMap<String, HashMap<String, Int>>()
    private val tot = HashMap<String, Int>()
    private val docs = HashMap<String, Int>()
    private val vocab = HashSet<String>()

    fun learn(label: String, words: List<String>) {
        if (words.isEmpty()) return
        if (wc.size >= 60 && !wc.containsKey(label)) return
        val m = wc.getOrPut(label) { HashMap() }
        for (w in words.take(150)) { m.merge(w, 1, Int::plus); tot.merge(label, 1, Int::plus); vocab.add(w) }
        if (m.size > 400) m.entries.removeAll { it.value <= 1 }   // buang kata langka: model tetap ringkas
        docs.merge(label, 1, Int::plus)
    }

    /** (label terbaik, keyakinan 0..1). */
    fun predict(words: List<String>): Pair<String, Float>? {
        if (wc.size < 2 || words.isEmpty()) return null
        val nDocs = docs.values.sum().toDouble(); val v = max(1, vocab.size).toDouble()
        val scores = wc.keys.associateWith { l ->
            var s = ln((docs[l] ?: 1) / nDocs)
            for (w in words.take(100)) s += ln(((wc[l]!![w] ?: 0) + 1.0) / ((tot[l] ?: 0) + v))
            s
        }
        val best = scores.maxByOrNull { it.value } ?: return null
        val z = scores.values.sumOf { exp(it - best.value) }
        return best.key to (1.0 / z).toFloat()
    }

    fun save(f: File) = f.bufferedWriter().use { w ->
        for ((l, m) in wc) for ((word, c) in m.entries.sortedByDescending { it.value }.take(150)) w.write("$l\t$word\t$c\n")
        for ((l, d) in docs) w.write("#\t$l\t$d\n")
    }

    fun load(f: File) {
        if (!f.exists()) return
        f.forEachLine { line ->
            val p = line.split('\t'); if (p.size < 3) return@forEachLine
            val c = p[2].toIntOrNull() ?: return@forEachLine
            if (p[0] == "#") docs[p[1]] = c
            else { wc.getOrPut(p[0]) { HashMap() }[p[1]] = c; tot.merge(p[0], c, Int::plus); vocab.add(p[1]) }
        }
    }
}

/** Mini ML #2: regresi logistik ber-hash — belajar NODE mana di layar yang biasa kamu sentuh. */
class NodeScorer {
    companion object { const val DIM = 4096 }
    val w = FloatArray(DIM)
    var updates = 0L

    private fun idx(f: String) = (f.hashCode() and 0x7fffffff) % DIM
    fun score(feats: List<String>): Float { var s = 0f; for (f in feats) s += w[idx(f)]; return s }
    fun prob(feats: List<String>): Float = (1.0 / (1.0 + exp(-score(feats).toDouble()))).toFloat()

    fun update(feats: List<String>, label: Float, lr: Float = 0.3f) {
        val err = label - prob(feats)
        for (f in feats) { val i = idx(f); w[i] = (w[i] + lr * err).coerceIn(-8f, 8f) }
        updates++
    }

    fun save(f: File) = f.outputStream().buffered().use { o ->
        java.io.DataOutputStream(o).also { d -> d.writeLong(updates); for (v in w) d.writeFloat(v) }.flush()
    }

    fun load(f: File) {
        if (!f.exists()) return
        try {
            java.io.DataInputStream(f.inputStream().buffered()).use { d ->
                updates = d.readLong(); for (i in w.indices) w[i] = d.readFloat()
            }
        } catch (_: Exception) {}
    }
}

/** Mini ML #3: kebiasaan jam-aplikasi (Markov sederhana) — "biasanya jam segini kamu buka X". */
class HabitModel {
    private val byHour = HashMap<Int, HashMap<String, Int>>()
    fun learn(hour: Int, app: String) { byHour.getOrPut(hour) { HashMap() }.merge(app, 1, Int::plus) }
    fun usual(hour: Int): String? {
        val m = byHour[hour] ?: return null
        val best = m.maxByOrNull { it.value } ?: return null
        return if (best.value >= 4) best.key else null
    }
    fun save(f: File) = f.bufferedWriter().use { w -> for ((h, m) in byHour) for ((a, c) in m) w.write("$h\t$a\t$c\n") }
    fun load(f: File) {
        if (!f.exists()) return
        f.forEachLine { l -> val p = l.split('\t'); if (p.size == 3) byHour.getOrPut(p[0].toIntOrNull() ?: return@forEachLine) { HashMap() }[p[1]] = p[2].toIntOrNull() ?: 0 }
    }
}
