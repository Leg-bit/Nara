#!/usr/bin/env python3
"""Periksa & rapikan bank obrolan (chat.txt / seed.txt): format 'ucapan1; ucapan2 => balasan1; balasan2'.
Jalankan di Pydroid/Termux:  python check_pairs.py ../app/src/main/assets/chat.txt
Melaporkan: baris rusak, ucapan ganda yang bertabrakan antar aturan, balasan terlalu panjang/kosong, dan statistik."""
import sys, re, collections

def main(path):
    seen = collections.defaultdict(list); bad = 0; rules = 0; pairs = 0
    for n, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.rstrip("\n")
        if not line.strip() or line.startswith("S:"): continue
        if "=>" not in line: print(f"baris {n}: tidak ada '=>'"); bad += 1; continue
        l, r = line.split("=>", 1)
        ps = [p.strip().lower() for p in l.split(";") if p.strip()]; rs = [x.strip() for x in r.split(";") if x.strip()]
        if not ps or not rs: print(f"baris {n}: ucapan atau balasan kosong"); bad += 1; continue
        rules += 1; pairs += len(ps) * len(rs)
        for x in rs:
            if len(x.split()) > 28: print(f"baris {n}: balasan terlalu panjang ({len(x.split())} kata): {x[:50]}...")
        for p in ps: seen[p].append(n)
    for p, ns in seen.items():
        if len(ns) > 1: print(f"ucapan ganda '{p}' di baris {ns} (balasan akan digabung; pastikan masih nyambung)")
    print(f"\n{rules} aturan, {len(seen)} ucapan unik, {pairs} pasangan, {bad} baris rusak")

if __name__ == "__main__": main(sys.argv[1] if len(sys.argv) > 1 else "chat.txt")
