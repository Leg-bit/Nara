# Memotong sprite sheet (tools/sheet.png) menjadi frame per-baris untuk app.
# Jalankan: python3 slice_sheet.py
import os, glob
import numpy as np
from PIL import Image, ImageOps, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "app", "src", "main", "assets", "sprites")
os.makedirs(OUT, exist_ok=True)
for f in glob.glob(os.path.join(OUT, "*_*.png")): os.remove(f)
for f in glob.glob(os.path.join(OUT, "faces*")):
    if os.path.isdir(f):
        for g in glob.glob(os.path.join(f, "*")): os.remove(g)
        os.rmdir(f)
    else: os.remove(f)

ROWS = [("idle", 8), ("sit", 8), ("walk", 9), ("run", 9), ("happy", 8), ("annoyed", 8)]
LABEL_X = 155      # kiri = panel label, dilewati
UP = 4             # perbesar 4x (Lanczos premultiplied + penajaman halus tanpa halo) supaya tajam di layar HP

sheet = Image.open(os.path.join(HERE, "sheet.png")).convert("RGBA")
A = np.array(sheet)[..., 3] > 20
H, W = A.shape

def runs(mask1d, offset, min_len=1):
    out, s = [], None
    for i, v in enumerate(mask1d):
        if v and s is None: s = i
        if not v and s is not None:
            if i - s >= min_len: out.append((s + offset, i + offset))
            s = None
    if s is not None: out.append((s + offset, len(mask1d) + offset))
    return out

bands = runs(A[:, LABEL_X:].any(axis=1), 0, 40)
assert len(bands) == len(ROWS), bands
def body_mask(arr):
    al = arr[..., 3] > 200
    luma = (arr[..., 0].astype(int) * 299 + arr[..., 1].astype(int) * 587 + arr[..., 2].astype(int) * 114) // 1000
    sat = arr[..., :3].max(axis=2).astype(int) - arr[..., :3].min(axis=2).astype(int)
    return al & (luma < 70) & (sat < 60), al & (sat > 120) & (luma > 90)

def anchor_x(crop):
    """Titik tumpu horizontal = pusat BADAN gelap (tanpa jubah neon yang berayun) -> frame tidak goyang."""
    arr = np.array(crop)
    body, _ = body_mask(arr)
    h = body.shape[0]
    body[: int(h * 0.15)] = False; body[int(h * 0.85):] = False
    if body.sum() < 50:
        al = arr[..., 3].astype(float)
        return (al.sum(axis=0) * np.arange(al.shape[1])).sum() / max(al.sum(), 1)
    return np.nonzero(body)[1].mean()

def native_facing(lst):
    """Jubah mengikuti di belakang: jubah di kiri badan = menghadap kanan ('R'), sebaliknya 'L'."""
    votes = 0
    for crop, _ in lst:
        body, cape = body_mask(np.array(crop))
        if body.sum() < 50 or cape.sum() < 50: continue
        votes += 1 if np.nonzero(cape)[1].mean() < np.nonzero(body)[1].mean() else -1
    return "R" if votes > 0 else "L"

def hd_up(cell):
    """Perbesar UP x tanpa pinggiran gelap/terang: resample dalam ruang premultiplied, lalu unsharp mask pada premultiplied."""
    big = cell.convert("RGBa").resize((cell.width * UP, cell.height * UP), Image.LANCZOS)
    a = np.array(big).astype(np.float32)
    alpha = a[..., 3:4]
    ch = []
    for k in range(3):
        im = Image.fromarray(a[..., k].clip(0, 255).astype(np.uint8))
        bl = np.array(im.filter(ImageFilter.GaussianBlur(1.6))).astype(np.float32)
        ch.append(a[..., k] + 0.9 * (a[..., k] - bl))
    rgb = np.stack(ch, axis=-1)
    rgb = np.minimum(np.clip(rgb, 0, 255), alpha)        # premultiplied: RGB tidak boleh melebihi alpha
    out = np.concatenate([rgb, alpha], axis=-1).astype(np.uint8)
    return Image.fromarray(out, "RGBa").convert("RGBA")

frames = {}
for (name, n), (y0, y1) in zip(ROWS, bands):
    segs = runs(A[y0:y1, LABEL_X:].any(axis=0), LABEL_X, 20)[:n]
    assert len(segs) == n, (name, len(segs))
    frames[name] = ([(sheet.crop((x0, y0, x1, y1)), None) for x0, x1 in segs], y1 - y0)
    frames[name] = ([(c, anchor_x(c)) for c, _ in frames[name][0]], y1 - y0)

half = max(max(cx, c.width - cx) for lst, _ in frames.values() for c, cx in lst)
CW = int(2 * half) + 6
facing = {}
for name, (lst, hgt) in frames.items():
    cells = []
    for crop, cx in lst:
        cell = Image.new("RGBA", (CW, hgt + 2), (0, 0, 0, 0))
        cell.alpha_composite(crop, (int(round(CW / 2 - cx)), 0))
        cells.append(hd_up(cell))
    if name in ("walk", "run"):
        nat = native_facing(lst); other = "L" if nat == "R" else "R"; facing[name] = nat
        for i, c in enumerate(cells):
            c.save(os.path.join(OUT, f"{name}_{nat}_{i}.png"))                      # arah asli
            ImageOps.mirror(c).save(os.path.join(OUT, f"{name}_{other}_{i}.png"))   # cermin
    else:
        for i, c in enumerate(cells): c.save(os.path.join(OUT, f"{name}_{i}.png"))
print("cell width", CW * UP, "native facing:", facing)

# ikon launcher dari kepala frame idle
idle0 = Image.open(os.path.join(OUT, "idle_0.png"))
bb = idle0.getbbox(); head = idle0.crop((bb[0], bb[1], bb[2], bb[1] + (bb[3] - bb[1]) // 2))
s = max(head.size); bg = Image.new("RGBA", (s + 40, s + 40), (20, 22, 40, 255))
bg.alpha_composite(head, ((bg.width - head.width) // 2, 20))
d = os.path.join(HERE, "..", "app", "src", "main", "res", "mipmap-xxhdpi"); os.makedirs(d, exist_ok=True)
bg.resize((144, 144), Image.LANCZOS).save(os.path.join(d, "ic_launcher.png"))
