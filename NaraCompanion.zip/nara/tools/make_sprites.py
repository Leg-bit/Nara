# Generator aset karakter Nara (orisinal, prosedural). Jalankan: python3 make_sprites.py
import math, random, os
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

W, H, S = 400, 800, 3
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "sprites")
os.makedirs(OUT, exist_ok=True)

SKIN=(222,178,156); SKIN_S=(176,128,116); SKIN_H=(238,200,180)
JACK=(40,44,62); JACK_S=(24,26,38); TRIM=(70,212,224)
LEG=(30,32,52); LEG_S=(18,19,32); BOOT=(16,16,22)
HAIR=(70,44,130); HAIR_S=(38,24,80); HAIR_H=(150,104,230); STREAK=(64,206,220)

def rot(p, a): return (math.sin(math.radians(a)), math.cos(math.radians(a)))
def end(p, a, l):
    d = rot(p, a); return (p[0]+d[0]*l, p[1]+d[1]*l)

class Canvas:
    def __init__(self):
        self.im = Image.new("RGBA", (W*S, H*S), (0,0,0,0)); self.d = ImageDraw.Draw(self.im)
    def poly(self, pts, fill): self.d.polygon([(x*S, y*S) for x,y in pts], fill=fill)
    def circ(self, c, r, fill):
        self.d.ellipse([(c[0]-r)*S,(c[1]-r)*S,(c[0]+r)*S,(c[1]+r)*S], fill=fill)
    def line(self, a, b, w, fill): self.d.line([(a[0]*S,a[1]*S),(b[0]*S,b[1]*S)], fill=fill, width=int(w*S))
    def limb(self, p0, p1, w0, w1, col, shade):
        dx, dy = p1[0]-p0[0], p1[1]-p0[1]; L = math.hypot(dx, dy) or 1
        nx, ny = -dy/L, dx/L
        a=(p0[0]+nx*w0, p0[1]+ny*w0); b=(p1[0]+nx*w1, p1[1]+ny*w1)
        c=(p1[0]-nx*w1, p1[1]-ny*w1); d=(p0[0]-nx*w0, p0[1]-ny*w0)
        self.poly([a,b,c,d], col)
        self.poly([(p0[0],p0[1]),(p1[0],p1[1]),c,d], shade)       # sisi gelap -> kesan faset
        self.circ(p0, w0, col); self.circ(p1, w1, shade if col!=SKIN else col)

def draw(pose):
    c = Canvas(); cx = 200
    dy = pose.get("down", 0); sway = pose.get("sway", 0); lean = pose.get("lean", 0)
    hs = pose.get("hair", 0); mouth = pose.get("mouth", 0); eyes = pose.get("eyes", 1)
    P = lambda x, y: (x + lean*(max(0, 380-y)/380.0) + sway*0, y + dy)
    # ---------- rambut belakang (panjang, bersudut) ----------
    back = [P(cx-46,60),P(cx-70,120),P(cx-84+hs,230),P(cx-66+hs,300),P(cx-78+hs*1.4,372),P(cx-44+hs,330),
            P(cx-30,380+0),P(cx,330),P(cx+30,396),P(cx+44-hs,330),P(cx+80-hs*1.4,368),P(cx+66-hs,296),
            P(cx+84-hs,226),P(cx+70,118),P(cx+46,60),P(cx,30)]
    c.poly(back, HAIR_S)
    c.poly([P(cx-40,70),P(cx-62,150),P(cx-70+hs,250),P(cx-30,200)], HAIR)
    # ---------- kaki ----------
    legs = pose.get("legs", ((0,0),(0,0))); foot_lift = pose.get("lift", (0,0))
    for side, (th, sh), lift in ((-1, legs[0], foot_lift[0]), (1, legs[1], foot_lift[1])):
        hip = P(cx+side*21, 352)
        knee = end(hip, side*5+th, 180*pose.get("thigh_len", 1.0))
        ank  = end(knee, side*4+sh, 168*pose.get("shin_len", 1.0)); ank = (ank[0], ank[1]-lift)
        c.limb(hip, knee, 24, 17, LEG, LEG_S)
        c.limb(knee, ank, 17, 11, LEG, LEG_S)
        foot = (ank[0]+side*14, ank[1]+22)
        c.poly([(ank[0]-13,ank[1]-8),(ank[0]+13,ank[1]-8),(foot[0]+side*20,foot[1]+2),(ank[0]-side*16,foot[1]+2)], BOOT)
        c.line((ank[0]-side*16,foot[1]),(foot[0]+side*20,foot[1]),2.5,TRIM)
        # lutut bersinar tipis
        c.line((knee[0]-6,knee[1]-2),(knee[0]+6,knee[1]+2),1.2,(60,70,110))
    # ---------- torso ----------
    tor = [P(cx-46,176),P(cx+46,176),P(cx+36,290),P(cx+48,356),P(cx-48,356),P(cx-36,290)]
    c.poly(tor, JACK)
    c.poly([P(cx,176),P(cx+46,176),P(cx+36,290),P(cx+48,356),P(cx,356)], JACK_S)
    c.poly([P(cx-6,176),P(cx+6,176),P(cx+4,356),P(cx-4,356)], TRIM)                       # ritsleting neon
    c.poly([P(cx-48,340),P(cx+48,340),P(cx+54,366),P(cx-54,366)], LEG_S)                  # sabuk/pinggang
    c.poly([P(cx-46,176),P(cx-20,176),P(cx-30,214)], (58,64,90))                            # kerah segitiga
    c.poly([P(cx+46,176),P(cx+20,176),P(cx+30,214)], (30,33,48))
    # ---------- leher ----------
    c.limb(P(cx,140), P(cx,180), 11, 13, SKIN, SKIN_S)
    # ---------- lengan ----------
    arms = pose.get("arms", ((0,0),(0,0)))
    for side, (up, fo) in ((-1, arms[0]), (1, arms[1])):
        sh = P(cx+side*48, 184)
        el = end(sh, side*10+up, 128)
        wr = end(el, side*6+fo, 118)
        c.limb(sh, el, 15, 11, JACK, JACK_S)
        c.limb(el, wr, 11, 8, JACK, JACK_S)
        c.line((el[0]-9,el[1]+0),(el[0]+9,el[1]+0),2,TRIM)
        hand = end(wr, side*6+fo, 26)
        c.limb(wr, hand, 8, 6, SKIN, SKIN_S)
        for k in (-1,0,1):
            f = end(hand, side*6+fo+k*14, 16); c.line(hand, f, 2.4, SKIN)
    # ---------- kepala ----------
    hc = P(cx, 100)
    face = [(hc[0]-28,hc[1]-30),(hc[0]+28,hc[1]-30),(hc[0]+30,hc[1]+4),(hc[0]+17,hc[1]+34),(hc[0],hc[1]+42),
            (hc[0]-17,hc[1]+34),(hc[0]-30,hc[1]+4)]
    c.poly(face, SKIN)
    c.poly([(hc[0],hc[1]-30),(hc[0]+28,hc[1]-30),(hc[0]+30,hc[1]+4),(hc[0]+17,hc[1]+34),(hc[0],hc[1]+42)], SKIN_S)
    c.poly([(hc[0]-26,hc[1]-6),(hc[0]-4,hc[1]-8),(hc[0]-12,hc[1]+14)], SKIN_H)
    # mata
    for side in (-1, 1):
        ex = hc[0]+side*13; ey = hc[1]+2
        if eyes:
            c.poly([(ex-9,ey),(ex,ey-5),(ex+9,ey-1),(ex+1,ey+4)], (245,245,250))
            c.circ((ex+side*0.5,ey-0.5), 4.2, (40,170,190)); c.circ((ex+side*0.5,ey-0.5), 2.0, (10,14,24))
            c.line((ex-10,ey-1),(ex,ey-6),1.6,(20,18,30)); c.line((ex,ey-6),(ex+10,ey-2),1.6,(20,18,30))
        else:
            c.line((ex-9,ey),(ex,ey+3),1.8,(24,20,32)); c.line((ex,ey+3),(ex+9,ey),1.8,(24,20,32))
        c.line((ex-10,ey-10-side*1),(ex+10,ey-12+side*1),1.8,HAIR_S)   # alis
    c.line((hc[0]+2,hc[1]+8),(hc[0]+5,hc[1]+19),1.2,SKIN_S)             # hidung
    c.line((hc[0]+5,hc[1]+19),(hc[0]-1,hc[1]+20),1.2,SKIN_S)
    my = hc[1]+29
    if mouth<=0:
        c.line((hc[0]-8,my),(hc[0]+8,my-1),2.0,(150,70,84))
    else:
        h = 3+mouth*3
        c.poly([(hc[0]-8,my-1),(hc[0],my-2),(hc[0]+8,my-1),(hc[0],my+h)], (96,30,48))
    # ---------- poni & rambut depan (bersudut, asimetris) ----------
    c.poly([(hc[0]-34,hc[1]-8),(hc[0]-32,hc[1]-40),(hc[0],hc[1]-52),(hc[0]+34,hc[1]-40),(hc[0]+32,hc[1]-6),
            (hc[0]+20,hc[1]-24),(hc[0]+6,hc[1]-14),(hc[0]-10,hc[1]-30),(hc[0]-24,hc[1]-6)], HAIR)
    c.poly([(hc[0]-34,hc[1]-8),(hc[0]-46+hs,hc[1]+60),(hc[0]-26,hc[1]+14),(hc[0]-30,hc[1]-4)], HAIR_S)
    c.poly([(hc[0]+32,hc[1]-6),(hc[0]+44-hs,hc[1]+70),(hc[0]+24,hc[1]+10)], HAIR_S)
    c.poly([(hc[0]-6,hc[1]-50),(hc[0]+18,hc[1]-34),(hc[0]+8,hc[1]-12),(hc[0]-2,hc[1]-30)], HAIR_H)
    c.poly([(hc[0]-26,hc[1]-30),(hc[0]-20,hc[1]-8),(hc[0]-30,hc[1]+30),(hc[0]-34,hc[1]-6)], STREAK)
    img = c.im.resize((W, H), Image.LANCZOS)
    a = np.array(img).astype(np.int16)
    rng = np.random.default_rng(3); n = rng.integers(-9, 10, size=a.shape[:2])[..., None]
    a[..., :3] = np.clip(a[..., :3] + n, 0, 255)   # grain halus: tidak terlihat 'kartun flat'
    out = Image.fromarray(a.astype(np.uint8), "RGBA")
    return out

def crop_save(name, im, sleep=False):
    im.save(os.path.join(OUT, name + ".png"))

def L(a, b=0): return (a, b)
STAND = ((( -3,-2),(3,2)))
poses = {}
poses["idle_0"] = dict(arms=((-2,-4),(2,4)), legs=((0,0),(0,0)))
poses["idle_1"] = dict(arms=((-4,-8),(4,8)), legs=((0,0),(0,0)), hair=5, down=1)
poses["blink_0"] = dict(arms=((-2,-4),(2,4)), legs=((0,0),(0,0)), eyes=0)
poses["talk_0"] = dict(arms=((-4,-10),(4,10)), legs=((0,0),(0,0)), mouth=1)
poses["talk_1"] = dict(arms=((-6,-16),(6,16)), legs=((0,0),(0,0)), mouth=2, hair=3)
walk = [((6,-6),(-8,14),(-4,4),(0,0)), ((0,0),(0,0),(0,0),(0,0)), ((-6,6),(8,-14),(4,-4),(0,0)), ((0,0),(0,0),(0,0),(0,0))]
for i,(al,ar,ll,lr) in enumerate([
    (( 14, 0),(-14,-8),( 6, 4),(-6,-4)),
    (( 0, 0),( 0, 0),( 0, 0),( 0, 0)),
    ((-14,-8),( 14, 0),(-6,-4),( 6, 4)),
    (( 0, 0),( 0, 0),( 0, 0),( 0, 0))]):
    lift = (14,0) if i==0 else ((0,14) if i==2 else (0,0))
    poses[f"walk_{i}"] = dict(arms=(al,ar), legs=(ll,lr), lift=lift, lean=8, hair=(8 if i in (0,2) else 0)*(1 if i==0 else -1), down=(3 if i in (0,2) else 0))
poses["wave_0"] = dict(arms=((-2,-4),(122,146)), legs=((0,0),(0,0)), mouth=1)
poses["wave_1"] = dict(arms=((-2,-4),(130,112)), legs=((0,0),(0,0)), mouth=1)
poses["wave_2"] = dict(arms=((-2,-4),(122,170)), legs=((0,0),(0,0)))
poses["touch_0"] = dict(arms=((-2,-4),(110,100)), legs=((0,0),(0,0)), lean=6)
poses["touch_1"] = dict(arms=((-2,-4),(118,104)), legs=((0,0),(0,0)), lean=8, mouth=1)
poses["sit_0"]  = dict(arms=((-8,-14),(8,14)), legs=((-30,34),(30,-34)), thigh_len=0.5, shin_len=0.75, down=190)
poses["sit_1"]  = dict(arms=((-8,-14),(8,14)), legs=((-30,34),(30,-34)), thigh_len=0.5, shin_len=0.75, down=190, mouth=1)
poses["sleep_0"] = dict(arms=((-6,-10),(6,10)), legs=((0,2),(0,-2)), eyes=0)

for name, p in poses.items():
    im = draw(p)
    if name.startswith("sit"):
        pass
    if name.startswith("sleep"):
        im = im.rotate(90, expand=True)           # rebah, kepala di kiri/kanan
        im = im.crop((0, 0, 800, 400))
        # bawah-ratakan: kanvas tetap 800x400
    crop_save(name, im)

# ikon & kursor
face = draw(poses["idle_0"]).crop((120, 20, 280, 180)).resize((192,192), Image.LANCZOS)
bg = Image.new("RGBA",(192,192),(20,22,40,255)); bg.alpha_composite(face)
os.makedirs(os.path.join(OUT,"..","..","res","mipmap-xxhdpi"), exist_ok=True)
bg.resize((144,144), Image.LANCZOS).save(os.path.join(OUT,"..","..","res","mipmap-xxhdpi","ic_launcher.png"))
cur = Image.new("RGBA",(96,96),(0,0,0,0)); d = ImageDraw.Draw(cur)
for r,al in ((46,40),(36,90),(26,170)): d.ellipse([48-r,48-r,48+r,48+r], outline=(70,212,224,al), width=4)
d.ellipse([40,40,56,56], fill=(235,250,255,255))
cur.save(os.path.join(OUT, "cursor.png"))
print("ok", sorted(os.listdir(OUT)))
