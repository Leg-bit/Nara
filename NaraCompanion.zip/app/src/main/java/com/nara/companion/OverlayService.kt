package com.nara.companion

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.nara.companion.brain.Act
import com.nara.companion.brain.Body
import com.nara.companion.brain.Emo
import com.nara.companion.brain.Inter
import org.json.JSONObject
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.max

/** Tubuh Nara: karakter humanoid yang berjalan di atas semua aplikasi dan bertindak dari dorongan internalnya. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        const val CH = "nara_main"
        const val A_PAUSE = "com.nara.companion.PAUSE"
        const val A_STOP = "com.nara.companion.STOP"
        private const val TOUCH = 10
    }

    private val h = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var img: CharacterView
    private var menu: LinearLayout? = null
    private var spriteScale = 1f
    private var running = false
    private var lastHeart = 0L
    private lateinit var lp: WindowManager.LayoutParams
    private var cursorBmp: Bitmap? = null
    private val sprites = HashMap<String, List<Bitmap>>()
    private val flipped = HashMap<String, List<Bitmap>>()
    private var sw = 0; private var sh = 0; private var density = 1f
    private var state = Body.IDLE
    private var stateUntil = 0L
    private var facingRight = true
    private var px = 60f; private var tx = 60f
    private var yMargin = 0
    private var frame = 0
    private var talkUntil = 0L; private var blinkUntil = 0L
    private var lastInteract = 0L; private var lastComment = 0L; private var lastIdleTrain = 0L; private var lastSave = 0L
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startFg(false)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density
        loadSprites()
        buildViews()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID") }
        ready = true
        val now = SystemClock.uptimeMillis()
        lastInteract = now; lastComment = now; lastSave = now
        h.post(animTick); h.postDelayed(thinkTick, 1000)
        h.postDelayed({ speak(if (NaraApp.brain.lang == "id") "Hai${NaraApp.brain.mem.fact("name")?.let { " $it" } ?: ""}! Aku sudah di sini." else "Hi! I'm here.") }, 800)
    }

    // ------------------------------------------------------------ notifikasi
    private fun startFg(paused: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Nara", NotificationManager.IMPORTANCE_LOW))
        fun svc(a: String) = PendingIntent.getService(this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("chat", true), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(if (paused) "Nara dijeda" else "Nara aktif").setContentText("Ketuk untuk ngobrol")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, if (paused) "Lanjut" else "Jeda", svc(A_PAUSE)).build())
            .addAction(Notification.Action.Builder(0, "Stop", svc(A_STOP)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 0x40000000 /* FOREGROUND_SERVICE_TYPE_SPECIAL_USE */) else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_PAUSE -> { Shared.paused = !Shared.paused; startFg(Shared.paused); if (ready) speak(if (Shared.paused) "Oke, aku diam dulu." else "Aku lanjut ya.") }
            A_STOP -> { stopSelf() }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------ tampilan
    private fun loadSprites() {
        val groups = mapOf("idle" to 8, "sit" to 8, "walk" to 9, "run" to 9, "happy" to 8, "annoyed" to 8)
        val refH = assets.open("sprites/idle_0.png").use { BitmapFactory.decodeStream(it).height }
        val scale = (sh * Prefs.sizePct / 100f) / refH   // tinggi karakter = % tinggi layar
        spriteScale = scale
        for ((g, n) in groups) {
            val l = ArrayList<Bitmap>()
            for (i in 0 until n) assets.open("sprites/${g}_$i.png").use { st ->
                val b = BitmapFactory.decodeStream(st)
                l.add(Bitmap.createScaledBitmap(b, max(1, (b.width * scale).toInt()), max(1, (b.height * scale).toInt()), true))
            }
            sprites[g] = l
        }
        cursorBmp = assets.open("sprites/cursor.png").use { BitmapFactory.decodeStream(it) }
    }

    /** Daftar frame; versi cermin dibuat sekali saat pertama dibutuhkan (hemat memori). */
    private fun frames(name: String, right: Boolean): List<Bitmap>? {
        val l = sprites[name] ?: return null
        if (right) return l
        return flipped.getOrPut(name) { l.map { Bitmap.createBitmap(it, 0, 0, it.width, it.height, Matrix().apply { preScale(-1f, 1f) }, true) } }
    }

    private fun buildViews() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bubble = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; visibility = View.GONE
            setPadding((12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt())
            maxWidth = (sw * 0.6f).toInt()
            background = GradientDrawable().apply { cornerRadius = 16 * density; setColor(Color.argb(225, 20, 24, 44)); setStroke((1.5f * density).toInt(), Color.rgb(70, 212, 224)) }
        }
        img = CharacterView(this)
        root.addView(bubble, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(img, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        img.show(sprites["idle"]!![0], null, 0, 0)
        yMargin = (sh * 0.045f).toInt()
        px = (sw * 0.1f)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = px.toInt(); y = yMargin }
        wm.addView(root, lp)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { doInteract(if (isHead(e.y)) Inter.PAT else Inter.POKE); return true }
            override fun onLongPress(e: MotionEvent) { showMenu() }
        })
        val ox = Osc(); val oy = Osc()
        var downX = 0f; var downY = 0f; var startPx = 0f; var startY = 0
        var dragging = false; var rubbing = false; var lastRev = 0
        img.setOnTouchListener { _, ev ->
            val step = 4f * density; val seg = 14f * density
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startPx = px; startY = yMargin
                    dragging = false; rubbing = false; lastRev = 0
                    ox.reset(ev.rawX); oy.reset(ev.rawY); dismissMenu()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    val dist = abs(dx) + abs(dy)
                    if (!dragging) {
                        ox.feed(ev.rawX, step, seg); oy.feed(ev.rawY, step, seg)
                        val rev = max(ox.rev, oy.rev)
                        if (rev >= 2 && dist < 70f * density) {
                            rubbing = true
                            val now = SystemClock.uptimeMillis()
                            if (rev > lastRev && now - lastRub > 700) { lastRev = rev; lastRub = now; doInteract(Inter.RUB) }
                        } else if (!rubbing && dist > 45f * density) {
                            dragging = true; doInteract(Inter.LIFT)
                        }
                    }
                    if (dragging) {
                        px = startPx + dx; yMargin = (startY - dy).toInt().coerceIn(0, sh - 200); applyPos()
                        state = Body.IDLE; stateUntil = SystemClock.uptimeMillis() + 3000
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) { doInteract(Inter.DROP); dragging = false }
                    rubbing = false
                }
            }
            gd.onTouchEvent(ev)
        }
    }

    /** Pendeteksi gerakan bolak-balik (elus). */
    private class Osc {
        var last = 0f; var dir = 0; var seg = 0f; var rev = 0
        fun reset(v: Float) { last = v; seg = v; dir = 0; rev = 0 }
        fun feed(v: Float, step: Float, minSeg: Float) {
            val d = v - last
            if (abs(d) < step) return
            val nd = if (d > 0) 1 else -1
            if (dir != 0 && nd != dir && abs(last - seg) >= minSeg) { rev++; seg = last }
            dir = nd; last = v
        }
    }
    private var lastRub = 0L

    private fun isHead(y: Float) = state != Body.SLEEP && y < img.height * 0.38f

    private fun doInteract(kind: Int) {
        val brain = NaraApp.brain
        val now = SystemClock.uptimeMillis()
        val id = brain.lang == "id"
        if (state == Body.SLEEP && kind != Inter.SLEEP && kind != Inter.SNACK && kind != Inter.DROP) {
            state = Body.IDLE; stateUntil = now + 4000
            brain.mood.impulse(if (brain.drives.energy < 0.5f) Emo.ANGRY else Emo.SURPRISED, -0.05f, 3500)
            speak(if (id) "Hmm… masih ngantuk…" else "Mmm… still sleepy…")
            return
        }
        val r = brain.interact(kind)
        when (kind) {
            Inter.HIGH5 -> { state = Body.WAVE; stateUntil = now + 1800 }
            Inter.SLEEP -> { state = Body.SLEEP; stateUntil = now + 30_000 }
            Inter.SNACK, Inter.HUG, Inter.PAT, Inter.RUB, Inter.POKE, Inter.SCOLD -> if (state == Body.WALK || state == TOUCH) { state = Body.IDLE; stateUntil = now + 3500 }
        }
        var t = r.text
        if (t == null && now - lastHeart > 2500) {
            t = when (r.emo) { Emo.HAPPY -> "💗"; Emo.SHY -> "💓"; else -> null }
            if (t != null) lastHeart = now
        }
        if (t != null) speak(t)
    }

    // ------------------------------------------------------------ menu interaksi (tekan lama)
    private fun dismissMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null; h.removeCallbacks(menuTimeout) }
    private val menuTimeout = Runnable { dismissMenu() }

    private fun showMenu() {
        dismissMenu()
        val id = NaraApp.brain.lang == "id"
        val items = listOf(
            (if (id) "💬 Ngobrol" else "💬 Chat") to { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("chat", true)) },
            (if (id) "🤗 Peluk" else "🤗 Hug") to { doInteract(Inter.HUG) },
            (if (id) "✋ Tos!" else "✋ High five") to { doInteract(Inter.HIGH5) },
            (if (id) "🍪 Kasih camilan" else "🍪 Give snack") to { doInteract(Inter.SNACK) },
            (if (id) "😴 Tidurlah" else "😴 Take a nap") to { doInteract(Inter.SLEEP) },
            (if (id) "👎 Jangan begitu" else "👎 Don't do that") to { doInteract(Inter.SCOLD) }
        )
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply { cornerRadius = 14 * density; setColor(Color.argb(235, 20, 24, 44)); setStroke((1.5f * density).toInt(), Color.rgb(70, 212, 224)) } }
        for ((label, act) in items) col.addView(TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 14f
            setPadding((12 * density).toInt(), (9 * density).toInt(), (12 * density).toInt(), (9 * density).toInt())
            setOnClickListener { dismissMenu(); act() }
        })
        val menuW = (170 * density).toInt()
        val left = px + winWidth() / 2 < sw / 2
        val mlp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (if (left) px + winWidth() + 8 * density else px - menuW - 8 * density).toInt().coerceIn(0, max(0, sw - menuW))
            y = yMargin + (img.height * 0.35f).toInt()
        }
        try { wm.addView(col, mlp); menu = col; h.postDelayed(menuTimeout, 7000) } catch (_: Exception) {}
    }

    fun speak(t: String) {
        h.post {
            if (!ready) return@post
            bubble.text = t; bubble.visibility = View.VISIBLE
            talkUntil = SystemClock.uptimeMillis() + (1200 + t.length * 55L).coerceAtMost(6000)
            h.removeCallbacks(hideBubble); h.postDelayed(hideBubble, (2500 + t.length * 70L).coerceAtMost(9000))
            if (Prefs.tts) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nara")
            applyPos()
        }
    }
    private val hideBubble = Runnable { bubble.visibility = View.GONE }

    private fun winWidth() = if (root.width > 0) root.width else (sw * 0.3f).toInt()

    private fun applyPos() {
        px = px.coerceIn(0f, max(0f, (sw - winWidth()).toFloat()))
        lp.x = px.toInt(); lp.y = yMargin
        if (root.isAttachedToWindow) try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        val hgt = root.height
        Shared.charRect = Rect(lp.x, sh - lp.y - hgt, lp.x + winWidth(), sh - lp.y)
    }

    // ------------------------------------------------------------ animasi (±8 fps)
    private val animTick = object : Runnable { override fun run() { try { stepAnim() } catch (_: Exception) {}; h.postDelayed(this, 130) } }

    private fun stepAnim() {
        val now = SystemClock.uptimeMillis(); frame++
        if (state == Body.WALK) {
            val dir = if (tx > px) 1 else -1
            facingRight = dir > 0
            px += dir * sw * (if (running) 0.034f else 0.0156f)
            if (abs(tx - px) < sw * 0.02f) { state = Body.IDLE; stateUntil = now + 2000 + rnd.nextInt(3000) }
            applyPos()
        }
        val emo = NaraApp.brain.emotion()
        // pilih baris sprite + rentang frame (hi eksklusif) + kecepatan ganti frame
        var name = "idle"; var lo = 0; var hi = 8; var div = 6
        when (state) {
            Body.WALK -> if (running) { name = "run"; hi = 9; div = 1 } else { name = "walk"; hi = 9; div = 2 }
            Body.SIT -> { name = "sit"; hi = 5; div = 5 }
            Body.SLEEP -> { name = "sit"; lo = 7; hi = 8 }
            Body.WAVE -> { name = "happy"; hi = 5; div = 3 }
            TOUCH -> { name = "happy"; hi = 2; div = 4 }
            else -> when (emo) {
                Emo.HAPPY -> { name = "happy"; lo = 5; hi = 8; div = 6 }
                Emo.ANGRY -> { name = "annoyed"; hi = 8; div = 5 }
                Emo.SAD -> { name = "sit"; lo = 5; hi = 8; div = 7 }
                else -> {}
            }
        }
        val list = frames(name, facingRight) ?: return
        val idx = lo + (frame / div) % (hi - lo)
        img.show(list[idx.coerceIn(0, list.size - 1)], null, 0, 0)
    }

    // ------------------------------------------------------------ kehendak (1x/detik)
    private val thinkTick = object : Runnable { override fun run() { try { think() } catch (_: Exception) {}; h.postDelayed(this, 1000) } }

    private fun think() {
        val now = SystemClock.uptimeMillis()
        val brain = NaraApp.brain
        val dm = resources.displayMetrics; sw = dm.widthPixels; sh = dm.heightPixels
        brain.tick(1f, state == Body.SLEEP)
        if (now - lastSave > 60_000) { lastSave = now; brain.save() }
        if (Shared.paused) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return

        if (now >= stateUntil) chooseBody(now)
        if (state == Body.SLEEP && brain.drives.energy > 0.95f) { state = Body.IDLE; stateUntil = now + 2000 }

        val interval = when (Prefs.autonomy) { 1 -> 90_000L; 2 -> 35_000L; 3 -> 14_000L; else -> Long.MAX_VALUE }
        if (Prefs.autonomy > 0 && now - lastInteract >= interval && state != Body.SLEEP) {
            lastInteract = now + rnd.nextInt(5000)
            tryInteract()
        }
        val ctx by lazy { brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa) }
        if (now - Shared.lastUserTouch > 20_000 && now - lastIdleTrain > 20_000 && Shared.curPkg.isNotEmpty()) { lastIdleTrain = now; brain.observeIdle(ctx) }
        if (now - lastComment > 120_000 && bubble.visibility != View.VISIBLE && state != Body.SLEEP) {
            lastComment = now + rnd.nextInt(60_000)
            brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
        }
    }

    private fun chooseBody(now: Long) {
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideBody(ctx)) {
            Body.WALK -> {
                val maxX = max(1f, (sw - winWidth()).toFloat())
                var t = rnd.nextFloat() * maxX
                if (abs(t - px) < sw * 0.15f) t = if (px < maxX / 2) maxX * 0.85f else maxX * 0.1f
                tx = t; state = Body.WALK; stateUntil = now + 20_000
                running = abs(t - px) > sw * 0.5f || (brain.emotion() == Emo.HAPPY && rnd.nextInt(3) == 0)
            }
            Body.SIT -> { state = Body.SIT; stateUntil = now + 8_000 + rnd.nextInt(12_000) }
            Body.SLEEP -> { state = Body.SLEEP; stateUntil = now + 30_000; speak("💤") }
            Body.WAVE -> { state = Body.WAVE; stateUntil = now + 2500 }
            Body.TALK -> {
                state = Body.IDLE; stateUntil = now + 3000
                NaraApp.brain.comment(Shared.curLabel.ifEmpty { "HP" }, Shared.curTexts)?.let { speak(it) }
            }
            else -> { state = Body.IDLE; stateUntil = now + 3000 + rnd.nextInt(5000) }
        }
    }

    // ------------------------------------------------------------ menyentuh layar
    private fun tryInteract() {
        val svc = ScreenAccessService.instance ?: return
        val now = SystemClock.uptimeMillis()
        if (!svc.canAct() || now - Shared.lastUserTouch < 8000) return
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        when (brain.decideInteract(ctx)) {
            Act.DOWN -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(true) }
            Act.UP -> reach(sw * 0.5f, sh * 0.5f) { svc.swipe(false) }
            Act.TAP -> {
                val cands = svc.candidates()
                val i = brain.pickNode(cands.map { it.feats }) ?: return
                val c = cands[i]
                reach(c.cx, c.cy) { svc.tap(c.cx, c.cy) }
            }
            Act.BACK -> reach(sw * 0.08f, sh * 0.5f) { svc.back() }
        }
    }

    private fun reach(x1: Float, y1: Float, action: () -> Unit) {
        state = TOUCH; stateUntil = SystemClock.uptimeMillis() + 2500
        facingRight = x1 >= lp.x + winWidth() / 2f
        val x0 = lp.x + winWidth() * (if (facingRight) 0.85f else 0.15f)
        val y0 = sh - lp.y - img.height * 0.55f
        val bmp = cursorBmp ?: run { action(); return }
        val size = (48 * density).toInt()
        val c = ImageView(this).apply { setImageBitmap(bmp) }
        val clp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (x0 - size / 2).toInt(); y = (y0 - size / 2).toInt() }
        try { wm.addView(c, clp) } catch (_: Exception) { action(); return }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener {
                val t = it.animatedValue as Float
                clp.x = (x0 + (x1 - x0) * t - size / 2).toInt(); clp.y = (y0 + (y1 - y0) * t - size / 2).toInt()
                try { wm.updateViewLayout(c, clp) } catch (_: Exception) {}
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    action()
                    h.postDelayed({ try { wm.removeView(c) } catch (_: Exception) {} }, 450)
                }
            })
            start()
        }
    }

    override fun onDestroy() {
        ready = false
        instance = null
        h.removeCallbacksAndMessages(null)
        dismissMenu()
        try { if (::root.isInitialized) wm.removeView(root) } catch (_: Exception) {}
        try { NaraApp.brain.save() } catch (_: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
