package com.nara.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var statsTv: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var toggleBtn: Button
    private lateinit var scroll: ScrollView
    private val dp get() = resources.displayMetrics.density
    private val BG = Color.rgb(16, 18, 32); private val FG = Color.rgb(230, 236, 250); private val ACC = Color.rgb(70, 212, 224)

    private fun tv(t: String, size: Float = 14f, bold: Boolean = false, color: Int = FG) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
    }
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * dp).toInt(), (24 * dp).toInt(), (16 * dp).toInt(), (24 * dp).toInt()) }
        scroll = ScrollView(this).apply { setBackgroundColor(BG); addView(col) }
        setContentView(scroll)

        col.addView(tv("Nara", 28f, true, ACC))
        col.addView(tv("Teman humanoid di layar HP-mu. Dia melihat, belajar dari caramu, dan punya kehendak sendiri.", 13f))
        status = tv("", 13f); col.addView(status)

        col.addView(tv("1. Izin", 18f, true))
        col.addView(btn("Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Aktifkan Akses Layar (Aksesibilitas → Nara)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(btn("Izinkan Nara melihat gambar layar (opsional)") {
            startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 77)
        })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        col.addView(tv("2. Jalankan", 18f, true))
        toggleBtn = btn("Mulai Nara") { toggle() }; col.addView(toggleBtn)

        col.addView(tv("3. Seberapa bebas Nara menyentuh layar?", 18f, true))
        val rg = RadioGroup(this)
        val names = listOf("Hanya mengamati & ngomong (tidak menyentuh)", "Jarang (±1,5 menit sekali)", "Sedang (±35 detik)", "Sering (±14 detik)")
        names.forEachIndexed { i, n -> rg.addView(RadioButton(this).apply { text = n; id = 100 + i; setTextColor(FG); isChecked = i == Prefs.autonomy }) }
        rg.setOnCheckedChangeListener { _, id -> Prefs.autonomy = id - 100 }
        col.addView(rg)
        col.addView(tv("Ukuran karakter (butuh Mulai ulang)", 14f))
        col.addView(SeekBar(this).apply {
            max = 35; progress = Prefs.sizePct - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Prefs.sizePct = 20 + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(Switch(this).apply { text = "Belajar bahasa dari ketikanku"; setTextColor(FG); isChecked = Prefs.learnTyping; setOnCheckedChangeListener { _: CompoundButton, c -> Prefs.learnTyping = c } })
        col.addView(Switch(this).apply { text = "Nara bersuara (TTS)"; setTextColor(FG); isChecked = Prefs.tts; setOnCheckedChangeListener { _: CompoundButton, c -> Prefs.tts = c } })
        col.addView(tv("Aplikasi yang tidak boleh disentuh/dibaca (pisahkan koma, cukup potongan nama paket)", 13f))
        col.addView(EditText(this).apply {
            setText(Prefs.blocklist); setTextColor(FG); setHintTextColor(Color.GRAY); hint = "contoh: whatsapp, tokopedia"
            setOnFocusChangeListener { _, f -> if (!f) Prefs.blocklist = text.toString() }
        })

        col.addView(tv("4. Ngobrol", 18f, true))
        logScroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(26, 30, 52)) }
        log = tv("", 14f).apply { setPadding((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt()) }
        logScroll.addView(log)
        col.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (220 * dp).toInt()))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "Tulis sesuatu…"; setTextColor(FG); setHintTextColor(Color.GRAY) }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn("Kirim") { send() })
        col.addView(row)
        col.addView(tv("Cara bermain dengan Nara: ketuk kepala = pat · elus kepala/badan (gerak bolak-balik) = elus · ketuk badan = colek (jangan kebanyakan, dia bisa sebel) · geser = angkat & pindahkan · tekan lama = menu (ngobrol, peluk, tos, camilan, tidur, \"jangan begitu\"). Makin sering kamu sayang-sayang, makin dekat dia; pose & ucapannya berubah sesuai suasana hatinya.", 12f))

        col.addView(tv("5. Otak Nara", 18f, true))
        statsTv = tv("", 13f); col.addView(statsTv)
        col.addView(btn("Hapus semua ingatan & pelajaran") {
            AlertDialog.Builder(this).setMessage("Nara akan lupa semuanya dan mulai dari nol. Yakin?")
                .setPositiveButton("Hapus") { _, _ -> NaraApp.brain.wipe(); NaraApp.brain.load(try { assets.open("seed.txt").bufferedReader().readText() } catch (e: Exception) { null }); refresh() }
                .setNegativeButton("Batal", null).show()
        })
        col.addView(tv("Catatan HP Xiaomi/MIUI: Pengaturan → Aplikasi → Nara → Izin lainnya → aktifkan 'Tampilkan jendela pop-up saat berjalan di latar' dan 'Mulai otomatis'; Hemat baterai → Tanpa batasan. Kalau Akses Layar mati sendiri, kunci aplikasi Nara di Recent Apps.", 12f, false, Color.rgb(160, 170, 200)))
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("ScreenAccessService")
    }

    private fun toggle() {
        if (OverlayService.instance != null) { stopService(Intent(this, OverlayService::class.java)); toggleBtn.postDelayed({ refresh() }, 400); return }
        if (!Settings.canDrawOverlays(this)) { status.text = "Izin 'tampil di atas aplikasi lain' belum aktif."; return }
        startForegroundService(Intent(this, OverlayService::class.java))
        toggleBtn.postDelayed({ refresh() }, 600)
    }

    private fun send() {
        val m = input.text.toString().trim(); if (m.isEmpty()) return
        input.setText("")
        val r = NaraApp.brain.reply(m)
        log.append("Kamu: $m\nNara: $r\n\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        OverlayService.instance?.speak(r)
        refresh()
    }

    private fun refresh() {
        val on = OverlayService.instance != null
        toggleBtn.text = if (on) "Hentikan Nara" else "Mulai Nara"
        status.text = "Tampil di atas app: ${if (Settings.canDrawOverlays(this)) "✔" else "✘"}   Akses layar: ${if (a11yOn()) "✔" else "✘"}   " +
            "Lihat gambar: ${if (CaptureService.running) "✔" else "—"}   Nara: ${if (on) "aktif" else "mati"}"
        statsTv.text = NaraApp.brain.stats()
    }

    override fun onResume() { super.onResume(); refresh(); if (intent?.getBooleanExtra("chat", false) == true) scroll.post { input.requestFocus() } }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data))
            status.postDelayed({ refresh() }, 800)
        }
    }

    override fun onPause() { super.onPause(); NaraApp.brain.save() }
}
