package com.nara.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** Mata visual (opsional): menangkap layar kecil ~tiap 3 detik, hanya diambil 4 angka ringkas (kecerahan, variasi, tepi, gelap). Gambar tidak disimpan. */
class CaptureService : Service() {
    private var mp: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var last = 0L

    companion object { @Volatile var running = false }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION") val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("nara_cap", "Nara melihat layar", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "nara_cap").setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Nara sedang melihat layar").setContentText("Hanya ringkasan angka, gambar tidak disimpan.").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(2, n)

        val th = HandlerThread("nara-cap").also { it.start() }; thread = th
        val h = Handler(th.looper)
        val m = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        mp = m
        m.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 6; val hh = dm.heightPixels / 6
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2); reader = r
        vd = m.createVirtualDisplay("nara", w, hh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - last < 3000) return@setOnImageAvailableListener
                last = now
                val pl = img.planes[0]; val buf = pl.buffer; val rs = pl.rowStride; val ps = pl.pixelStride
                var sum = 0.0; var sum2 = 0.0; var edge = 0.0; var dark = 0; var cnt = 0
                var prev = -1.0
                var y = 0
                while (y < hh) {
                    var x = 0
                    while (x < w) {
                        val o = y * rs + x * ps
                        val lum = (0.299 * (buf.get(o).toInt() and 0xff) + 0.587 * (buf.get(o + 1).toInt() and 0xff) + 0.114 * (buf.get(o + 2).toInt() and 0xff)) / 255.0
                        sum += lum; sum2 += lum * lum; cnt++
                        if (lum < 0.2) dark++
                        if (prev >= 0) edge += abs(lum - prev)
                        prev = lum; x += 2
                    }
                    prev = -1.0; y += 2
                }
                if (cnt > 0) {
                    val mean = sum / cnt; val sd = sqrt((sum2 / cnt - mean * mean).coerceAtLeast(0.0))
                    Shared.visual = floatArrayOf(mean.toFloat(), min(1f, (sd * 2).toFloat()), min(1f, (edge / cnt * 4).toFloat()), dark.toFloat() / cnt)
                }
            } finally { img.close() }
        }, h)
        running = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { mp?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        Shared.visual = FloatArray(4)
        super.onDestroy()
    }
}
