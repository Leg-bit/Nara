package com.nara.companion.brain

import java.io.File
import java.util.Random
import kotlin.math.pow

/**
 * Mini LLM: model bahasa tingkat-kata (trigram + backoff) yang dilatih LANGSUNG di HP
 * dari teks layar, obrolan, dan ketikan. Kecil, tapi benar-benar belajar.
 */
class TinyLm {
    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, HashMap<String, Int>>()
    private val tri = HashMap<String, HashMap<String, Int>>()
    var tokensSeen = 0L; private set

    val vocabSize get() = uni.size
    fun knows(w: String) = uni.containsKey(w)
    fun count(w: String) = uni[w] ?: 0

    fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            if (ch.isLetter() || ch == '\'' || (ch.isDigit() && sb.isNotEmpty())) sb.append(ch)
            else { if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) } }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out.filter { it.length in 1..24 && !it.startsWith("http") }
    }

    private fun sentences(text: String) = text.split(Regex("[.!?\\n]+")).map { it.trim() }.filter { it.length > 2 }

    fun learn(text: String, weight: Int = 1) {
        for (sent in sentences(text.take(4000))) {
            val t = tokenize(sent)
            if (t.size < 2 || t.size > 40) continue
            val seq = ArrayList<String>(t.size + 3)
            seq.add("<s>"); seq.addAll(t); seq.add("</s>")
            for (w in t) { uni[w] = (uni[w] ?: 0) + weight }
            for (i in 1 until seq.size) {
                bi.getOrPut(seq[i - 1]) { HashMap() }.merge(seq[i], weight, Int::plus)
                if (i >= 2) tri.getOrPut(seq[i - 2] + " " + seq[i - 1]) { HashMap() }.merge(seq[i], weight, Int::plus)
            }
            tokensSeen += t.size
        }
        if (tri.size > 150_000) prune()
    }

    private fun prune() {
        tri.entries.removeIf { e -> e.value.values.sum() <= 1 }
        bi.entries.removeIf { e -> e.value.values.sum() <= 1 && e.key != "<s>" }
    }

    /** Seberapa "baru" sebuah teks: porsi kata yang belum pernah dilihat (0..1). Pemicu rasa penasaran. */
    fun novelty(text: String): Float {
        val t = tokenize(text).take(200)
        if (t.isEmpty()) return 0f
        return t.count { !knows(it) }.toFloat() / t.size
    }

    fun rareUnknownWord(text: String, rnd: Random): String? {
        val c = tokenize(text).filter { it.length in 4..14 && !knows(it) }.distinct()
        return if (c.isEmpty()) null else c[rnd.nextInt(c.size)]
    }

    private fun sample(dist: Map<String, Int>, temp: Float, rnd: Random, avoid: Set<String>): String? {
        if (dist.isEmpty()) return null
        var total = 0.0
        val items = dist.entries.map { it.key to it.value.toDouble().pow(1.0 / temp) }
        for ((k, v) in items) total += if (k in avoid) v * 0.1 else v
        var r = rnd.nextDouble() * total
        for ((k, v) in items) { r -= if (k in avoid) v * 0.1 else v; if (r <= 0) return k }
        return items.last().first
    }

    fun generate(seed: List<String>, maxWords: Int, temp: Float, rnd: Random): String {
        var w1 = "<s>"
        var w2 = seed.firstOrNull { knows(it) } ?: ""
        val out = ArrayList<String>()
        if (w2.isNotEmpty()) out.add(w2) else {
            w2 = sample(bi["<s>"] ?: emptyMap(), temp, rnd, emptySet()) ?: return ""
            out.add(w2)
        }
        var guard = 0
        while (out.size < maxWords && guard++ < maxWords * 4) {
            val avoid = out.takeLast(4).toSet()
            val nxt = sample(tri["$w1 $w2"] ?: emptyMap(), temp, rnd, avoid)
                ?: sample(bi[w2] ?: emptyMap(), temp, rnd, avoid)
                ?: break
            if (nxt == "</s>") { if (out.size >= 3) break else continue }
            out.add(nxt); w1 = w2; w2 = nxt
        }
        return out.joinToString(" ")
    }

    fun save(f: File) {
        f.bufferedWriter().use { w ->
            w.write("n\t$tokensSeen\n")
            for ((a, c) in uni) w.write("u\t$a\t$c\n")
            for ((a, m) in bi) for ((b, c) in m) if (c > 0) w.write("b\t$a\t$b\t$c\n")
            for ((k, m) in tri) for ((b, c) in m) if (c > 1 || m.size < 3) w.write("t\t$k\t$b\t$c\n")
        }
    }

    fun load(f: File) {
        if (!f.exists()) return
        f.forEachLine { line ->
            val p = line.split('\t')
            try {
                when (p[0]) {
                    "n" -> tokensSeen = p[1].toLong()
                    "u" -> uni[p[1]] = p[2].toInt()
                    "b" -> bi.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                    "t" -> tri.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                }
            } catch (_: Exception) {}
        }
    }
}
