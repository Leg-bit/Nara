package com.nara.companion

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.nara.companion.brain.Act
import com.nara.companion.brain.ScreenStats

/**
 * Mata & tangan Nara: membaca teks layar (bukan kolom sandi), mengamati sentuhanmu untuk belajar,
 * dan (bila diizinkan) melakukan scroll / tap / back.
 */
class ScreenAccessService : AccessibilityService() {
    class Cand(val cx: Float, val cy: Float, val feats: List<String>, val text: String)
    private class Acc { var count = 0; var clickable = 0; var scrollable = false; var editable = false; val texts = ArrayList<String>(); val cands = ArrayList<Cand>() }

    companion object {
        @Volatile var instance: ScreenAccessService? = null
        private val SENSITIVE = listOf("bank", "wallet", "pay", "gopay", "ovo", "dana", "bca", "bni", "mandiri", "jenius", "password", "authenticator",
            "lastpass", "keepass", "bitwarden", "otp", "com.android.settings", "packageinstaller", "permissioncontroller", "securitycenter", "securitycore")
        private val NOISE = listOf("com.android.systemui", "inputmethod", "keyboard")
        private val DANGER = Regex("(?i)(bayar|pay|transfer|hapus|delete|kirim|send|beli|buy|konfirmasi|confirm|logout|log out|keluar|sign out|uninstall|reset|izinkan|allow|setuju|agree|install|unduh|download|order|pesan|checkout|submit|post|unfollow|block|blokir|report|laporkan|tolak|accept|terima|^ok$|^ya$|^yes$)")

        fun isBlocked(pkg: String): Boolean {
            val p = pkg.lowercase()
            if (SENSITIVE.any { p.contains(it) }) return true
            return Prefs.blocklist.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { p.contains(it) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastRead = 0L
    private var lastScrollEvt = 0L
    private var lastScrollY = 0
    private var lastCands: List<Cand> = emptyList()
    private var typedBuf = ""
    private val flushTyped = Runnable {
        if (typedBuf.length > 3) NaraApp.brain.observeTyped(typedBuf)
        typedBuf = ""
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg.substringAfterLast('.') }

    private fun ua(a: Int) {
        val brain = NaraApp.brain
        val ctx = brain.context(Shared.curPkg, Shared.curStats, Shared.lastUa)
        brain.observeUserAction(ctx, a)
        Shared.lastUa = a
        Shared.lastUserTouch = SystemClock.uptimeMillis()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        try { handle(e) } catch (ex: Exception) { /* jangan pernah crash karena satu event */ }
    }

    private fun handle(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || NOISE.any { pkg.contains(it) }) return
        val now = SystemClock.uptimeMillis()
        val self = now < Shared.selfActUntil
        val brain = NaraApp.brain
        if (isBlocked(pkg)) { if (Shared.curPkg != pkg) { Shared.curPkg = pkg; Shared.curTexts = emptyList(); Shared.curStats = ScreenStats() }; return }

        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (pkg != Shared.curPkg) {
                    Shared.curPkg = pkg; Shared.curLabel = label(pkg)
                    brain.observeApp(pkg, Shared.curLabel)
                    if (!self) ua(Act.SWITCH)
                    // kalau kamu pindah app sesaat setelah Nara menyentuh layar, anggap itu tanda "jangan"
                    if (now - Shared.lastSelfActionTime < 3000) brain.feedback(-0.6f)
                }
                readScreen(true)
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> if (!self) {
                val src = e.source
                if (src != null) {
                    val feats = featsOf(src, pkg)
                    val neg = lastCands.filter { it.feats != feats }.shuffled().take(6).map { it.feats }
                    brain.observeUserClick(feats, neg)
                }
                ua(Act.TAP)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> if (!self && now - lastScrollEvt > 700) {
                lastScrollEvt = now
                var dy = if (Build.VERSION.SDK_INT >= 28) e.scrollDeltaY else 0
                if (dy == 0) dy = e.scrollY - lastScrollY
                lastScrollY = e.scrollY
                if (dy != 0) ua(if (dy > 0) Act.DOWN else Act.UP)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> if (!self && !e.isPassword && Prefs.learnTyping) {
                typedBuf = e.text.joinToString(" ")
                handler.removeCallbacks(flushTyped); handler.postDelayed(flushTyped, 2500)
                ua(Act.TYPE)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> readScreen(false)
        }
    }

    private fun featsOf(n: AccessibilityNodeInfo, pkg: String): List<String> {
        val r = Rect(); n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        val f = ArrayList<String>()
        val cls = n.className?.toString() ?: "?"
        f.add("cls:$cls"); f.add("app:$pkg")
        n.viewIdResourceName?.let { f.add("id:$it"); f.add("a+id:$pkg|$it") }
        f.add("pos:${(r.centerX() * 4 / dm.widthPixels).coerceIn(0, 3)}_${(r.centerY() * 8 / dm.heightPixels).coerceIn(0, 7)}")
        f.add("a+c:$pkg|$cls")
        val txt = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
        NaraApp.brain.lm.tokenize(txt).take(5).forEach { f.add("w:$it") }
        return f
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, acc: Acc, pkg: String) {
        if (n == null || depth > 25 || acc.count > 300) return
        acc.count++
        if (!n.isVisibleToUser || n.isPassword) return
        val t = n.text?.toString() ?: n.contentDescription?.toString()
        if (!t.isNullOrBlank() && t.length in 2..200) acc.texts.add(t.trim())
        if (n.isScrollable) acc.scrollable = true
        if (n.isEditable) acc.editable = true
        if (n.isClickable && n.isEnabled) {
            acc.clickable++
            val r = Rect(); n.getBoundsInScreen(r)
            val dm = resources.displayMetrics
            val area = r.width().toLong() * r.height()
            if (r.width() >= 24 && r.height() >= 24 && area < 0.6 * dm.widthPixels * dm.heightPixels &&
                !(t != null && DANGER.containsMatchIn(t.trim())) && !Rect.intersects(r, Shared.charRect)) {
                acc.cands.add(Cand(r.exactCenterX(), r.exactCenterY(), featsOf(n, pkg), t ?: ""))
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, acc, pkg)
    }

    private fun readScreen(force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastRead < 3500) return
        lastRead = now
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || isBlocked(pkg)) return
        val acc = Acc()
        walk(root, 0, acc, pkg)
        lastCands = acc.cands
        val texts = acc.texts.distinct().take(60)
        Shared.curTexts = texts
        Shared.curStats = ScreenStats(texts.sumOf { it.length }, acc.scrollable, acc.clickable, acc.editable, Shared.visual)
        if (Shared.curPkg.isEmpty()) { Shared.curPkg = pkg; Shared.curLabel = label(pkg) }
        NaraApp.brain.observeScreen(pkg, Shared.curLabel.ifEmpty { label(pkg) }, texts)
    }

    // ------------------------------------------------------------ tindakan Nara
    fun canAct(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return pm.isInteractive && !km.isKeyguardLocked && Shared.curPkg.isNotEmpty() && !isBlocked(Shared.curPkg) && !Shared.paused
    }

    fun candidates(): List<Cand> { readScreen(true); return lastCands }

    private fun markSelf(durMs: Long) {
        val now = SystemClock.uptimeMillis()
        Shared.selfActUntil = now + durMs + 1200
        Shared.lastSelfActionTime = now
    }

    private fun gesture(p: Path, dur: Long) {
        markSelf(dur)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    fun swipe(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val y1 = dm.heightPixels * (if (down) 0.68f else 0.35f)
        val y2 = dm.heightPixels * (if (down) 0.35f else 0.68f)
        gesture(Path().apply { moveTo(x, y1); lineTo(x, y2) }, 320)
    }

    fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }, 60)

    fun back() { markSelf(300); performGlobalAction(GLOBAL_ACTION_BACK) }
}
