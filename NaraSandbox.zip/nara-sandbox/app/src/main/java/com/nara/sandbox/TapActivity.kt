package com.nara.sandbox

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Latihan Tekan: tombol berwarna tersebar di SELURUH layar (termasuk tepi), tujuan berganti tiap ronde.
 * Teks tujuan: "TUJUAN: Tekan tombol 'Biru'". Melatih Nara menekan tombol di mana pun, bukan hanya di tengah.
 */
class TapActivity : Activity() {
    private val colors = listOf(
        "Merah" to Color.rgb(200, 40, 40), "Biru" to Color.rgb(40, 90, 200), "Hijau" to Color.rgb(40, 150, 70), "Kuning" to Color.rgb(220, 190, 40),
        "Ungu" to Color.rgb(130, 60, 190), "Oranye" to Color.rgb(230, 120, 30), "Pink" to Color.rgb(230, 100, 160), "Hitam" to Color.rgb(30, 30, 30),
        "Putih" to Color.rgb(235, 235, 235), "Abu" to Color.rgb(130, 130, 140), "Coklat" to Color.rgb(120, 80, 50), "Emas" to Color.rgb(190, 150, 60))
    private lateinit var goalT: TextView
    private lateinit var scoreT: TextView
    private lateinit var feedback: TextView
    private lateinit var area: FrameLayout
    private var target = ""
    private var right = 0; private var wrong = 0; private var round = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18, 20, 32)); fitsSystemWindows = true }
        fun label(size: Float, color: Int) = TextView(this).apply { textSize = size; setTextColor(color); setPadding(dp(12), dp(3), dp(12), dp(3)) }
        goalT = label(18f, Color.rgb(70, 212, 224)); scoreT = label(13f, Color.WHITE); feedback = label(16f, Color.rgb(255, 214, 90))
        root.addView(goalT); root.addView(scoreT); root.addView(feedback)
        area = FrameLayout(this)
        root.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        newTarget()
        area.post { shuffle() }
    }

    private fun newTarget() {
        target = colors.random().first
        goalT.text = "TUJUAN: Tekan tombol '$target'"
        scoreT.text = "SKOR: $right benar • $wrong salah • ronde $round"
    }

    private fun shuffle() {
        val w = area.width; val h = area.height
        if (w == 0 || h == 0) { area.post { shuffle() }; return }
        area.removeAllViews()
        val cols = 3; val rows = 5
        val cw = w / cols; val ch = h / rows
        val bw = (cw * 0.86f).toInt(); val bh = (ch * 0.7f).toInt()
        val order = (0 until cols * rows).shuffled().take(colors.size)
        for ((i, c) in order.withIndex()) {
            val (name, col) = colors[i]
            val btn = Button(this).apply {
                text = name; isAllCaps = false; gravity = Gravity.CENTER; setBackgroundColor(col)
                setTextColor(if (name == "Putih" || name == "Kuning") Color.BLACK else Color.WHITE)
                setOnClickListener { pressed(name) }
            }
            val lp = FrameLayout.LayoutParams(bw, bh)
            lp.leftMargin = (c % cols) * cw + (cw - bw) / 2
            lp.topMargin = (c / cols) * ch + (ch - bh) / 2
            area.addView(btn, lp)
        }
    }

    private fun pressed(name: String) {
        if (name == target) { right++; feedback.text = "✅ BENAR" } else { wrong++; feedback.text = "❌ SALAH" }
        round++
        newTarget(); shuffle()
    }
}
