package com.nara.sandbox;

import java.util.Random;

/** Bot "Mittens" (kucing, level pemula): kebanyakan langkah acak, kadang menangkap bidak kalau ada kesempatan. */
public final class Mittens {
    private final Random r;
    public Mittens(long seed) { r = new Random(seed); }
    public Mittens() { this(System.nanoTime()); }

    public int pick(Chess c) {
        int[] mv = c.moves(false);
        if (mv.length == 0) return -1;
        if (r.nextInt(100) < 30) {
            int[] caps = new int[mv.length]; int k = 0;
            for (int m : mv) if (c.b[Chess.to(m)] != 0) caps[k++] = m;
            if (k > 0) return caps[r.nextInt(k)];
        }
        return mv[r.nextInt(mv.length)];
    }
}
