package com.nara.sandbox

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Menu NaraSandbox: tempat latihan aman untuk Nara (tujuan, aturan, dan hasil yang jelas). */
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18, 20, 32)); fitsSystemWindows = true
            setPadding((20 * d).toInt(), (24 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        col.addView(TextView(this).apply { text = "Nara Sandbox"; textSize = 26f; setTextColor(Color.rgb(70, 212, 224)) })
        col.addView(TextView(this).apply {
            text = "Tempat latihan Nara. Buka panel Nara lalu ketik, misalnya: \"kalahkan mittens\", \"latihan tekan tombol\", atau \"latih dirimu main catur\"."
            textSize = 14f; setTextColor(Color.rgb(190, 200, 225)); setPadding(0, (8 * d).toInt(), 0, (20 * d).toInt())
        })
        fun menu(t: String, go: Class<*>) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 18f
            setOnClickListener { startActivity(Intent(this@MainActivity, go)) }
        }
        col.addView(menu("Catur vs Mittens", ChessActivity::class.java), LinearLayout.LayoutParams(-1, (72 * d).toInt()).apply { bottomMargin = (12 * d).toInt() })
        col.addView(menu("Latihan Tekan", TapActivity::class.java), LinearLayout.LayoutParams(-1, (72 * d).toInt()))
        setContentView(col)
    }
}
