package com.nara.sandbox

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Catur melawan Mittens. Pemain (Nara) = Putih. Setiap kotak punya contentDescription "sq e2 wP" dan teks status
 * "STATUS: GILIRAN_PUTIH | CR=KQkq | EP=-" supaya bisa dibaca lewat Aksesibilitas. Hasil: "HASIL: MENANG/KALAH/SERI".
 */
class ChessActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var game = Chess.start()
    private val mittens = Mittens()
    private var selected = -1
    private var over = false
    private val cells = arrayOfNulls<TextView>(64)
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var record: TextView
    private lateinit var again: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cell = resources.displayMetrics.widthPixels / 8
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18, 20, 32)); fitsSystemWindows = true }
        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); setPadding(dp(12), dp(3), dp(12), dp(3))
        }
        root.addView(label("TUJUAN: Kalahkan bot Mittens", 16f, Color.rgb(70, 212, 224)))
        status = label("", 13f, Color.WHITE); root.addView(status)
        for (r in 7 downTo 0) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in 0..7) {
                val sq = r * 8 + f
                val tv = TextView(this).apply {
                    gravity = Gravity.CENTER
                    setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, cell * 0.62f)
                    isClickable = true
                    setOnClickListener { onSquare(sq) }
                }
                cells[sq] = tv
                row.addView(tv, LinearLayout.LayoutParams(cell, cell))
            }
            root.addView(row)
        }
        result = label("", 20f, Color.rgb(255, 214, 90)); result.visibility = View.GONE; root.addView(result)
        again = Button(this).apply { text = "Main lagi"; isAllCaps = false; visibility = View.GONE; setOnClickListener { restart() } }
        root.addView(again, LinearLayout.LayoutParams(-1, dp(52)))
        record = label("", 13f, Color.rgb(190, 200, 225)); root.addView(record)
        root.addView(Button(this).apply { text = "Menu"; isAllCaps = false; setOnClickListener { finish() } }, LinearLayout.LayoutParams(-1, dp(48)))
        setContentView(root)
        updateRecord(); render()
    }

    private fun glyph(p: Int): String = if (p == 0) "" else "♟♞♝♜♛♚"[Math.abs(p) - 1].toString() + "\uFE0E"

    private fun render() {
        for (sq in 0 until 64) {
            val p = game.b[sq]
            val tv = cells[sq] ?: continue
            val light = (((sq and 7) + (sq shr 3)) % 2) == 1
            tv.setBackgroundColor(if (sq == selected) Color.rgb(240, 200, 60) else if (light) Color.rgb(217, 201, 163) else Color.rgb(139, 107, 74))
            tv.text = glyph(p)
            tv.setTextColor(if (p > 0) Color.WHITE else Color.rgb(20, 20, 20))
            tv.setShadowLayer(if (p > 0) 4f else 0f, 0f, 0f, Color.BLACK)
            tv.contentDescription = "sq " + Chess.name(sq) + " " + Chess.code(p)
        }
        val cr = StringBuilder()
        if ((game.castle and 1) != 0) cr.append('K'); if ((game.castle and 2) != 0) cr.append('Q')
        if ((game.castle and 4) != 0) cr.append('k'); if ((game.castle and 8) != 0) cr.append('q')
        val ep = if (game.ep >= 0) Chess.name(game.ep) else "-"
        status.text = if (over) "STATUS: SELESAI" else "STATUS: " + (if (game.side == 1) "GILIRAN_PUTIH" else "GILIRAN_HITAM") + " | CR=" + (if (cr.isEmpty()) "-" else cr.toString()) + " | EP=" + ep
    }

    private fun onSquare(sq: Int) {
        if (over || game.side != 1) return
        val p = game.b[sq]
        if (p > 0) { selected = sq; render(); return }          // menyentuh bidak sendiri selalu memilih ulang
        if (selected >= 0) {
            val m = game.find(selected, sq)
            selected = -1
            if (m >= 0) { game.apply(m); afterMove() } else render()
        }
    }

    private fun afterMove() {
        render()
        val r = game.result(game.moves(false), 300)
        if (r != 0) { finish(r); return }
        if (game.side == -1) ui.postDelayed({ mittensMove() }, 800)
    }

    private fun mittensMove() {
        if (over || game.side != -1) return
        val mv = mittens.pick(game)
        if (mv < 0) return
        game.apply(mv); render()
        val r = game.result(game.moves(false), 300)
        if (r != 0) finish(r)
    }

    private fun finish(r: Int) {
        over = true; selected = -1
        val key = when (r) { 1 -> "cm"; -1 -> "ck"; else -> "cs" }
        val sp = getSharedPreferences("sb", 0)
        sp.edit().putInt(key, sp.getInt(key, 0) + 1).apply()
        result.text = "HASIL: " + (when (r) { 1 -> "MENANG"; -1 -> "KALAH"; else -> "SERI" })
        result.visibility = View.VISIBLE; again.visibility = View.VISIBLE
        updateRecord(); render()
    }

    private fun restart() {
        ui.removeCallbacksAndMessages(null)
        game = Chess.start(); over = false; selected = -1
        result.visibility = View.GONE; again.visibility = View.GONE
        render()
    }

    private fun updateRecord() {
        val sp = getSharedPreferences("sb", 0)
        record.text = "REKOR: " + sp.getInt("cm", 0) + " menang • " + sp.getInt("ck", 0) + " kalah • " + sp.getInt("cs", 0) + " seri"
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }
}
