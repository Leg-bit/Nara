plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nara.sandbox"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.nara.sandbox"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("nara") {
            storeFile = file("nara.keystore"); storeType = "pkcs12"
            storePassword = "naranara"; keyAlias = "nara"; keyPassword = "naranara"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nara") }
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("nara") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
