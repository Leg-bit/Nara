package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.learning.*;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class LearningTest {
    private static Lesson L(String id, int order, int diff, List<String> pre, List<String> concepts, boolean authored) { return new Lesson(id, "nn", order, id, diff, pre, concepts, authored); }
    private static List<String> l(String... s) { return Arrays.asList(s); }

    private static Curriculum sample() {
        Curriculum c = new Curriculum();
        c.add(L("A", 1, 1, l(), l("a1", "a2"), true));
        c.add(L("B", 2, 2, l("A"), l("b1"), true));
        c.add(L("C", 3, 3, l("B"), l("c1"), false));
        return c;
    }

    @Test void validatesUnknownPrerequisitesAndCycles() {
        Curriculum bad = new Curriculum(); bad.add(L("A", 1, 1, l("Z"), l("x"), true));
        assertFalse(bad.validate().isEmpty());
        Curriculum cyc = new Curriculum(); cyc.add(L("A", 1, 1, l("B"), l("x"), true)); cyc.add(L("B", 2, 1, l("A"), l("y"), true));
        assertTrue(cyc.validate().get(0).contains("siklus"));
        assertTrue(sample().validate().isEmpty());
    }

    @Test void topologicalOrderRespectsPrerequisites() {
        List<Lesson> o = sample().topologicalOrder();
        assertEquals("A", o.get(0).id); assertEquals("B", o.get(1).id); assertEquals("C", o.get(2).id);
        assertEquals(new LinkedHashSet<String>(l("B", "A")).toString(), sample().allPrerequisites("C").toString());
    }

    @Test void masteryRisesWithSuccessFallsWithFailureAndNeedsRepeatedEvidence() {
        MasteryModel m = new MasteryModel();
        m.update("x", 1.0, 2, 0); assertTrue(m.value("x") > MasteryModel.PRIOR && m.value("x") < 0.8, "satu jawaban benar belum berarti menguasai");
        for (int i = 0; i < 6; i++) m.update("x", 1.0, 2, 0);
        assertTrue(m.value("x") > 0.85);
        double high = m.value("x"); m.update("x", 0.0, 2, 0); assertTrue(m.value("x") < high);
        m.update("y", 0.0, 3, 0); assertTrue(m.weakConcepts().contains("y"));
        assertFalse(m.weakConcepts().contains("x"));
    }

    @Test void forgettingReducesEffectiveMastery() {
        MasteryModel m = new MasteryModel();
        for (int i = 0; i < 5; i++) m.update("x", 1.0, 2, 100);
        assertEquals(m.value("x"), m.effective("x", 100), 1e-9);
        assertTrue(m.effective("x", 160) < m.value("x") * 0.6);
    }

    @Test void onlyAssessmentScoreUnlocksNextLesson() {
        Curriculum c = sample(); Map<String, LessonRecord> r = new HashMap<String, LessonRecord>();
        assertFalse(UnlockPolicy.isUnlocked(c.get("B"), r));
        r.put("A", new LessonRecord("A", 5, 0.55));     // dicoba berkali-kali, skor belum lulus
        assertFalse(UnlockPolicy.isUnlocked(c.get("B"), r));
        r.put("A", new LessonRecord("A", 6, 0.7));
        assertTrue(UnlockPolicy.isUnlocked(c.get("B"), r));
    }

    @Test void recommenderContinuesAndNeverSuggestsUnauthoredLessons() {
        Curriculum c = sample(); Map<String, LessonRecord> r = new HashMap<String, LessonRecord>(); MasteryModel m = new MasteryModel();
        assertEquals("A", Recommender.next(c, r, m, 0).lessonId);
        r.put("A", new LessonRecord("A", 1, 0.8)); r.put("B", new LessonRecord("B", 1, 0.9));
        for (int i = 0; i < 6; i++) { m.update("a1", 1, 1, 0); m.update("a2", 1, 1, 0); m.update("b1", 1, 2, 0); }
        assertNull(Recommender.next(c, r, m, 0), "C belum ditulis, tidak boleh direkomendasikan");
    }

    @Test void recommenderRemediatesPrerequisiteWhenConceptsAreWeak() {
        Curriculum c = sample(); Map<String, LessonRecord> r = new HashMap<String, LessonRecord>(); MasteryModel m = new MasteryModel();
        r.put("A", new LessonRecord("A", 1, 0.75));
        m.update("a1", 0.6, 1, 0); m.update("a2", 0.5, 1, 0);
        r.put("B", new LessonRecord("B", 2, 0.3)); m.update("b1", 0.0, 2, 0); m.update("b1", 0.0, 2, 0);
        Recommendation rec = Recommender.next(c, r, m, 0);
        assertEquals(Recommendation.Type.REMEDIATE, rec.type);
        assertEquals("A", rec.lessonId);
    }

    @Test void recommenderSuggestsReviewWhenKnowledgeDecays() {
        Curriculum c = sample(); Map<String, LessonRecord> r = new HashMap<String, LessonRecord>(); MasteryModel m = new MasteryModel();
        r.put("A", new LessonRecord("A", 1, 0.9)); r.put("B", new LessonRecord("B", 1, 0.9));
        for (int i = 0; i < 4; i++) { m.update("a1", 1, 1, 10); m.update("a2", 1, 1, 10); m.update("b1", 1, 2, 10); }
        assertNull(Recommender.next(c, r, m, 10));
        Recommendation rec = Recommender.next(c, r, m, 120);
        assertEquals(Recommendation.Type.REVIEW, rec.type);
    }

    @Test void targetDifficultyTracksMastery() {
        assertEquals(1, Recommender.targetDifficulty(0.0)); assertEquals(3, Recommender.targetDifficulty(0.5)); assertEquals(5, Recommender.targetDifficulty(1.0));
    }

    @Test void streakCountsConsecutiveDaysAndBreaksOnGap() {
        List<Long> days = Arrays.asList(10L, 9L, 8L, 6L);
        assertEquals(3, Streak.compute(days, 10));
        assertEquals(3, Streak.compute(days, 11));   // belum belajar hari ini, runtun kemarin masih hidup
        assertEquals(0, Streak.compute(days, 12));   // sudah putus
        assertEquals(0, Streak.compute(Arrays.<Long>asList(), 5));
    }
}
