package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.assessment.*;
import com.neuralnlp.academy.engine.learning.*;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/** Menguji ASET KURIKULUM yang sebenarnya: grafik prasyarat valid, dan setiap soal bisa dijawab benar (serta jawaban salah ditolak) oleh engine penilai. */
class LessonDataTest {
    private static final File ROOT = new File("../app/src/main/assets/curriculum");

    @SuppressWarnings("unchecked") private static Map<String, Object> read(File f) throws Exception { return (Map<String, Object>) MiniJson.parse(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)); }
    @SuppressWarnings("unchecked") private static List<String> strings(Object o) { List<String> r = new ArrayList<String>(); for (Object x : (List<Object>) o) r.add((String) x); return r; }

    @SuppressWarnings("unchecked") private static Curriculum curriculum() throws Exception {
        Curriculum c = new Curriculum();
        for (Object o : (List<Object>) read(new File(ROOT, "curriculum.json")).get("lessons")) {
            Map<String, Object> m = (Map<String, Object>) o;
            c.add(new Lesson((String) m.get("id"), (String) m.get("track"), ((Double) m.get("order")).intValue(), (String) m.get("title"), ((Double) m.get("difficulty")).intValue(),
                strings(m.get("prerequisites")), strings(m.get("concepts")), (Boolean) m.get("authored")));
        }
        return c;
    }

    @Test void curriculumGraphIsValidAndComplete() throws Exception {
        Curriculum c = curriculum();
        assertTrue(c.validate().isEmpty(), c.validate().toString());
        assertEquals(18, c.track("nn").size()); assertEquals(20, c.track("nlp").size());
        assertEquals(38, c.topologicalOrder().size());
    }

    @Test void firstLessonsOfEachTrackAreAuthoredAndReachableOnlyThroughAssessments() throws Exception {
        Curriculum c = curriculum();
        Map<String, LessonRecord> none = new HashMap<String, LessonRecord>();
        Lesson first = c.get(Recommender.next(c, none, new MasteryModel(), 0).lessonId);
        assertTrue(first.authored && first.prerequisites.isEmpty(), "rekomendasi pertama harus pelajaran tertulis tanpa prasyarat: " + first.id);
        for (Lesson l : c.all()) if (l.authored && !l.prerequisites.isEmpty()) assertFalse(UnlockPolicy.isUnlocked(l, none), l.id + " tidak boleh terbuka tanpa lulus prasyarat");
        for (Lesson l : c.all()) if (l.authored) for (String p : l.prerequisites) assertTrue(c.get(p).authored, l.id + " butuh prasyarat yang belum ditulis: " + p);
    }

    @SuppressWarnings("unchecked") private static Question build(Map<String, Object> q) {
        String id = (String) q.get("id"), prompt = (String) q.get("prompt"), expl = (String) q.get("explanation"); List<String> concepts = strings(q.get("concepts")); int d = ((Double) q.get("difficulty")).intValue();
        switch ((String) q.get("type")) {
            case "MCQ": return Question.mcq(id, prompt, concepts, d, strings(q.get("choices")), ((Double) q.get("correct")).intValue(), expl);
            case "NUMERIC": return Question.numeric(id, prompt, concepts, d, (Double) q.get("answer"), (Double) q.get("tolerance"), expl);
            case "SHORT_CONCEPT": { List<List<String>> r = new ArrayList<List<String>>(); for (Object g : (List<Object>) q.get("rubric")) r.add(strings(g)); return Question.concept(id, prompt, concepts, d, r, expl); }
            case "CODE_OUTPUT": return Question.codeOutput(id, prompt, concepts, d, (String) q.get("expected"), expl);
            default: return Question.experiment(id, prompt, concepts, d, (String) q.get("metric"), (Double) q.get("target"), expl);
        }
    }

    @Test void everyQuestionAcceptsItsCorrectAnswerAndRejectsWrongOnes() throws Exception {
        int checked = 0;
        for (File f : ROOT.toPath().resolve("lessons").toFile().listFiles()) {
            Map<String, Object> lesson = read(f);
            for (Object o : (List<Object>) lesson.get("questions")) {
                Map<String, Object> m = (Map<String, Object>) o; Question q = build(m); String where = q.id;
                switch (q.type) {
                    case MCQ:
                        assertTrue(AssessmentEngine.grade(q, Answer.choice(q.correctIndex)).correct(), where);
                        assertEquals(0.0, AssessmentEngine.grade(q, Answer.choice((q.correctIndex + 1) % q.choices.size())).score, 0.0, where);
                        break;
                    case NUMERIC:
                        assertTrue(AssessmentEngine.grade(q, Answer.number(q.numericAnswer)).correct(), where);
                        assertEquals(0.0, AssessmentEngine.grade(q, Answer.number(q.numericAnswer + 100)).score, 0.0, where);
                        break;
                    case SHORT_CONCEPT:
                        assertTrue(AssessmentEngine.grade(q, Answer.text((String) m.get("modelAnswer"))).correct(), where + " contoh jawaban harus lolos rubrik");
                        assertTrue(AssessmentEngine.grade(q, Answer.text("tidak tahu")).score < 0.34, where + " jawaban kosong makna tidak boleh lolos");
                        break;
                    case CODE_OUTPUT:
                        assertTrue(AssessmentEngine.grade(q, Answer.text(q.expectedOutput)).correct(), where);
                        assertTrue(AssessmentEngine.grade(q, Answer.text("keluaran ngawur")).score < 0.5, where);
                        break;
                    default:
                        assertTrue(AssessmentEngine.grade(q, Answer.number(q.target)).correct(), where);
                        assertTrue(AssessmentEngine.grade(q, Answer.number(0.0)).score < 0.5, where);
                }
                checked++;
            }
        }
        assertTrue(checked >= 30, "jumlah soal terperiksa: " + checked);
    }
}
