package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.nlp.*;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class NlpTest {
    @Test void normalizerShowsEveryStep() {
        TextNormalizer.Options o = new TextNormalizer.Options(); o.expandSlang = true; o.removeStopwords = true;
        List<TextNormalizer.Step> s = TextNormalizer.steps("Gue gak suka makanan ini, BGT!!", o);
        assertEquals("asli", s.get(0).name);
        assertEquals("gue gak suka makanan ini bgt", s.get(2).result);
        assertEquals("saya tidak suka makanan ini banget", s.get(3).result);
        assertEquals("suka makanan banget", s.get(s.size() - 1).result);
    }

    @Test void tokenizerSplitsWordsAndKeepsNumbers() {
        assertEquals(Arrays.asList("halo", "dunia", "2024"), Tokenizer.words("Halo, Dunia 2024!"));
        assertEquals(Arrays.asList("a b", "b c"), Tokenizer.ngrams(Arrays.asList("a", "b", "c"), 2));
    }

    @Test void indonesianStemmerHandlesCommonAffixes() {
        String[][] c = {{"mengalahkan", "kalah"}, {"membuatkan", "buat"}, {"bermain", "main"}, {"pemain", "main"}, {"dimakan", "makan"}, {"makanan", "makan"},
            {"berlari", "lari"}, {"menulis", "tulis"}, {"penulis", "tulis"}, {"memakai", "pakai"}, {"tulisan", "tulis"}, {"kuambil", "ambil"}};
        int ok = 0;
        for (String[] x : c) if (Stemmer.stemIndonesian(x[0]).equals(x[1])) ok++; else System.out.println("  stem salah: " + x[0] + " -> " + Stemmer.stemIndonesian(x[0]));
        assertEquals(c.length, ok);
    }

    @Test void englishStemmerAndLemmatizer() {
        assertEquals("run", Stemmer.stemEnglish("running")); assertEquals("play", Stemmer.stemEnglish("played"));
        assertEquals("study", Stemmer.stemEnglish("studies")); assertEquals("cat", Stemmer.stemEnglish("cats"));
        assertEquals("be", Stemmer.lemmaEnglish("was")); assertEquals("good", Stemmer.lemmaEnglish("better")); assertEquals("child", Stemmer.lemmaEnglish("children"));
    }

    @Test void bpeLearnsFrequentPairsAndReconstructsWords() {
        Bpe b = Bpe.train(Arrays.asList("low", "low", "low", "lower", "newest", "newest", "widest"), 8);
        assertTrue(b.merges().size() >= 3);
        List<String> pieces = b.encode("lowest"); StringBuilder sb = new StringBuilder();
        for (String p : pieces) sb.append(p);
        assertEquals("lowest" + Bpe.END, sb.toString());
        assertTrue(b.encode("low").size() <= 2, "kata sering muncul harus tergabung rapat");
    }

    @Test void bagOfWordsCountsTerms() {
        BagOfWords bow = new BagOfWords();
        bow.fit(Arrays.asList(Arrays.asList("a", "b", "a"), Arrays.asList("c")));
        assertEquals(Arrays.asList("a", "b", "c"), bow.vocabulary());
        assertEquals(Arrays.asList(2, 1, 0).toString(), Arrays.toString(bow.vector(Arrays.asList("a", "b", "a"))).replace("[", "[").replace("]", "]"));
    }

    @Test void tfidfWeightsRareTermsHigherAndNormalizes() {
        TfIdf t = new TfIdf();
        List<List<String>> docs = Arrays.asList(Arrays.asList("kucing", "makan", "ikan"), Arrays.asList("anjing", "makan", "tulang"), Arrays.asList("kucing", "tidur"));
        t.fit(docs);
        assertTrue(t.idf("tulang") > t.idf("makan"));
        Map<String, Double> v = t.transform(docs.get(0)); double n = 0; for (double x : v.values()) n += x * x;
        assertEquals(1.0, n, 1e-9);
        assertEquals(1.0, TfIdf.cosine(v, v), 1e-9);
        assertEquals("ikan", TfIdf.top(v, 1).get(0).getKey());
    }

    private static List<String> toks(String s) { TextNormalizer.Options o = new TextNormalizer.Options(); o.expandSlang = true; o.stem = true; o.removeStopwords = false; return Tokenizer.words(TextNormalizer.normalize(s, o)); }

    @Test void naiveBayesSentimentGeneralizesInIndonesian() {
        List<List<String>> x = new ArrayList<List<String>>(); List<String> y = new ArrayList<String>();
        for (String s : NlpData.ID_POS) { x.add(toks(s)); y.add("positif"); }
        for (String s : NlpData.ID_NEG) { x.add(toks(s)); y.add("negatif"); }
        NaiveBayes nb = new NaiveBayes(); nb.fit(x, y);
        String[] pos = {"kamarnya bersih dan stafnya ramah", "makanannya enak dan harganya murah", "aplikasinya bagus dan sangat membantu", "saya puas, hasilnya memuaskan"};
        String[] neg = {"kamarnya kotor dan stafnya cuek", "makanannya hambar dan harganya mahal", "aplikasinya jelek dan sering error", "saya kecewa, hasilnya buruk"};
        List<List<String>> tx = new ArrayList<List<String>>(); List<String> ty = new ArrayList<String>();
        for (String s : pos) { tx.add(toks(s)); ty.add("positif"); }
        for (String s : neg) { tx.add(toks(s)); ty.add("negatif"); }
        assertTrue(nb.accuracy(tx, ty) >= 0.875, "akurasi uji: " + nb.accuracy(tx, ty));
        Map<String, Double> p = nb.probabilities(toks("sangat bagus dan menyenangkan"));
        assertEquals(1.0, p.get("positif") + p.get("negatif"), 1e-9);
        assertTrue(p.get("positif") > 0.5);
    }

    @Test void languageIdentifierSeparatesIndonesianFromEnglish() {
        LanguageIdentifier li = new LanguageIdentifier();
        String[] id = {"aku mau pergi ke toko untuk membeli roti", "bagaimana cara membuat kue yang enak", "anak-anak bermain di halaman setiap sore", "terima kasih banyak atas bantuannya kemarin", "dia tidak datang karena sedang sakit", "kita harus belajar lebih giat lagi"};
        String[] en = {"i want to go to the store to buy some bread", "how do you make a delicious cake", "the children play in the yard every afternoon", "thank you very much for your help yesterday", "he did not come because he was sick", "we have to study harder from now on"};
        for (String s : id) assertEquals("id", li.detect(s), s);
        for (String s : en) assertEquals("en", li.detect(s), s);
    }

    @Test void semanticSearchFindsRelevantDocument() {
        SemanticSearch ss = new SemanticSearch("id");
        ss.index(Arrays.asList("cara memasak nasi goreng dengan telur", "tutorial belajar bermain gitar untuk pemula", "panduan merawat kucing peliharaan di rumah", "resep membuat kue coklat yang lembut"));
        assertEquals(1, ss.search("belajar main gitar", 3).get(0).index);
        assertEquals(2, ss.search("merawat kucing", 1).get(0).index);
        assertTrue(ss.search("xyzxyz tidak ada", 3).isEmpty());
    }
}
