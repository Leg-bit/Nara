package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.nn.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NetworkTest {
    private static double lossOf(Network n, double[][] x, double[] y) { return n.evaluate(x, y)[0]; }

    private void gradientCheck(Activation hidden, Activation out, Network.Loss loss) {
        Network n = new Network(new int[]{2, 3, 1}, hidden, out, loss, 7);
        double[][] x = {{0.3, -0.8}, {1.2, 0.4}, {-0.5, 0.9}}; double[] y = {1, 0, 1};
        double[] analytic = n.gradients(x, y), p = n.parameters();
        for (int i = 0; i < p.length; i++) {
            double old = p[i], h = 1e-6;
            p[i] = old + h; double lp = lossOf(n, x, y);
            p[i] = old - h; double lm = lossOf(n, x, y);
            p[i] = old;
            double numeric = (lp - lm) / (2 * h);
            assertEquals(numeric, analytic[i], 1e-5 + 1e-4 * Math.abs(numeric));
        }
    }

    @Test void gradientCheckTanhBce() { gradientCheck(Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY); }
    @Test void gradientCheckSigmoidMse() { gradientCheck(Activation.SIGMOID, Activation.SIGMOID, Network.Loss.MSE); }
    @Test void gradientCheckLeakyReluLinearMse() { gradientCheck(Activation.LEAKY_RELU, Activation.LINEAR, Network.Loss.MSE); }

    @Test void activationDerivativesMatchNumeric() {
        for (Activation a : Activation.values()) for (double z : new double[]{-1.7, -0.3, 0.4, 2.1}) {
            double h = 1e-6, num = (a.apply(z + h) - a.apply(z - h)) / (2 * h);
            assertEquals(num, a.derivative(z, a.apply(z)), 1e-5);
        }
    }

    /** XOR butuh lapisan tersembunyi. Dengan 8 neuron, semua seed berhasil; dengan sedikit neuron kadang terjebak minimum lokal (diukur 14-17 dari 20 seed untuk 3-4 neuron). */
    @Test void xorIsLearnedReliablyWithEnoughHiddenNeurons() {
        Dataset d = Dataset.xor();
        for (long seed = 1; seed <= 10; seed++) {
            Network n = new Network(new int[]{2, 8, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, seed);
            double before = lossOf(n, d.x, d.y);
            TrainingHistory h = n.fit(d.x, d.y, new TrainConfig().epochs(600).batch(4).lr(0.05).optimizer(OptimizerType.ADAM).seed(seed), null);
            assertTrue(h.finalAccuracy() == 1.0, "seed " + seed);
            assertTrue(h.finalLoss() < before * 0.2, "loss harus turun tajam (seed " + seed + ")");
        }
    }

    @Test void widerHiddenLayerTrainsMoreReliablyThanNarrow() {
        Dataset d = Dataset.xor(); int narrow = 0, wide = 0;
        for (long seed = 1; seed <= 20; seed++) {
            for (int w : new int[]{2, 8}) {
                Network n = new Network(new int[]{2, w, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, seed);
                if (n.fit(d.x, d.y, new TrainConfig().epochs(600).batch(4).lr(0.05).seed(seed), null).finalAccuracy() == 1.0) { if (w == 2) narrow++; else wide++; }
            }
        }
        assertTrue(wide > narrow, "lebar 8 (" + wide + "/20) harus lebih andal daripada lebar 2 (" + narrow + "/20)");
    }

    @Test void xorIsNotSolvableWithoutHiddenLayer() {
        Dataset d = Dataset.xor();
        Network n = new Network(new int[]{2, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 3);
        TrainingHistory h = n.fit(d.x, d.y, new TrainConfig().epochs(800).batch(4).lr(0.05), null);
        assertTrue(h.finalAccuracy() <= 0.75, "satu neuron tidak bisa memecahkan XOR");
    }

    @Test void allOptimizersConvergeOnLinearlySeparableData() {
        Dataset all = Dataset.blobs(200, 0.35, 5); Dataset[] s = all.split(0.75, 1);
        for (OptimizerType t : OptimizerType.values()) {
            Network n = new Network(new int[]{2, 4, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 2);
            double lr = t == OptimizerType.ADAM ? 0.02 : 0.1;
            n.fit(s[0].x, s[0].y, new TrainConfig().epochs(120).batch(16).lr(lr).optimizer(t), null);
            assertTrue(n.evaluate(s[1].x, s[1].y)[1] >= 0.93, t + " harus mencapai akurasi uji >= 0.93");
        }
    }

    @Test void circlesNeedHiddenLayerAndGeneralize() {
        Dataset[] s = Dataset.circles(300, 0.08, 4).split(0.7, 2);
        Network linear = new Network(new int[]{2, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 1);
        linear.fit(s[0].x, s[0].y, new TrainConfig().epochs(150).lr(0.05), null);
        assertTrue(linear.evaluate(s[1].x, s[1].y)[1] < 0.75, "garis lurus tidak cukup untuk lingkaran");
        Network deep = new Network(new int[]{2, 8, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 1);
        deep.fit(s[0].x, s[0].y, new TrainConfig().epochs(250).lr(0.03), null);
        assertTrue(deep.evaluate(s[1].x, s[1].y)[1] >= 0.9, "lapisan tersembunyi harus menggeneralisasi");
    }

    @Test void listenerCanStopTraining() {
        Dataset d = Dataset.xor();
        Network n = new Network(new int[]{2, 3, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 1);
        TrainingHistory h = n.fit(d.x, d.y, new TrainConfig().epochs(100), (e, l, a) -> e < 5);
        assertEquals(5, h.loss.size());
    }

    @Test void sameSeedGivesSameResult() {
        Dataset d = Dataset.moons(100, 0.1, 9);
        double[] r = new double[2];
        for (int k = 0; k < 2; k++) {
            Network n = new Network(new int[]{2, 5, 1}, Activation.TANH, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 11);
            r[k] = n.fit(d.x, d.y, new TrainConfig().epochs(20).seed(3), null).finalLoss();
        }
        assertEquals(r[0], r[1], 0.0);
    }

    @Test void weightsAndBiasesAreExposedForVisualization() {
        Network n = new Network(new int[]{2, 3, 1}, Activation.RELU, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, 1);
        assertEquals(3, n.weights(0).length); assertEquals(2, n.weights(0)[0].length);
        assertEquals(1, n.weights(1).length); assertEquals(3, n.biases(0).length);
        assertEquals(2 * 3 + 3 + 3 * 1 + 1, n.parameterCount());
    }

    @Test void bceRequiresSigmoidOutput() {
        boolean thrown = false;
        try { new Network(new int[]{2, 1}, Activation.TANH, Activation.LINEAR, Network.Loss.BINARY_CROSS_ENTROPY, 1); } catch (IllegalArgumentException e) { thrown = true; }
        assertTrue(thrown);
    }
}
