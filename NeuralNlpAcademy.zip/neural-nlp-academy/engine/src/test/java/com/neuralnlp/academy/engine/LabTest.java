package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.lab.*;
import com.neuralnlp.academy.engine.nn.*;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class LabTest {
    @Test void lessonExperimentNn03SingleNeuronLearnsAnd() {
        NnLabConfig c = new NnLabConfig(); c.dataset = "and"; c.hidden = new int[]{}; c.learningRate = 0.1; c.epochs = 300;
        NnLabResult r = NnLab.run(c, null);
        assertEquals(1.0, r.testAccuracy, 1e-9);
        assertEquals(2 * 1 + 1, r.network.parameterCount());
    }

    @Test void lessonExperimentNn02CirclesReachesTargetWithHiddenLayerButNotWithout() {
        NnLabConfig deep = new NnLabConfig();   // preset pelajaran: circles, [8], tanh, lr 0.03, 250 epoch
        assertTrue(NnLab.run(deep, null).testAccuracy >= 0.9, "preset pelajaran harus mencapai target 0,9");
        NnLabConfig flat = new NnLabConfig(); flat.hidden = new int[]{};
        assertTrue(NnLab.run(flat, null).testAccuracy < 0.75);
    }

    @Test void labReportsProgressAndSupportsCancel() {
        NnLabConfig c = new NnLabConfig(); c.epochs = 100;
        final int[] calls = {0};
        NnLabResult r = NnLab.run(c, (e, l, a) -> { calls[0]++; return e < 10; });
        assertEquals(10, calls[0]); assertEquals(10, r.history.loss.size());
    }

    @Test void tokenizeComparesWordCharAndSubword() {
        NlpLab.TokenView v = NlpLab.tokenize("Belajar membaca itu seru", 40);
        assertEquals(4, v.words.size()); assertEquals(24, v.chars.size());
        assertTrue(v.subwords.size() >= v.words.size() && v.subwords.size() <= v.chars.size());
        assertTrue(NlpLab.tokenize("belajar", 40).subwords.size() <= 2, "kata sering muncul di korpus menjadi hampir satu token");
    }

    @Test void tfidfTopHighlightsDistinctiveTerms() {
        List<List<Map.Entry<String, Double>>> t = NlpLab.tfidfTop(Arrays.asList("kucing makan ikan di dapur", "anjing makan tulang di halaman", "kucing tidur di sofa"), "id", 2);
        assertEquals(3, t.size());
        String[] top0 = {t.get(0).get(0).getKey(), t.get(0).get(1).getKey()};
        assertTrue(Arrays.asList(top0).contains("ikan") || Arrays.asList(top0).contains("dapur"));
        assertFalse(Arrays.asList(top0).contains("makan"));
    }

    @Test void classifierHasReasonableHeldOutAccuracyInBothLanguages() {
        assertTrue(NlpLab.heldOutAccuracy("id") >= 0.8, "id: " + NlpLab.heldOutAccuracy("id"));
        assertTrue(NlpLab.heldOutAccuracy("en") >= 0.8, "en: " + NlpLab.heldOutAccuracy("en"));
        assertTrue(NlpLab.classify("pelayanannya sangat ramah dan makanannya enak", "id").get("positif") > 0.5);
        assertTrue(NlpLab.classify("the food was bad and the service was rude", "en").get("negatif") > 0.5);
    }

    @Test void bagOfWordsViewSharesOneVocabularyAcrossDocuments() {
        NlpLab.BowView v = NlpLab.bagOfWords(Arrays.asList("kucing makan ikan", "anjing makan tulang"), "id");
        assertEquals(Arrays.asList("anjing", "ikan", "kucing", "makan", "tulang"), v.vocabulary);
        assertEquals(2, v.vectors.size()); assertEquals(5, v.vectors.get(0).length);
        int sum0 = 0; for (int x : v.vectors.get(0)) sum0 += x;
        assertEquals(3, sum0);
    }
}
