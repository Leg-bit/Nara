package com.neuralnlp.academy.engine;

import com.neuralnlp.academy.engine.assessment.*;
import com.neuralnlp.academy.engine.learning.MasteryModel;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class AssessmentTest {
    private static List<String> l(String... s) { return Arrays.asList(s); }

    @Test void multipleChoiceGivesFeedbackWithCorrectAnswer() {
        Question q = Question.mcq("q1", "2+2?", l("math"), 1, l("3", "4", "5"), 1, "Penjumlahan dasar.");
        assertTrue(AssessmentEngine.grade(q, Answer.choice(1)).correct());
        Grade bad = AssessmentEngine.grade(q, Answer.choice(0));
        assertEquals(0.0, bad.score, 0.0); assertTrue(bad.feedback.contains("4"));
    }

    @Test void numericAnswersAllowToleranceAndPartialCredit() {
        Question q = Question.numeric("q2", "sigmoid(0)?", l("act"), 1, 0.5, 0.01, "sigmoid(0)=1/2");
        assertEquals(1.0, AssessmentEngine.grade(q, Answer.number(0.505)).score, 0.0);
        assertEquals(0.5, AssessmentEngine.grade(q, Answer.number(0.54)).score, 0.0);
        assertEquals(0.0, AssessmentEngine.grade(q, Answer.number(0.9)).score, 0.0);
        assertEquals(0.0, AssessmentEngine.grade(q, Answer.text("x")).score, 0.0);
    }

    @Test void conceptAnswersAreGradedByIdeasNotExactWording() {
        Question q = Question.concept("q3", "Jelaskan backpropagation.", l("backprop"), 3,
            Arrays.asList(l("gradien", "turunan", "gradient"), l("bobot", "weight", "parameter"), l("galat", "error", "loss")), "Backprop menyebarkan galat mundur.");
        assertEquals(1.0, AssessmentEngine.grade(q, Answer.text("Kita hitung gradien dari loss lalu memperbarui bobot-bobot jaringan")).score, 1e-9);
        Grade part = AssessmentEngine.grade(q, Answer.text("Memperbarui weights dengan gradient")); // stem: weights -> weight
        assertEquals(2.0 / 3, part.score, 1e-9); assertTrue(part.feedback.contains("galat"));
        assertEquals(0.0, AssessmentEngine.grade(q, Answer.text("tidak tahu")).score, 0.0);
    }

    @Test void codeOutputComparesLineByLineWithNumericTolerance() {
        Question q = Question.codeOutput("q4", "keluaran?", l("code"), 2, "0.5\n0.7311", "sigmoid");
        assertTrue(AssessmentEngine.grade(q, Answer.text("0.5\n0.73110001")).correct());
        assertEquals(0.5, AssessmentEngine.grade(q, Answer.text("0.5\n0.9")).score, 0.0);
    }

    @Test void experimentScoreFollowsMeasuredMetric() {
        Question q = Question.experiment("q5", "capai akurasi 0.9", l("train"), 3, "akurasi", 0.9, "perlu lapisan tersembunyi");
        assertTrue(AssessmentEngine.grade(q, Answer.number(0.95)).correct());
        Grade g = AssessmentEngine.grade(q, Answer.number(0.5));
        assertTrue(g.score > 0 && g.score < 0.6); assertFalse(g.correct());
    }

    @Test void examSessionUpdatesMasteryAndFlagsWeakConcepts() {
        Question a = Question.mcq("a", "?", l("c1"), 2, l("x", "y"), 0, "e"), b = Question.mcq("b", "?", l("c2"), 2, l("x", "y"), 0, "e");
        ExamSession s = new ExamSession(Arrays.asList(a, b));
        boolean early = false; try { s.finish(new MasteryModel(), 0); } catch (IllegalStateException e) { early = true; }
        assertTrue(early);
        s.submit(Answer.choice(0)); s.submit(Answer.choice(1));
        MasteryModel m = new MasteryModel(); ExamResult r = s.finish(m, 5);
        assertEquals(0.5, r.score, 1e-9);
        assertEquals(Arrays.asList("c2"), r.weakConcepts);
        assertTrue(m.value("c1") > m.value("c2"));
        assertFalse(r.passed());
    }

    @Test void examBuilderPrefersWeakConceptsAndMixesTypes() {
        MasteryModel m = new MasteryModel();
        for (int i = 0; i < 6; i++) m.update("strong", 1.0, 2, 0);
        m.update("weak", 0.0, 2, 0);
        Question qs = Question.mcq("s", "?", l("strong"), 2, l("x", "y"), 0, "e"), qw = Question.mcq("w", "?", l("weak"), 2, l("x", "y"), 0, "e");
        int picked = 0;
        for (long seed = 0; seed < 20; seed++) if (ExamBuilder.build(Arrays.asList(qs, qw), m, 1, new Random(seed)).get(0).id.equals("w")) picked++;
        assertTrue(picked >= 18, "soal konsep lemah harus diutamakan, terpilih " + picked + "/20");
        List<Question> pool = Arrays.asList(qs, Question.mcq("s2", "?", l("strong"), 2, l("x", "y"), 0, "e"), Question.numeric("n", "?", l("strong"), 2, 1, 0.01, "e"));
        List<Question> exam = ExamBuilder.build(pool, new MasteryModel(), 2, new Random(1));
        assertTrue(exam.get(0).type != exam.get(1).type, "jenis soal harus beragam");
    }
}
