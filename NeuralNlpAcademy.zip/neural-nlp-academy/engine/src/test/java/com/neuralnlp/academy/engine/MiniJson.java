package com.neuralnlp.academy.engine;

import java.util.*;

/** Pengurai JSON minimal untuk uji (menghindari dependensi tambahan pada modul engine). Objek -> Map, larik -> List, angka -> Double. */
final class MiniJson {
    private final String s; private int i = 0;
    private MiniJson(String s) { this.s = s; }

    static Object parse(String text) { MiniJson p = new MiniJson(text); Object v = p.value(); p.ws(); if (p.i != p.s.length()) throw new IllegalStateException("sisa teks pada " + p.i); return v; }

    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

    private Object value() {
        ws(); char c = s.charAt(i);
        if (c == '{') return obj();
        if (c == '[') return arr();
        if (c == '"') return str();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        int st = i; while (i < s.length() && "+-.eE0123456789".indexOf(s.charAt(i)) >= 0) i++;
        return Double.valueOf(s.substring(st, i));
    }

    private Map<String, Object> obj() {
        Map<String, Object> m = new LinkedHashMap<String, Object>(); i++; ws();
        if (s.charAt(i) == '}') { i++; return m; }
        while (true) { ws(); String k = str(); ws(); i++; m.put(k, value()); ws(); char c = s.charAt(i++); if (c == '}') return m; }
    }

    private List<Object> arr() {
        List<Object> l = new ArrayList<Object>(); i++; ws();
        if (s.charAt(i) == ']') { i++; return l; }
        while (true) { l.add(value()); ws(); char c = s.charAt(i++); if (c == ']') return l; }
    }

    private String str() {
        StringBuilder b = new StringBuilder(); i++;
        while (true) {
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c != '\\') { b.append(c); continue; }
            char e = s.charAt(i++);
            switch (e) {
                case 'n': b.append('\n'); break; case 't': b.append('\t'); break; case 'r': b.append('\r'); break; case 'b': b.append('\b'); break; case 'f': b.append('\f'); break;
                case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                default: b.append(e);
            }
        }
    }
}
