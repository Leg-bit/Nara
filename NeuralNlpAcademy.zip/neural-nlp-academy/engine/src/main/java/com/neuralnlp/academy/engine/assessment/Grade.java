package com.neuralnlp.academy.engine.assessment;

import java.util.List;

public final class Grade {
    public final double score; public final String feedback; public final List<String> concepts;
    public Grade(double score, String feedback, List<String> concepts) { this.score = score; this.feedback = feedback; this.concepts = concepts; }
    public boolean correct() { return score >= 0.999; }
}
