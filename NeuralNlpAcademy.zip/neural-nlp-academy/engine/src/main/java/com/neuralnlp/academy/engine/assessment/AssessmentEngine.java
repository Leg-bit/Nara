package com.neuralnlp.academy.engine.assessment;

import com.neuralnlp.academy.engine.nlp.Stemmer;
import com.neuralnlp.academy.engine.nlp.Tokenizer;

import java.util.*;

/** Menilai jawaban: memahami konsep (bukan sekadar mencocokkan teks persis) dan memberi umpan balik yang spesifik. */
public final class AssessmentEngine {
    private AssessmentEngine() {}

    public static Grade grade(Question q, Answer a) {
        switch (q.type) {
            case MCQ: return gradeMcq(q, a);
            case NUMERIC: return gradeNumeric(q, a);
            case SHORT_CONCEPT: return gradeConcept(q, a);
            case CODE_OUTPUT: return gradeCode(q, a);
            default: return gradeExperiment(q, a);
        }
    }

    private static Grade gradeMcq(Question q, Answer a) {
        boolean ok = a.choice == q.correctIndex;
        return new Grade(ok ? 1 : 0, ok ? "Benar. " + q.explanation : "Belum tepat. Jawaban yang benar: " + q.choices.get(q.correctIndex) + ". " + q.explanation, q.concepts);
    }

    private static Grade gradeNumeric(Question q, Answer a) {
        if (a.number == null) return new Grade(0, "Masukkan angka sebagai jawaban.", q.concepts);
        double err = Math.abs(a.number - q.numericAnswer) / Math.max(1.0, Math.abs(q.numericAnswer));
        if (err <= q.tolerance) return new Grade(1, "Benar. " + q.explanation, q.concepts);
        if (err <= q.tolerance * 5) return new Grade(0.5, "Hampir: kamu dekat dengan " + fmt(q.numericAnswer) + ". Periksa pembulatan/langkah hitung. " + q.explanation, q.concepts);
        return new Grade(0, "Belum tepat. Jawaban yang benar sekitar " + fmt(q.numericAnswer) + ". " + q.explanation, q.concepts);
    }

    private static String fmt(double v) { return String.format(Locale.US, "%.4f", v).replaceAll("0+$", "").replaceAll("\\.$", ""); }

    private static String norm(String s) { return " " + String.join(" ", Tokenizer.words(s)) + " "; }

    private static boolean sameStem(String a, String b) {
        return Stemmer.stemEnglish(a).equals(Stemmer.stemEnglish(b)) || Stemmer.stemIndonesian(a).equals(Stemmer.stemIndonesian(b));
    }

    private static boolean mentions(String answerNorm, List<String> answerTokens, String synonym) {
        String sn = norm(synonym);
        if (answerNorm.contains(sn)) return true;
        List<String> st = Tokenizer.words(synonym);
        if (st.size() == 1) for (String t : answerTokens) if (sameStem(t, st.get(0))) return true;
        return false;
    }

    private static Grade gradeConcept(Question q, Answer a) {
        String n = norm(a.text); List<String> toks = Tokenizer.words(a.text);
        int hit = 0; List<String> missing = new ArrayList<String>();
        for (List<String> group : q.rubric) {
            boolean ok = false;
            for (String syn : group) if (mentions(n, toks, syn)) { ok = true; break; }
            if (ok) hit++; else missing.add(group.get(0));
        }
        double score = q.rubric.isEmpty() ? 0 : (double) hit / q.rubric.size();
        String fb = score >= 0.999 ? "Penjelasanmu mencakup semua gagasan kunci. " + q.explanation
            : "Penjelasanmu belum menyebut: " + String.join(", ", missing) + ". " + q.explanation;
        return new Grade(score, fb, q.concepts);
    }

    private static boolean sameToken(String x, String y) {
        try { double a = Double.parseDouble(x), b = Double.parseDouble(y); return Math.abs(a - b) <= 1e-4 * Math.max(1, Math.abs(b)); }
        catch (NumberFormatException e) { return x.equalsIgnoreCase(y); }
    }

    private static Grade gradeCode(Question q, Answer a) {
        String[] exp = q.expectedOutput.trim().split("\\r?\\n"), got = a.text.trim().split("\\r?\\n");
        int n = Math.max(exp.length, got.length), ok = 0;
        for (int i = 0; i < n; i++) {
            if (i >= exp.length || i >= got.length) continue;
            String[] e = exp[i].trim().split("\\s+"), g = got[i].trim().split("\\s+");
            boolean same = e.length == g.length;
            for (int k = 0; same && k < e.length; k++) if (!sameToken(g[k], e[k])) same = false;
            if (same) ok++;
        }
        double score = n == 0 ? 0 : (double) ok / n;
        return new Grade(score, score >= 0.999 ? "Keluaran sesuai. " + q.explanation : "Keluaran belum sesuai (" + ok + " dari " + n + " baris cocok). " + q.explanation, q.concepts);
    }

    private static Grade gradeExperiment(Question q, Answer a) {
        if (a.number == null) return new Grade(0, "Jalankan eksperimen di laboratorium lalu kirim hasilnya.", q.concepts);
        double s = Math.max(0, Math.min(1, a.number / q.target));
        return new Grade(a.number >= q.target ? 1 : s * 0.9, a.number >= q.target ? "Eksperimen berhasil: " + q.metricName + " " + fmt(a.number) + " mencapai target. " + q.explanation
            : q.metricName + " " + fmt(a.number) + " belum mencapai target " + fmt(q.target) + ". Coba ubah arsitektur atau laju belajar. " + q.explanation, q.concepts);
    }
}
