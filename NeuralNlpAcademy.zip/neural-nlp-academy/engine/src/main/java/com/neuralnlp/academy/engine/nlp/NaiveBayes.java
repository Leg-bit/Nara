package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Naive Bayes multinomial (penghalusan Laplace) untuk klasifikasi teks. */
public final class NaiveBayes {
    private final Map<String, Integer> docCount = new TreeMap<String, Integer>();
    private final Map<String, Map<String, Integer>> wordCount = new HashMap<String, Map<String, Integer>>();
    private final Map<String, Integer> total = new HashMap<String, Integer>();
    private final Set<String> vocab = new HashSet<String>();
    private int docs = 0;

    public void fit(List<List<String>> x, List<String> y) {
        for (int i = 0; i < x.size(); i++) {
            String c = y.get(i);
            docCount.put(c, docCount.containsKey(c) ? docCount.get(c) + 1 : 1); docs++;
            Map<String, Integer> m = wordCount.get(c); if (m == null) { m = new HashMap<String, Integer>(); wordCount.put(c, m); }
            for (String w : x.get(i)) { m.put(w, m.containsKey(w) ? m.get(w) + 1 : 1); total.put(c, total.containsKey(c) ? total.get(c) + 1 : 1); vocab.add(w); }
        }
    }

    /** Peluang tiap kelas (jumlah = 1). */
    public Map<String, Double> probabilities(List<String> doc) {
        Map<String, Double> logp = new TreeMap<String, Double>();
        double max = -1e300;
        for (String c : docCount.keySet()) {
            double lp = Math.log((double) docCount.get(c) / docs);
            Map<String, Integer> m = wordCount.get(c); int tot = total.containsKey(c) ? total.get(c) : 0;
            for (String w : doc) { if (!vocab.contains(w)) continue; int cnt = m.containsKey(w) ? m.get(w) : 0; lp += Math.log((cnt + 1.0) / (tot + vocab.size())); }
            logp.put(c, lp); if (lp > max) max = lp;
        }
        double sum = 0; for (double v : logp.values()) sum += Math.exp(v - max);
        Map<String, Double> out = new TreeMap<String, Double>();
        for (Map.Entry<String, Double> e : logp.entrySet()) out.put(e.getKey(), Math.exp(e.getValue() - max) / sum);
        return out;
    }

    public String predict(List<String> doc) {
        String best = null; double bp = -1;
        for (Map.Entry<String, Double> e : probabilities(doc).entrySet()) if (e.getValue() > bp) { bp = e.getValue(); best = e.getKey(); }
        return best;
    }

    public double accuracy(List<List<String>> x, List<String> y) {
        int ok = 0; for (int i = 0; i < x.size(); i++) if (predict(x.get(i)).equals(y.get(i))) ok++;
        return x.isEmpty() ? 0 : (double) ok / x.size();
    }
}
