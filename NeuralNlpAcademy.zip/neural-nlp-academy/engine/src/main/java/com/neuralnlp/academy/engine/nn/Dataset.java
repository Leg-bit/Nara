package com.neuralnlp.academy.engine.nn;

import java.util.Random;

/** Dataset kecil 2 fitur untuk eksperimen jaringan saraf (label 0/1). Dibangkitkan dengan seed agar bisa diulang. */
public final class Dataset {
    public final String name;
    public final double[][] x;
    public final double[] y;

    public Dataset(String name, double[][] x, double[] y) { this.name = name; this.x = x; this.y = y; }

    public int size() { return x.length; }

    public static Dataset xor() {
        return new Dataset("XOR", new double[][]{{0, 0}, {0, 1}, {1, 0}, {1, 1}}, new double[]{0, 1, 1, 0});
    }

    public static Dataset and() {
        return new Dataset("AND", new double[][]{{0, 0}, {0, 1}, {1, 0}, {1, 1}}, new double[]{0, 0, 0, 1});
    }

    /** Dua gumpalan titik yang terpisah garis lurus. */
    public static Dataset blobs(int n, double noise, long seed) {
        Random r = new Random(seed);
        double[][] x = new double[n][2]; double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            int c = i % 2; y[i] = c;
            double cx = c == 0 ? -1.0 : 1.0;
            x[i][0] = cx + r.nextGaussian() * noise; x[i][1] = cx + r.nextGaussian() * noise;
        }
        return new Dataset("Blobs", x, y);
    }

    /** Lingkaran dalam dan lingkaran luar: tidak bisa dipisah garis lurus. */
    public static Dataset circles(int n, double noise, long seed) {
        Random r = new Random(seed);
        double[][] x = new double[n][2]; double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            int c = i % 2; y[i] = c;
            double rad = (c == 0 ? 0.4 : 1.0) + r.nextGaussian() * noise;
            double a = r.nextDouble() * 2 * Math.PI;
            x[i][0] = rad * Math.cos(a); x[i][1] = rad * Math.sin(a);
        }
        return new Dataset("Circles", x, y);
    }

    /** Dua bulan sabit yang saling mengait. */
    public static Dataset moons(int n, double noise, long seed) {
        Random r = new Random(seed);
        double[][] x = new double[n][2]; double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            int c = i % 2; y[i] = c;
            double a = r.nextDouble() * Math.PI;
            if (c == 0) { x[i][0] = Math.cos(a); x[i][1] = Math.sin(a); }
            else { x[i][0] = 1 - Math.cos(a); x[i][1] = 0.5 - Math.sin(a); }
            x[i][0] += r.nextGaussian() * noise; x[i][1] += r.nextGaussian() * noise;
        }
        return new Dataset("Moons", x, y);
    }

    /** Bagi menjadi data latih dan data uji (acak dengan seed). */
    public Dataset[] split(double trainFraction, long seed) {
        int n = size(); int[] idx = new int[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        Random r = new Random(seed);
        for (int i = n - 1; i > 0; i--) { int j = r.nextInt(i + 1); int t = idx[i]; idx[i] = idx[j]; idx[j] = t; }
        int nt = (int) Math.round(n * trainFraction);
        double[][] xa = new double[nt][], xb = new double[n - nt][]; double[] ya = new double[nt], yb = new double[n - nt];
        for (int i = 0; i < n; i++) {
            if (i < nt) { xa[i] = x[idx[i]]; ya[i] = y[idx[i]]; } else { xb[i - nt] = x[idx[i]]; yb[i - nt] = y[idx[i]]; }
        }
        return new Dataset[]{new Dataset(name + "-latih", xa, ya), new Dataset(name + "-uji", xb, yb)};
    }
}
