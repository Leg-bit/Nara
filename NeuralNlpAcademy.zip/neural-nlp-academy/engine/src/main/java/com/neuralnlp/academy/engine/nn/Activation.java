package com.neuralnlp.academy.engine.nn;

/** Fungsi aktivasi neuron beserta turunannya (untuk backpropagation). */
public enum Activation {
    LINEAR, SIGMOID, TANH, RELU, LEAKY_RELU;

    public double apply(double z) {
        switch (this) {
            case SIGMOID: return 1.0 / (1.0 + Math.exp(-z));
            case TANH: return Math.tanh(z);
            case RELU: return z > 0 ? z : 0.0;
            case LEAKY_RELU: return z > 0 ? z : 0.01 * z;
            default: return z;
        }
    }

    /** Turunan terhadap z; [a] = apply(z) (dipakai ulang agar hemat hitungan). */
    public double derivative(double z, double a) {
        switch (this) {
            case SIGMOID: return a * (1.0 - a);
            case TANH: return 1.0 - a * a;
            case RELU: return z > 0 ? 1.0 : 0.0;
            case LEAKY_RELU: return z > 0 ? 1.0 : 0.01;
            default: return 1.0;
        }
    }
}
