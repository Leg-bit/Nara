package com.neuralnlp.academy.engine.assessment;

import java.util.*;

public final class ExamResult {
    public final double score;                         // 0..1, rata-rata berbobot kesulitan
    public final Map<String, Double> conceptScores;    // rata-rata skor per konsep
    public final List<String> weakConcepts;            // konsep dengan skor < 0.6 pada ujian ini
    public ExamResult(double score, Map<String, Double> conceptScores, List<String> weakConcepts) { this.score = score; this.conceptScores = conceptScores; this.weakConcepts = weakConcepts; }
    public boolean passed() { return score >= com.neuralnlp.academy.engine.learning.UnlockPolicy.PASS_SCORE; }
}
