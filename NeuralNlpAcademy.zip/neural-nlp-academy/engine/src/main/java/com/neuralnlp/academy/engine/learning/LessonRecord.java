package com.neuralnlp.academy.engine.learning;

/** Catatan hasil asesmen sebuah pelajaran. Pelajaran dianggap lulus hanya berdasarkan skor asesmen, bukan klik "selesai". */
public final class LessonRecord {
    public final String lessonId;
    public final int attempts;
    public final double bestScore;

    public LessonRecord(String lessonId, int attempts, double bestScore) { this.lessonId = lessonId; this.attempts = attempts; this.bestScore = bestScore; }

    public boolean passed() { return bestScore >= UnlockPolicy.PASS_SCORE; }
}
