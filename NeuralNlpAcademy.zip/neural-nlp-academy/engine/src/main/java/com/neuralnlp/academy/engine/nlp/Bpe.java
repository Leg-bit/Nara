package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Byte-Pair Encoding mini untuk belajar tokenisasi subkata: gabungkan pasangan simbol paling sering berulang kali. */
public final class Bpe {
    public static final String END = "</w>";
    private final List<String[]> merges = new ArrayList<String[]>();

    public List<String[]> merges() { return merges; }

    private static List<String> symbols(String word) {
        List<String> s = new ArrayList<String>();
        for (int i = 0; i < word.length(); i++) s.add(String.valueOf(word.charAt(i)));
        s.add(END);
        return s;
    }

    public static Bpe train(List<String> words, int numMerges) {
        Bpe b = new Bpe();
        Map<String, Integer> freq = new LinkedHashMap<String, Integer>();
        for (String w : words) { String k = w.toLowerCase(Locale.ROOT); Integer c = freq.get(k); freq.put(k, c == null ? 1 : c + 1); }
        Map<String, List<String>> seg = new LinkedHashMap<String, List<String>>();
        for (String w : freq.keySet()) seg.put(w, symbols(w));
        for (int m = 0; m < numMerges; m++) {
            Map<String, Integer> pairs = new TreeMap<String, Integer>();
            for (Map.Entry<String, List<String>> e : seg.entrySet()) {
                List<String> s = e.getValue(); int f = freq.get(e.getKey());
                for (int i = 0; i + 1 < s.size(); i++) { String k = s.get(i) + "\u0001" + s.get(i + 1); Integer c = pairs.get(k); pairs.put(k, c == null ? f : c + f); }
            }
            String best = null; int bc = 1;
            for (Map.Entry<String, Integer> e : pairs.entrySet()) if (e.getValue() > bc) { bc = e.getValue(); best = e.getKey(); }
            if (best == null) break;
            String[] ab = best.split("\u0001");
            b.merges.add(ab);
            for (Map.Entry<String, List<String>> e : seg.entrySet()) e.setValue(apply(e.getValue(), ab));
        }
        return b;
    }

    private static List<String> apply(List<String> s, String[] ab) {
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < s.size(); i++) {
            if (i + 1 < s.size() && s.get(i).equals(ab[0]) && s.get(i + 1).equals(ab[1])) { out.add(ab[0] + ab[1]); i++; } else out.add(s.get(i));
        }
        return out;
    }

    /** Pecah satu kata menjadi subkata sesuai aturan gabung yang dipelajari. */
    public List<String> encode(String word) {
        List<String> s = symbols(word.toLowerCase(Locale.ROOT));
        for (String[] ab : merges) s = apply(s, ab);
        return s;
    }
}
