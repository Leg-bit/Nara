package com.neuralnlp.academy.engine.learning;

import java.util.*;

/** Runtun belajar: jumlah hari berturut-turut yang aktif, berakhir hari ini (atau kemarin jika hari ini belum belajar). */
public final class Streak {
    private Streak() {}

    public static int compute(Collection<Long> activeDays, long today) {
        Set<Long> s = new HashSet<Long>(activeDays);
        long d = s.contains(today) ? today : today - 1;
        int n = 0;
        while (s.contains(d)) { n++; d--; }
        return n;
    }
}
