package com.neuralnlp.academy.engine.assessment;

import java.util.*;

/** Satu soal asesmen. Gunakan pabrik statis sesuai jenis soal. */
public final class Question {
    public final String id, prompt, explanation;
    public final QuestionType type;
    public final List<String> concepts;
    public final int difficulty;
    // MCQ
    public List<String> choices = Collections.emptyList(); public int correctIndex = -1;
    // NUMERIC
    public double numericAnswer, tolerance = 0.01;
    // SHORT_CONCEPT: tiap grup = sinonim untuk satu gagasan yang harus disebut
    public List<List<String>> rubric = Collections.emptyList();
    // CODE_OUTPUT
    public String expectedOutput = "";
    // EXPERIMENT: metrik (mis. akurasi) minimal yang harus dicapai
    public double target; public String metricName = "";

    private Question(String id, QuestionType t, String prompt, List<String> concepts, int difficulty, String explanation) {
        this.id = id; this.type = t; this.prompt = prompt; this.concepts = concepts; this.difficulty = difficulty; this.explanation = explanation;
    }

    public static Question mcq(String id, String prompt, List<String> concepts, int difficulty, List<String> choices, int correct, String explanation) {
        Question q = new Question(id, QuestionType.MCQ, prompt, concepts, difficulty, explanation); q.choices = choices; q.correctIndex = correct; return q;
    }

    public static Question numeric(String id, String prompt, List<String> concepts, int difficulty, double answer, double tolerance, String explanation) {
        Question q = new Question(id, QuestionType.NUMERIC, prompt, concepts, difficulty, explanation); q.numericAnswer = answer; q.tolerance = tolerance; return q;
    }

    public static Question concept(String id, String prompt, List<String> concepts, int difficulty, List<List<String>> rubric, String explanation) {
        Question q = new Question(id, QuestionType.SHORT_CONCEPT, prompt, concepts, difficulty, explanation); q.rubric = rubric; return q;
    }

    public static Question codeOutput(String id, String prompt, List<String> concepts, int difficulty, String expected, String explanation) {
        Question q = new Question(id, QuestionType.CODE_OUTPUT, prompt, concepts, difficulty, explanation); q.expectedOutput = expected; return q;
    }

    public static Question experiment(String id, String prompt, List<String> concepts, int difficulty, String metricName, double target, String explanation) {
        Question q = new Question(id, QuestionType.EXPERIMENT, prompt, concepts, difficulty, explanation); q.metricName = metricName; q.target = target; return q;
    }
}
