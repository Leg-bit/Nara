package com.neuralnlp.academy.engine.learning;

import java.util.*;

/** Graf kurikulum: pelajaran dan prasyaratnya. Memvalidasi referensi dan siklus, serta memberi urutan belajar topologis. */
public final class Curriculum {
    private final Map<String, Lesson> lessons = new LinkedHashMap<String, Lesson>();

    public void add(Lesson l) { lessons.put(l.id, l); }
    public Lesson get(String id) { return lessons.get(id); }
    public Collection<Lesson> all() { return Collections.unmodifiableCollection(lessons.values()); }

    public List<Lesson> track(String track) {
        List<Lesson> l = new ArrayList<Lesson>();
        for (Lesson x : lessons.values()) if (x.track.equals(track)) l.add(x);
        Collections.sort(l, new Comparator<Lesson>() { public int compare(Lesson a, Lesson b) { return Integer.compare(a.order, b.order); } });
        return l;
    }

    /** Daftar masalah (kosong = valid): prasyarat tidak dikenal atau siklus. */
    public List<String> validate() {
        List<String> problems = new ArrayList<String>();
        for (Lesson l : lessons.values()) for (String p : l.prerequisites) if (!lessons.containsKey(p)) problems.add(l.id + " butuh prasyarat tak dikenal: " + p);
        if (problems.isEmpty() && topologicalOrder().size() != lessons.size()) problems.add("ada siklus prasyarat");
        return problems;
    }

    /** Urutan belajar (algoritma Kahn); pelajaran yang terjebak siklus tidak ikut. Urutan stabil: track lalu nomor urut. */
    public List<Lesson> topologicalOrder() {
        Map<String, Integer> indeg = new LinkedHashMap<String, Integer>();
        for (Lesson l : lessons.values()) { int d = 0; for (String p : l.prerequisites) if (lessons.containsKey(p)) d++; indeg.put(l.id, d); }
        List<Lesson> ready = new ArrayList<Lesson>(), out = new ArrayList<Lesson>();
        for (Lesson l : lessons.values()) if (indeg.get(l.id) == 0) ready.add(l);
        Comparator<Lesson> cmp = new Comparator<Lesson>() { public int compare(Lesson a, Lesson b) { int c = a.track.compareTo(b.track); return c != 0 ? c : Integer.compare(a.order, b.order); } };
        while (!ready.isEmpty()) {
            Collections.sort(ready, cmp);
            Lesson cur = ready.remove(0); out.add(cur);
            for (Lesson l : lessons.values()) if (l.prerequisites.contains(cur.id)) { int d = indeg.get(l.id) - 1; indeg.put(l.id, d); if (d == 0) ready.add(l); }
        }
        return out;
    }

    /** Semua prasyarat langsung dan tidak langsung. */
    public Set<String> allPrerequisites(String id) {
        Set<String> seen = new LinkedHashSet<String>();
        Deque<String> q = new ArrayDeque<String>();
        Lesson l = lessons.get(id); if (l == null) return seen;
        q.addAll(l.prerequisites);
        while (!q.isEmpty()) { String p = q.poll(); if (seen.add(p) && lessons.containsKey(p)) q.addAll(lessons.get(p).prerequisites); }
        return seen;
    }
}
