package com.neuralnlp.academy.engine.learning;

import java.util.*;

/**
 * Memilih satu pelajaran berikutnya: (1) perkuat prasyarat kalau konsep lemah, (2) lanjut ke pelajaran terbuka berikutnya,
 * (3) ulangi materi yang mulai terlupa. Pelajaran yang belum ditulis (authored=false) tidak pernah direkomendasikan.
 */
public final class Recommender {
    private Recommender() {}

    public static Recommendation next(Curriculum c, Map<String, LessonRecord> records, MasteryModel m, long today) {
        // 1) remediasi: pelajaran yang sudah dicoba tetapi belum lulus dan punya konsep sangat lemah
        for (Lesson l : c.topologicalOrder()) {
            LessonRecord r = records.get(l.id);
            if (r == null || r.attempts == 0 || r.passed()) continue;
            List<String> weak = new ArrayList<String>();
            for (String k : l.concepts) { MasteryModel.Mastery x = m.get(k); if (x != null && x.evidence >= 1 && x.value < 0.5) weak.add(k); }
            if (weak.isEmpty()) continue;
            Lesson best = null; double bestAvg = 1.0;
            for (String pid : c.allPrerequisites(l.id)) {
                Lesson p = c.get(pid);
                if (p == null || !p.authored) continue;
                boolean covers = false; for (String k : weak) if (p.concepts.contains(k)) covers = true;
                double avg = m.average(p.concepts);
                if (covers && avg < 0.8 && avg < bestAvg) { best = p; bestAvg = avg; }
            }
            if (best == null) for (String pid : c.allPrerequisites(l.id)) {
                Lesson p = c.get(pid);
                if (p == null || !p.authored) continue;
                double avg = m.average(p.concepts);
                if (avg < 0.7 && avg < bestAvg) { best = p; bestAvg = avg; }
            }
            if (best != null) return new Recommendation(best.id, Recommendation.Type.REMEDIATE, "Konsep \"" + weak.get(0) + "\" di \"" + l.title + "\" masih lemah. Perkuat dulu: " + best.title + ".");
        }
        // 2) lanjut
        for (Lesson l : c.topologicalOrder()) {
            if (!l.authored || UnlockPolicy.isPassed(records, l.id) || !UnlockPolicy.isUnlocked(l, records)) continue;
            LessonRecord r = records.get(l.id);
            return new Recommendation(l.id, Recommendation.Type.CONTINUE, r != null && r.attempts > 0 ? "Ulangi asesmen \"" + l.title + "\" sampai lulus." : "Pelajaran berikutnya: " + l.title + ".");
        }
        // 3) ulangan: materi lulus yang penguasaan efektifnya menurun
        Lesson weakest = null; double wv = 0.75;
        for (Lesson l : c.topologicalOrder()) {
            if (!l.authored || !UnlockPolicy.isPassed(records, l.id) || l.concepts.isEmpty()) continue;
            double s = 0; for (String k : l.concepts) s += m.effective(k, today);
            s /= l.concepts.size();
            if (s < wv) { wv = s; weakest = l; }
        }
        if (weakest != null) return new Recommendation(weakest.id, Recommendation.Type.REVIEW, "Waktunya mengulang \"" + weakest.title + "\" sebelum terlupa.");
        return null;
    }

    /** Tingkat kesulitan soal yang pas untuk penguasaan tertentu (1..5). */
    public static int targetDifficulty(double mastery) { return Math.max(1, Math.min(5, (int) Math.round(1 + mastery * 4))); }
}
