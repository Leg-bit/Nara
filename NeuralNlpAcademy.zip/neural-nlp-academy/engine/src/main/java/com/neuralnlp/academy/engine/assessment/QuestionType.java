package com.neuralnlp.academy.engine.assessment;

public enum QuestionType { MCQ, NUMERIC, SHORT_CONCEPT, CODE_OUTPUT, EXPERIMENT }
