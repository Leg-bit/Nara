package com.neuralnlp.academy.engine.nlp;

import java.util.*;

public final class Tokenizer {
    private Tokenizer() {}

    /** Token kata: urutan huruf/angka, huruf kecil. */
    public static List<String> words(String text) {
        List<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        String t = text.toLowerCase(Locale.ROOT);
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.isLetterOrDigit(c)) cur.append(c);
            else if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    public static List<String> chars(String text) {
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < text.length(); i++) out.add(String.valueOf(text.charAt(i)));
        return out;
    }

    public static List<String> ngrams(List<String> tokens, int n) {
        List<String> out = new ArrayList<String>();
        for (int i = 0; i + n <= tokens.size(); i++) out.add(String.join(" ", tokens.subList(i, i + n)));
        return out;
    }
}
