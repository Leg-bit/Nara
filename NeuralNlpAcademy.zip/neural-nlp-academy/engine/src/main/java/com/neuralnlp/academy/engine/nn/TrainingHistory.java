package com.neuralnlp.academy.engine.nn;

import java.util.ArrayList;
import java.util.List;

/** Riwayat loss dan akurasi per epoch. */
public final class TrainingHistory {
    public final List<Double> loss = new ArrayList<Double>();
    public final List<Double> accuracy = new ArrayList<Double>();
    public boolean diverged = false;

    public double finalLoss() { return loss.isEmpty() ? Double.NaN : loss.get(loss.size() - 1); }
    public double finalAccuracy() { return accuracy.isEmpty() ? 0.0 : accuracy.get(accuracy.size() - 1); }
}
