package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Identifikasi bahasa (Indonesia / Inggris) memakai Naive Bayes atas trigram huruf. Offline dan sangat ringan. */
public final class LanguageIdentifier {
    private final NaiveBayes nb = new NaiveBayes();

    public LanguageIdentifier() {
        List<List<String>> x = new ArrayList<List<String>>(); List<String> y = new ArrayList<String>();
        add(x, y, "id", NlpData.ID_POS); add(x, y, "id", NlpData.ID_NEG); add(x, y, "id", NlpData.ID_GENERAL);
        add(x, y, "en", NlpData.EN_POS); add(x, y, "en", NlpData.EN_NEG); add(x, y, "en", NlpData.EN_GENERAL);
        nb.fit(x, y);
    }

    private static void add(List<List<String>> x, List<String> y, String lang, String[] texts) { for (String t : texts) { x.add(trigrams(t)); y.add(lang); } }

    static List<String> trigrams(String text) {
        String s = "  " + text.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\s]", " ").replaceAll("\\s+", " ").trim() + " ";
        List<String> out = new ArrayList<String>();
        for (int i = 0; i + 3 <= s.length(); i++) out.add(s.substring(i, i + 3));
        return out;
    }

    public Map<String, Double> probabilities(String text) { return nb.probabilities(trigrams(text)); }

    public String detect(String text) { return nb.predict(trigrams(text)); }
}
