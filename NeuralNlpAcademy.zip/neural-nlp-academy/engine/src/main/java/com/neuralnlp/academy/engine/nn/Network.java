package com.neuralnlp.academy.engine.nn;

import java.util.Random;

/**
 * Jaringan saraf berlapis penuh (MLP) murni Java: forward, backpropagation, tiga optimizer.
 * Tugas: klasifikasi biner (keluaran sigmoid + binary cross-entropy) atau regresi (keluaran linear + MSE).
 * Semua parameter disimpan dalam satu vektor datar agar mudah dioptimasi, dicek gradiennya, dan divisualisasikan.
 */
public final class Network {
    public enum Loss { BINARY_CROSS_ENTROPY, MSE }

    /** Pendengar progres tiap epoch; kembalikan false untuk menghentikan pelatihan (mis. dibatalkan pengguna). */
    public interface EpochListener { boolean onEpoch(int epoch, double loss, double accuracy); }

    private final int[] sizes;
    private final Activation hidden, output;
    private final Loss loss;
    private final int[] wOff, bOff;
    private final double[] p;

    public Network(int[] sizes, Activation hidden, Activation output, Loss loss, long seed) {
        if (sizes.length < 2) throw new IllegalArgumentException("minimal 2 lapisan (masukan dan keluaran)");
        if (loss == Loss.BINARY_CROSS_ENTROPY && output != Activation.SIGMOID) throw new IllegalArgumentException("BCE membutuhkan keluaran SIGMOID");
        this.sizes = sizes.clone(); this.hidden = hidden; this.output = output; this.loss = loss;
        int L = sizes.length - 1; wOff = new int[L]; bOff = new int[L];
        int n = 0;
        for (int l = 0; l < L; l++) { wOff[l] = n; n += sizes[l] * sizes[l + 1]; bOff[l] = n; n += sizes[l + 1]; }
        p = new double[n];
        Random r = new Random(seed);
        for (int l = 0; l < L; l++) {
            Activation a = l == L - 1 ? output : hidden;
            double scale = a == Activation.RELU || a == Activation.LEAKY_RELU ? Math.sqrt(2.0 / sizes[l]) : Math.sqrt(1.0 / sizes[l]);
            for (int i = 0; i < sizes[l] * sizes[l + 1]; i++) p[wOff[l] + i] = r.nextGaussian() * scale;
        }
    }

    public int parameterCount() { return p.length; }
    public int layers() { return sizes.length - 1; }
    public int[] sizes() { return sizes.clone(); }
    public double[] parameters() { return p; }

    /** Matriks bobot lapisan ke-l (baris = neuron keluaran, kolom = neuron masukan) untuk visualisasi. */
    public double[][] weights(int l) {
        double[][] w = new double[sizes[l + 1]][sizes[l]];
        for (int j = 0; j < sizes[l + 1]; j++) for (int i = 0; i < sizes[l]; i++) w[j][i] = p[wOff[l] + j * sizes[l] + i];
        return w;
    }

    public double[] biases(int l) {
        double[] b = new double[sizes[l + 1]];
        System.arraycopy(p, bOff[l], b, 0, b.length);
        return b;
    }

    private Activation act(int l) { return l == layers() - 1 ? output : hidden; }

    /** Forward pass; mengisi z (pra-aktivasi) dan a (aktivasi) tiap lapisan. a[0] = masukan. */
    private void forward(double[] x, double[][] z, double[][] a) {
        a[0] = x;
        for (int l = 0; l < layers(); l++) {
            int in = sizes[l], out = sizes[l + 1];
            for (int j = 0; j < out; j++) {
                double s = p[bOff[l] + j];
                int base = wOff[l] + j * in;
                for (int i = 0; i < in; i++) s += p[base + i] * a[l][i];
                z[l][j] = s; a[l + 1][j] = act(l).apply(s);
            }
        }
    }

    private double[][] newZ() { double[][] z = new double[layers()][]; for (int l = 0; l < z.length; l++) z[l] = new double[sizes[l + 1]]; return z; }
    private double[][] newA() { double[][] a = new double[layers() + 1][]; for (int l = 1; l < a.length; l++) a[l] = new double[sizes[l]]; return a; }

    public double[] predict(double[] x) {
        double[][] z = newZ(), a = newA(); forward(x, z, a);
        return a[layers()].clone();
    }

    private static double clamp(double v) { return Math.min(1 - 1e-12, Math.max(1e-12, v)); }

    private double sampleLoss(double out, double y) {
        if (loss == Loss.BINARY_CROSS_ENTROPY) { double o = clamp(out); return -(y * Math.log(o) + (1 - y) * Math.log(1 - o)); }
        return 0.5 * (out - y) * (out - y);
    }

    /** Loss rata-rata dan akurasi (ambang 0,5 untuk klasifikasi). */
    public double[] evaluate(double[][] x, double[] y) {
        double sum = 0; int ok = 0;
        for (int i = 0; i < x.length; i++) {
            double o = predict(x[i])[0];
            sum += sampleLoss(o, y[i]);
            if ((o >= 0.5 ? 1.0 : 0.0) == y[i]) ok++;
        }
        return new double[]{sum / x.length, (double) ok / x.length};
    }

    /** Gradien analitik (backpropagation) rata-rata atas batch; panjang = parameterCount(). */
    public double[] gradients(double[][] x, double[] y) {
        double[] g = new double[p.length];
        int L = layers();
        double[][] z = newZ(), a = newA();
        double[][] delta = new double[L][];
        for (int l = 0; l < L; l++) delta[l] = new double[sizes[l + 1]];
        for (int s = 0; s < x.length; s++) {
            forward(x[s], z, a);
            double o = a[L][0];
            if (loss == Loss.BINARY_CROSS_ENTROPY) delta[L - 1][0] = o - y[s];
            else delta[L - 1][0] = (o - y[s]) * output.derivative(z[L - 1][0], o);
            for (int l = L - 1; l >= 0; l--) {
                int in = sizes[l], out = sizes[l + 1];
                for (int j = 0; j < out; j++) {
                    g[bOff[l] + j] += delta[l][j];
                    int base = wOff[l] + j * in;
                    for (int i = 0; i < in; i++) g[base + i] += delta[l][j] * a[l][i];
                }
                if (l > 0) {
                    for (int i = 0; i < in; i++) {
                        double sum = 0;
                        for (int j = 0; j < out; j++) sum += p[wOff[l] + j * in + i] * delta[l][j];
                        delta[l - 1][i] = sum * hidden.derivative(z[l - 1][i], a[l][i]);
                    }
                }
            }
        }
        for (int i = 0; i < g.length; i++) g[i] /= x.length;
        return g;
    }

    /** Latih jaringan. Mengembalikan riwayat loss/akurasi (dihitung pada seluruh data tiap epoch). */
    public TrainingHistory fit(double[][] x, double[] y, TrainConfig cfg, EpochListener listener) {
        TrainingHistory h = new TrainingHistory();
        Optimizer opt = new Optimizer(cfg.optimizer, p.length);
        Random r = new Random(cfg.seed);
        int n = x.length; int[] idx = new int[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        int bs = Math.max(1, Math.min(cfg.batchSize, n));
        for (int e = 0; e < cfg.epochs; e++) {
            for (int i = n - 1; i > 0; i--) { int j = r.nextInt(i + 1); int t = idx[i]; idx[i] = idx[j]; idx[j] = t; }
            for (int start = 0; start < n; start += bs) {
                int end = Math.min(n, start + bs);
                double[][] bx = new double[end - start][]; double[] by = new double[end - start];
                for (int k = start; k < end; k++) { bx[k - start] = x[idx[k]]; by[k - start] = y[idx[k]]; }
                double[] g = gradients(bx, by);
                if (cfg.l2 > 0) for (int i = 0; i < g.length; i++) g[i] += cfg.l2 * p[i];
                opt.step(p, g, cfg.learningRate);
            }
            double[] ev = evaluate(x, y);
            h.loss.add(ev[0]); h.accuracy.add(ev[1]);
            if (Double.isNaN(ev[0]) || Double.isInfinite(ev[0])) { h.diverged = true; break; }
            if (listener != null && !listener.onEpoch(e + 1, ev[0], ev[1])) break;
        }
        return h;
    }
}
