package com.neuralnlp.academy.engine.lab;

import com.neuralnlp.academy.engine.nlp.*;

import java.util.*;

/** Fasad eksperimen NLP: semua logika ada di sini (teruji), UI hanya menampilkan hasilnya. */
public final class NlpLab {
    private NlpLab() {}

    public static final String[] BPE_CORPUS = {
        "belajar", "pelajar", "mengajar", "ajar", "pengajar", "pembelajaran", "belajar", "makan", "makanan", "dimakan", "memakan", "pemakan", "minum", "minuman", "diminum",
        "learning", "learner", "learned", "teach", "teacher", "teaching", "taught", "play", "player", "playing", "played", "playful"};

    /** Perbandingan tiga cara tokenisasi untuk teks yang sama. */
    public static final class TokenView {
        public final List<String> words, chars, subwords;
        TokenView(List<String> w, List<String> c, List<String> s) { words = w; chars = c; subwords = s; }
    }

    public static TokenView tokenize(String text, int bpeMerges) {
        List<String> words = Tokenizer.words(text);
        Bpe bpe = Bpe.train(Arrays.asList(BPE_CORPUS), bpeMerges);
        List<String> sub = new ArrayList<String>();
        for (String w : words) sub.addAll(bpe.encode(w));
        return new TokenView(words, Tokenizer.chars(text), sub);
    }

    /** Representasi Bag of Words: kosakata bersama dan vektor jumlah kata tiap dokumen. */
    public static final class BowView {
        public final List<String> vocabulary; public final List<int[]> vectors;
        BowView(List<String> v, List<int[]> x) { vocabulary = v; vectors = x; }
    }

    public static BowView bagOfWords(List<String> docs, String lang) {
        TextNormalizer.Options o = new TextNormalizer.Options(); o.lang = lang; o.removeStopwords = true; o.expandSlang = "id".equals(lang);
        List<List<String>> toks = new ArrayList<List<String>>();
        for (String d : docs) toks.add(Tokenizer.words(TextNormalizer.normalize(d, o)));
        BagOfWords b = new BagOfWords(); b.fit(toks);
        List<int[]> vs = new ArrayList<int[]>();
        for (List<String> t : toks) vs.add(b.vector(t));
        return new BowView(new ArrayList<String>(b.vocabulary()), vs);
    }

    /** Tabel TF-IDF: untuk tiap dokumen, kata-kata teratas beserta bobot. */
    public static List<List<Map.Entry<String, Double>>> tfidfTop(List<String> docs, String lang, int k) {
        TextNormalizer.Options o = new TextNormalizer.Options(); o.lang = lang; o.removeStopwords = true; o.expandSlang = "id".equals(lang);
        List<List<String>> toks = new ArrayList<List<String>>();
        for (String d : docs) toks.add(Tokenizer.words(TextNormalizer.normalize(d, o)));
        TfIdf t = new TfIdf(); t.fit(toks);
        List<List<Map.Entry<String, Double>>> out = new ArrayList<List<Map.Entry<String, Double>>>();
        for (List<String> d : toks) out.add(TfIdf.top(t.transform(d), k));
        return out;
    }

    private static List<String> sentimentTokens(String text, String lang) {
        TextNormalizer.Options o = new TextNormalizer.Options(); o.lang = lang; o.expandSlang = "id".equals(lang); o.stem = true;
        // Inggris: buang stopword (diukur: akurasi uji 0,70 -> 0,80 pada data kecil). Indonesia: JANGAN, karena daftar stopword memuat "tidak" yang membalik sentimen.
        o.removeStopwords = "en".equals(lang);
        return Tokenizer.words(TextNormalizer.normalize(text, o));
    }

    private static void collect(String lang, List<List<String>> x, List<String> y, int from, int step) {
        String[] pos = "en".equals(lang) ? NlpData.EN_POS : NlpData.ID_POS, neg = "en".equals(lang) ? NlpData.EN_NEG : NlpData.ID_NEG;
        for (int i = from; i < pos.length; i += step) { x.add(sentimentTokens(pos[i], lang)); y.add("positif"); }
        for (int i = from; i < neg.length; i += step) { x.add(sentimentTokens(neg[i], lang)); y.add("negatif"); }
    }

    /** Latih Naive Bayes pada seluruh dataset sentimen bawaan lalu beri peluang kelas untuk [text]. */
    public static Map<String, Double> classify(String text, String lang) {
        List<List<String>> x = new ArrayList<List<String>>(); List<String> y = new ArrayList<String>();
        collect(lang, x, y, 0, 1);
        NaiveBayes nb = new NaiveBayes(); nb.fit(x, y);
        return nb.probabilities(sentimentTokens(text, lang));
    }

    /** Akurasi pada data yang tidak ikut dilatih: tiap contoh ke-4 disisihkan sebagai data uji. */
    public static double heldOutAccuracy(String lang) {
        List<List<String>> trX = new ArrayList<List<String>>(), teX = new ArrayList<List<String>>(); List<String> trY = new ArrayList<String>(), teY = new ArrayList<String>();
        List<List<String>> ax = new ArrayList<List<String>>(); List<String> ay = new ArrayList<String>(); collect(lang, ax, ay, 0, 1);
        for (int i = 0; i < ax.size(); i++) { if (i % 4 == 3) { teX.add(ax.get(i)); teY.add(ay.get(i)); } else { trX.add(ax.get(i)); trY.add(ay.get(i)); } }
        NaiveBayes nb = new NaiveBayes(); nb.fit(trX, trY);
        return nb.accuracy(teX, teY);
    }
}
