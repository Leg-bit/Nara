package com.neuralnlp.academy.engine.learning;

public final class Recommendation {
    public enum Type { CONTINUE, REMEDIATE, REVIEW }
    public final String lessonId, reason; public final Type type;
    public Recommendation(String lessonId, Type type, String reason) { this.lessonId = lessonId; this.type = type; this.reason = reason; }
}
