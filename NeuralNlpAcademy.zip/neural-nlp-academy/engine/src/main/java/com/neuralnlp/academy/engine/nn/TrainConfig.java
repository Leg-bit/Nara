package com.neuralnlp.academy.engine.nn;

/** Pengaturan satu eksperimen pelatihan. */
public final class TrainConfig {
    public int epochs = 200;
    public int batchSize = 16;
    public double learningRate = 0.05;
    public OptimizerType optimizer = OptimizerType.ADAM;
    public double l2 = 0.0;
    public long seed = 1;

    public TrainConfig epochs(int v) { epochs = v; return this; }
    public TrainConfig batch(int v) { batchSize = v; return this; }
    public TrainConfig lr(double v) { learningRate = v; return this; }
    public TrainConfig optimizer(OptimizerType v) { optimizer = v; return this; }
    public TrainConfig l2(double v) { l2 = v; return this; }
    public TrainConfig seed(long v) { seed = v; return this; }
}
