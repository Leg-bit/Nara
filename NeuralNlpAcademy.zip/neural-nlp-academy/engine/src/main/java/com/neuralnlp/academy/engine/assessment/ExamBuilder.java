package com.neuralnlp.academy.engine.assessment;

import com.neuralnlp.academy.engine.learning.MasteryModel;
import com.neuralnlp.academy.engine.learning.Recommender;

import java.util.*;

/** Memilih soal secara adaptif: konsep yang lemah dan kesulitan yang pas lebih diutamakan; jenis soal dibuat beragam. */
public final class ExamBuilder {
    private ExamBuilder() {}

    public static List<Question> build(List<Question> pool, MasteryModel m, int n, Random rnd) {
        List<Question> left = new ArrayList<Question>(pool), out = new ArrayList<Question>();
        Map<QuestionType, Integer> used = new EnumMap<QuestionType, Integer>(QuestionType.class);
        while (out.size() < n && !left.isEmpty()) {
            Question best = null; double bs = -1;
            for (Question q : left) {
                double avg = 0; for (String c : q.concepts) avg += m.get(c) == null ? 0.3 : m.value(c);
                avg = q.concepts.isEmpty() ? 0.3 : avg / q.concepts.size();
                double weakness = 1.0 - avg;
                double fit = 1.0 - 0.15 * Math.abs(q.difficulty - Recommender.targetDifficulty(avg));
                Integer u = used.get(q.type);
                double variety = Math.pow(0.7, u == null ? 0 : u);
                double s = (0.5 + weakness) * fit * variety * (0.9 + 0.2 * rnd.nextDouble());
                if (s > bs) { bs = s; best = q; }
            }
            out.add(best); left.remove(best);
            Integer u = used.get(best.type); used.put(best.type, u == null ? 1 : u + 1);
        }
        return out;
    }
}
