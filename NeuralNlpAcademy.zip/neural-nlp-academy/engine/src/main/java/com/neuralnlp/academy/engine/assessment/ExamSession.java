package com.neuralnlp.academy.engine.assessment;

import com.neuralnlp.academy.engine.learning.MasteryModel;

import java.util.*;

/** Satu sesi ujian: soal dijawab satu per satu, lalu hasilnya memperbarui model penguasaan konsep. */
public final class ExamSession {
    private final List<Question> questions; private final List<Grade> grades = new ArrayList<Grade>();

    public ExamSession(List<Question> questions) { this.questions = new ArrayList<Question>(questions); }

    public List<Question> questions() { return questions; }
    public boolean finished() { return grades.size() == questions.size(); }
    public Question current() { return finished() ? null : questions.get(grades.size()); }

    public Grade submit(Answer a) {
        if (finished()) throw new IllegalStateException("ujian sudah selesai");
        Grade g = AssessmentEngine.grade(current(), a); grades.add(g); return g;
    }

    /** Hitung hasil akhir dan perbarui penguasaan konsep. */
    public ExamResult finish(MasteryModel m, long today) {
        if (!finished()) throw new IllegalStateException("masih ada soal belum dijawab");
        double num = 0, den = 0;
        Map<String, List<Double>> byConcept = new LinkedHashMap<String, List<Double>>();
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i); double s = grades.get(i).score;
            num += s * q.difficulty; den += q.difficulty;
            for (String c : q.concepts) { List<Double> l = byConcept.get(c); if (l == null) { l = new ArrayList<Double>(); byConcept.put(c, l); } l.add(s); m.update(c, s, q.difficulty, today); }
        }
        Map<String, Double> cs = new LinkedHashMap<String, Double>(); List<String> weak = new ArrayList<String>();
        for (Map.Entry<String, List<Double>> e : byConcept.entrySet()) { double sum = 0; for (double v : e.getValue()) sum += v; double avg = sum / e.getValue().size(); cs.put(e.getKey(), avg); if (avg < 0.6) weak.add(e.getKey()); }
        return new ExamResult(den == 0 ? 0 : num / den, cs, weak);
    }
}
