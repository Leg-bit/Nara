package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** TF-IDF: tf = jumlah kata, idf = ln((1+n)/(1+df)) + 1 (dihaluskan), vektor dinormalisasi L2. */
public final class TfIdf {
    private final Map<String, Double> idf = new HashMap<String, Double>();
    private double unseenIdf = 1.0;

    public void fit(List<List<String>> docs) {
        Map<String, Integer> df = new HashMap<String, Integer>();
        for (List<String> d : docs) for (String w : new HashSet<String>(d)) { Integer c = df.get(w); df.put(w, c == null ? 1 : c + 1); }
        int n = docs.size();
        idf.clear();
        for (Map.Entry<String, Integer> e : df.entrySet()) idf.put(e.getKey(), Math.log((1.0 + n) / (1.0 + e.getValue())) + 1.0);
        unseenIdf = Math.log((1.0 + n) / 1.0) + 1.0;
    }

    public double idf(String term) { Double v = idf.get(term); return v == null ? unseenIdf : v; }

    /** Vektor jarang (kata -> bobot) ternormalisasi L2. */
    public Map<String, Double> transform(List<String> doc) {
        Map<String, Double> tf = new LinkedHashMap<String, Double>();
        for (String w : doc) { if (!idf.containsKey(w)) continue; Double c = tf.get(w); tf.put(w, c == null ? 1.0 : c + 1.0); }
        double norm = 0;
        for (Map.Entry<String, Double> e : tf.entrySet()) { double v = e.getValue() * idf.get(e.getKey()); e.setValue(v); norm += v * v; }
        norm = Math.sqrt(norm);
        if (norm > 0) for (Map.Entry<String, Double> e : tf.entrySet()) e.setValue(e.getValue() / norm);
        return tf;
    }

    public static double cosine(Map<String, Double> a, Map<String, Double> b) {
        double dot = 0, na = 0, nb = 0;
        for (Map.Entry<String, Double> e : a.entrySet()) { na += e.getValue() * e.getValue(); Double o = b.get(e.getKey()); if (o != null) dot += e.getValue() * o; }
        for (double v : b.values()) nb += v * v;
        return na == 0 || nb == 0 ? 0 : dot / Math.sqrt(na * nb);
    }

    public static List<Map.Entry<String, Double>> top(Map<String, Double> vec, int k) {
        List<Map.Entry<String, Double>> l = new ArrayList<Map.Entry<String, Double>>(vec.entrySet());
        Collections.sort(l, new Comparator<Map.Entry<String, Double>>() { public int compare(Map.Entry<String, Double> x, Map.Entry<String, Double> y) { int c = Double.compare(y.getValue(), x.getValue()); return c != 0 ? c : x.getKey().compareTo(y.getKey()); } });
        return l.subList(0, Math.min(k, l.size()));
    }
}
