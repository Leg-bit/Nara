package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Pencarian dokumen berbasis TF-IDF + cosine (dasar pencarian semantik leksikal). */
public final class SemanticSearch {
    public static final class Hit { public final int index; public final double score; Hit(int i, double s) { index = i; score = s; } }

    private final TfIdf tfidf = new TfIdf();
    private final List<Map<String, Double>> vecs = new ArrayList<Map<String, Double>>();
    private final TextNormalizer.Options opt = new TextNormalizer.Options();

    public SemanticSearch(String lang) { opt.lang = lang; opt.removeStopwords = true; opt.stem = true; opt.expandSlang = "id".equals(lang); }

    private List<String> toks(String s) { return Tokenizer.words(TextNormalizer.normalize(s, opt)); }

    public void index(List<String> docs) {
        List<List<String>> t = new ArrayList<List<String>>();
        for (String d : docs) t.add(toks(d));
        tfidf.fit(t);
        vecs.clear();
        for (List<String> d : t) vecs.add(tfidf.transform(d));
    }

    public List<Hit> search(String query, int k) {
        Map<String, Double> q = tfidf.transform(toks(query));
        List<Hit> hits = new ArrayList<Hit>();
        for (int i = 0; i < vecs.size(); i++) { double s = TfIdf.cosine(q, vecs.get(i)); if (s > 0) hits.add(new Hit(i, s)); }
        Collections.sort(hits, new Comparator<Hit>() { public int compare(Hit a, Hit b) { return Double.compare(b.score, a.score); } });
        return hits.subList(0, Math.min(k, hits.size()));
    }
}
