package com.neuralnlp.academy.engine.lab;

import com.neuralnlp.academy.engine.nn.Activation;
import com.neuralnlp.academy.engine.nn.OptimizerType;

/** Pengaturan eksperimen di Laboratorium Jaringan Saraf. */
public final class NnLabConfig {
    public String dataset = "circles";           // xor | and | blobs | circles | moons
    public int[] hidden = {8};                   // jumlah neuron tiap lapisan tersembunyi (kosong = satu neuron)
    public Activation activation = Activation.TANH;
    public double learningRate = 0.03;
    public int epochs = 250;
    public int batchSize = 16;
    public OptimizerType optimizer = OptimizerType.ADAM;
    public double l2 = 0.0;
    public long seed = 1;
}
