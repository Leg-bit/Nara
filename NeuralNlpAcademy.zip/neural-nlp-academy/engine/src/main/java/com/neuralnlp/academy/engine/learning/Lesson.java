package com.neuralnlp.academy.engine.learning;

import java.util.*;

/** Metadata satu pelajaran dalam kurikulum (isi pelajaran disimpan terpisah di berkas JSON aset). */
public final class Lesson {
    public final String id, track, title;
    public final int order, difficulty;
    public final List<String> prerequisites, concepts;
    /** false = baru kerangka (belum ditulis): tidak boleh direkomendasikan atau dibuka sebagai pelajaran. */
    public final boolean authored;

    public Lesson(String id, String track, int order, String title, int difficulty, List<String> prerequisites, List<String> concepts, boolean authored) {
        this.id = id; this.track = track; this.order = order; this.title = title; this.difficulty = difficulty;
        this.prerequisites = Collections.unmodifiableList(new ArrayList<String>(prerequisites));
        this.concepts = Collections.unmodifiableList(new ArrayList<String>(concepts));
        this.authored = authored;
    }
}
