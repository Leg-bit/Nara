package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Representasi Bag of Words: kosakata terurut + vektor jumlah kata. */
public final class BagOfWords {
    private final List<String> vocab = new ArrayList<String>();
    private final Map<String, Integer> index = new HashMap<String, Integer>();

    public void fit(List<List<String>> docs) {
        TreeSet<String> set = new TreeSet<String>();
        for (List<String> d : docs) set.addAll(d);
        vocab.clear(); index.clear();
        for (String w : set) { index.put(w, vocab.size()); vocab.add(w); }
    }

    public List<String> vocabulary() { return Collections.unmodifiableList(vocab); }

    public int[] vector(List<String> doc) {
        int[] v = new int[vocab.size()];
        for (String w : doc) { Integer i = index.get(w); if (i != null) v[i]++; }
        return v;
    }
}
