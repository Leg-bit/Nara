package com.neuralnlp.academy.engine.nn;

/** Pembaruan parameter pada vektor datar: SGD, Momentum, atau Adam. */
final class Optimizer {
    private final OptimizerType type;
    private final double[] m, v;
    private int t = 0;

    Optimizer(OptimizerType type, int n) { this.type = type; m = new double[n]; v = new double[n]; }

    void step(double[] p, double[] g, double lr) {
        t++;
        switch (type) {
            case SGD:
                for (int i = 0; i < p.length; i++) p[i] -= lr * g[i];
                break;
            case MOMENTUM:
                for (int i = 0; i < p.length; i++) { m[i] = 0.9 * m[i] + g[i]; p[i] -= lr * m[i]; }
                break;
            default: {
                double b1 = 0.9, b2 = 0.999, eps = 1e-8;
                double c1 = 1 - Math.pow(b1, t), c2 = 1 - Math.pow(b2, t);
                for (int i = 0; i < p.length; i++) {
                    m[i] = b1 * m[i] + (1 - b1) * g[i];
                    v[i] = b2 * v[i] + (1 - b2) * g[i] * g[i];
                    p[i] -= lr * (m[i] / c1) / (Math.sqrt(v[i] / c2) + eps);
                }
            }
        }
    }
}
