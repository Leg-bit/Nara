package com.neuralnlp.academy.engine.nn;

public enum OptimizerType { SGD, MOMENTUM, ADAM }
