package com.neuralnlp.academy.engine.learning;

import java.util.*;

/**
 * Penguasaan per konsep (0..1) yang diperbarui dari hasil soal. Pembaruan mirip Elo: laju belajar menurun seiring bukti,
 * soal sulit berbobot lebih. Penguasaan efektif meluruh seiring waktu (lupa) agar materi lama diulang.
 */
public final class MasteryModel {
    public static final double PRIOR = 0.3, WEAK = 0.6;

    public static final class Mastery {
        public double value; public int evidence; public long lastDay;
        public Mastery(double v, int e, long d) { value = v; evidence = e; lastDay = d; }
    }

    private final Map<String, Mastery> map = new LinkedHashMap<String, Mastery>();

    public Mastery get(String concept) { return map.get(concept); }
    public Map<String, Mastery> all() { return Collections.unmodifiableMap(map); }
    public void put(String concept, Mastery m) { map.put(concept, m); }

    public double value(String concept) { Mastery m = map.get(concept); return m == null ? 0.0 : m.value; }

    public void update(String concept, double score, int difficulty, long today) {
        Mastery m = map.get(concept);
        if (m == null) { m = new Mastery(PRIOR, 0, today); map.put(concept, m); }
        double lr = Math.max(0.15, 0.5 / (1 + 0.25 * m.evidence));
        double w = 0.6 + 0.1 * Math.max(1, Math.min(5, difficulty));
        m.value = Math.max(0.0, Math.min(1.0, m.value + lr * w * (score - m.value)));
        m.evidence++; m.lastDay = today;
    }

    /** Penguasaan setelah memperhitungkan lupa: value * exp(-hari / stabilitas); stabilitas tumbuh dengan jumlah bukti. */
    public double effective(String concept, long today) {
        Mastery m = map.get(concept);
        if (m == null) return 0.0;
        double stability = 7.0 + 6.0 * Math.min(m.evidence, 8);
        return m.value * Math.exp(-Math.max(0, today - m.lastDay) / stability);
    }

    /** Konsep lemah: sudah pernah diuji tetapi penguasaan di bawah ambang. Terlemah lebih dulu. */
    public List<String> weakConcepts() {
        List<String> out = new ArrayList<String>();
        for (Map.Entry<String, Mastery> e : map.entrySet()) if (e.getValue().evidence >= 1 && e.getValue().value < WEAK) out.add(e.getKey());
        Collections.sort(out, new Comparator<String>() { public int compare(String a, String b) { return Double.compare(value(a), value(b)); } });
        return out;
    }

    public double average(Collection<String> concepts) {
        if (concepts.isEmpty()) return 0.0;
        double s = 0; for (String c : concepts) s += value(c);
        return s / concepts.size();
    }
}
