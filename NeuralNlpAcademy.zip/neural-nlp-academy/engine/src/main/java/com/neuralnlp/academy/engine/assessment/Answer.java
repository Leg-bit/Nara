package com.neuralnlp.academy.engine.assessment;

/** Jawaban pengguna; isi sesuai jenis soal (pilihan, angka, teks, atau metrik hasil eksperimen). */
public final class Answer {
    public int choice = -1; public Double number; public String text = "";
    public static Answer choice(int i) { Answer a = new Answer(); a.choice = i; return a; }
    public static Answer number(double v) { Answer a = new Answer(); a.number = v; return a; }
    public static Answer text(String t) { Answer a = new Answer(); a.text = t == null ? "" : t; return a; }
}
