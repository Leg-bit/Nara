package com.neuralnlp.academy.engine.lab;

import com.neuralnlp.academy.engine.nn.*;

/** Menjalankan satu eksperimen pelatihan lengkap (dataset -> jaringan -> pelatihan -> evaluasi). Dipakai Laboratorium dan asesmen eksperimen. */
public final class NnLab {
    private NnLab() {}

    public static Dataset dataset(String name) {
        if ("xor".equals(name)) return Dataset.xor();
        if ("and".equals(name)) return Dataset.and();
        if ("blobs".equals(name)) return Dataset.blobs(300, 0.35, 5);
        if ("moons".equals(name)) return Dataset.moons(300, 0.1, 6);
        return Dataset.circles(300, 0.08, 4);
    }

    /** Dataset 4 titik (XOR/AND) tidak dibagi; data uji = data latih (ditandai agar UI jujur). */
    public static boolean isTiny(String name) { return "xor".equals(name) || "and".equals(name); }

    public static NnLabResult run(NnLabConfig c, Network.EpochListener listener) {
        Dataset all = dataset(c.dataset);
        Dataset[] s = isTiny(c.dataset) ? new Dataset[]{all, all} : all.split(0.7, 2);
        int[] sizes = new int[c.hidden.length + 2];
        sizes[0] = 2; for (int i = 0; i < c.hidden.length; i++) sizes[i + 1] = Math.max(1, c.hidden[i]); sizes[sizes.length - 1] = 1;
        Network n = new Network(sizes, c.activation, Activation.SIGMOID, Network.Loss.BINARY_CROSS_ENTROPY, c.seed);
        TrainConfig tc = new TrainConfig().epochs(c.epochs).batch(c.batchSize).lr(c.learningRate).optimizer(c.optimizer).l2(c.l2).seed(c.seed);
        TrainingHistory h = n.fit(s[0].x, s[0].y, tc, listener);
        return new NnLabResult(h, n, s[0], s[1], n.evaluate(s[0].x, s[0].y), n.evaluate(s[1].x, s[1].y));
    }
}
