package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/** Normalisasi teks bertahap (huruf kecil, tanda baca, singkatan gaul, stopword, stemming) dengan jejak tiap langkah untuk visualisasi. */
public final class TextNormalizer {
    public static final class Options {
        public boolean lowercase = true, stripPunctuation = true, expandSlang = false, removeStopwords = false, stem = false;
        public String lang = "id";
    }

    public static final class Step {
        public final String name, result;
        Step(String n, String r) { name = n; result = r; }
    }

    private static final Map<String, String> SLANG = new HashMap<String, String>();
    static {
        String[] s = {"gak", "tidak", "nggak", "tidak", "ga", "tidak", "bgt", "banget", "yg", "yang", "dgn", "dengan", "tdk", "tidak", "udh", "sudah", "sdh", "sudah",
            "krn", "karena", "utk", "untuk", "aja", "saja", "dlm", "dalam", "tp", "tapi", "jg", "juga", "sm", "sama", "hrs", "harus", "bs", "bisa", "lg", "lagi", "org", "orang",
            "skrg", "sekarang", "brp", "berapa", "kmu", "kamu", "gue", "saya", "gw", "saya", "lu", "kamu", "klo", "kalau", "kalo", "kalau", "emg", "memang", "banget", "sangat"};
        for (int i = 0; i < s.length; i += 2) SLANG.put(s[i], s[i + 1]);
    }
    private static final Set<String> STOP_ID = new HashSet<String>(Arrays.asList("yang", "dan", "di", "ke", "dari", "untuk", "dengan", "ini", "itu", "pada", "adalah", "atau", "saya", "kamu", "aku", "kami", "mereka", "juga", "akan", "sudah", "ada", "dalam", "oleh", "karena", "tidak", "saja", "lagi", "sangat"));
    private static final Set<String> STOP_EN = new HashSet<String>(Arrays.asList("the", "a", "an", "and", "or", "of", "to", "in", "on", "at", "is", "are", "was", "were", "i", "you", "he", "she", "it", "we", "they", "this", "that", "for", "with", "be", "as", "by", "my", "your"));

    public static boolean isStopword(String w, String lang) { return ("en".equals(lang) ? STOP_EN : STOP_ID).contains(w); }

    public static List<Step> steps(String text, Options o) {
        List<Step> out = new ArrayList<Step>();
        String t = text;
        out.add(new Step("asli", t));
        if (o.lowercase) { t = t.toLowerCase(Locale.ROOT); out.add(new Step("huruf kecil", t)); }
        if (o.stripPunctuation) { t = t.replaceAll("[^\\p{L}\\p{N}\\s]", " ").replaceAll("\\s+", " ").trim(); out.add(new Step("tanpa tanda baca", t)); }
        List<String> toks = new ArrayList<String>(t.isEmpty() ? Collections.<String>emptyList() : Arrays.asList(t.split("\\s+")));
        if (o.expandSlang) {
            for (int i = 0; i < toks.size(); i++) { String r = SLANG.get(toks.get(i)); if (r != null) toks.set(i, r); }
            out.add(new Step("singkatan dibakukan", join(toks)));
        }
        if (o.removeStopwords) {
            List<String> k = new ArrayList<String>();
            for (String w : toks) if (!isStopword(w, o.lang)) k.add(w);
            toks = k; out.add(new Step("tanpa stopword", join(toks)));
        }
        if (o.stem) {
            for (int i = 0; i < toks.size(); i++) toks.set(i, "en".equals(o.lang) ? Stemmer.stemEnglish(toks.get(i)) : Stemmer.stemIndonesian(toks.get(i)));
            out.add(new Step("stemming", join(toks)));
        }
        return out;
    }

    public static String normalize(String text, Options o) { List<Step> s = steps(text, o); return s.get(s.size() - 1).result; }

    private static String join(List<String> l) { StringBuilder sb = new StringBuilder(); for (String s : l) { if (sb.length() > 0) sb.append(' '); sb.append(s); } return sb.toString(); }
}
