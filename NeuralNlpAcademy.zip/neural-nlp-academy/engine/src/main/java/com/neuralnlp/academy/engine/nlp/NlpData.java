package com.neuralnlp.academy.engine.nlp;

/** Dataset kecil bawaan (bahasa Indonesia & Inggris) untuk eksperimen klasifikasi dan identifikasi bahasa secara offline. */
public final class NlpData {
    private NlpData() {}

    public static final String[] ID_POS = {
        "film ini bagus sekali dan menyenangkan", "pelayanannya ramah dan cepat", "makanannya enak sekali, saya suka", "aplikasinya mudah dipakai dan sangat membantu",
        "harganya murah dan kualitasnya bagus", "saya puas dengan pembelian ini", "tempatnya nyaman dan bersih", "pengiriman cepat barang sesuai pesanan",
        "guru yang mengajar sangat baik dan sabar", "pemandangannya indah dan bikin tenang", "hasilnya memuaskan, terima kasih banyak", "suasananya menyenangkan dan seru",
        "layanan pelanggan sangat membantu dan sopan", "kameranya bagus dan baterainya awet", "ceritanya menarik dan menyentuh hati", "saya senang sekali dengan hasilnya",
        "produk berkualitas dan sangat direkomendasikan", "kopinya mantap dan tempatnya asyik", "desainnya keren dan elegan", "performanya cepat dan stabil",
        "staf hotel sangat ramah dan membantu", "rasanya lezat dan porsinya pas", "pengalaman yang luar biasa, pasti kembali lagi", "bukunya inspiratif dan mudah dipahami"};

    public static final String[] ID_NEG = {
        "film ini jelek dan membosankan", "pelayanannya lambat dan tidak ramah", "makanannya hambar dan mahal, saya kecewa", "aplikasinya sering error dan lemot",
        "harganya mahal tapi kualitasnya buruk", "saya kecewa dengan pembelian ini", "tempatnya kotor dan bau", "pengiriman lama barang rusak",
        "guru yang mengajar tidak jelas dan galak", "pemandangannya biasa saja dan ramai sekali", "hasilnya mengecewakan, buang uang saja", "suasananya membosankan dan berisik",
        "layanan pelanggan tidak membantu dan kasar", "kameranya jelek dan baterainya boros", "ceritanya membingungkan dan membosankan", "saya sangat kesal dengan hasilnya",
        "produk murahan dan tidak direkomendasikan", "kopinya pahit dan tempatnya sempit", "desainnya norak dan murahan", "performanya lambat dan sering macet",
        "staf hotel sangat tidak ramah dan cuek", "rasanya aneh dan porsinya kecil", "pengalaman yang buruk, tidak akan kembali", "bukunya membosankan dan sulit dipahami"};

    public static final String[] EN_POS = {
        "this movie is great and very enjoyable", "the service was friendly and fast", "the food is delicious and I love it", "the app is easy to use and really helpful",
        "the price is low and the quality is good", "i am satisfied with this purchase", "the place is comfortable and clean", "fast delivery and the item matches the order",
        "the teacher is kind and patient", "the view is beautiful and calming", "the result is satisfying, thank you so much", "the atmosphere is fun and exciting",
        "customer support was helpful and polite", "the camera is excellent and the battery lasts long", "the story is moving and interesting", "i am very happy with the outcome",
        "high quality product and highly recommended", "the coffee is amazing and the place is cozy", "the design is cool and elegant", "the performance is fast and stable"};

    public static final String[] EN_NEG = {
        "this movie is terrible and boring", "the service was slow and rude", "the food is bland and expensive, i am disappointed", "the app crashes often and is very slow",
        "the price is high but the quality is poor", "i am disappointed with this purchase", "the place is dirty and smells bad", "late delivery and the item was broken",
        "the teacher is unclear and harsh", "the view is ordinary and too crowded", "the result is disappointing, a waste of money", "the atmosphere is dull and noisy",
        "customer support was useless and rude", "the camera is bad and the battery drains fast", "the story is confusing and boring", "i am really annoyed with the outcome",
        "cheap product and not recommended", "the coffee is bitter and the place is cramped", "the design is ugly and cheap", "the performance is slow and often freezes"};

    /** Kalimat umum tambahan untuk profil bahasa (di luar dataset sentimen). */
    public static final String[] ID_GENERAL = {
        "selamat pagi, apa kabar hari ini", "saya sedang belajar pemrograman di rumah", "besok kita akan pergi ke pasar bersama", "tolong ambilkan buku yang ada di meja itu",
        "kami tinggal di kota yang cukup besar", "dia suka membaca cerita sebelum tidur malam", "cuaca hari ini sangat cerah dan hangat", "jangan lupa membawa payung karena mungkin hujan"};
    public static final String[] EN_GENERAL = {
        "good morning, how are you today", "i am studying programming at home", "tomorrow we will go to the market together", "please bring me the book that is on that table",
        "we live in a fairly big city", "she likes reading stories before bedtime", "the weather today is very bright and warm", "do not forget to bring an umbrella because it might rain"};
}
