package com.neuralnlp.academy.engine.learning;

import java.util.Map;

/** Aturan pembukaan pelajaran: hanya skor asesmen yang membuka materi lanjutan, tidak pernah tombol "selesai". */
public final class UnlockPolicy {
    public static final double PASS_SCORE = 0.7;
    private UnlockPolicy() {}

    public static boolean isPassed(Map<String, LessonRecord> records, String lessonId) {
        LessonRecord r = records.get(lessonId);
        return r != null && r.passed();
    }

    /** Terbuka kalau semua prasyaratnya lulus. */
    public static boolean isUnlocked(Lesson l, Map<String, LessonRecord> records) {
        for (String p : l.prerequisites) if (!isPassed(records, p)) return false;
        return true;
    }
}
