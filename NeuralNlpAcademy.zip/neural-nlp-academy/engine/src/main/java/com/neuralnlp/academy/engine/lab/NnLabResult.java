package com.neuralnlp.academy.engine.lab;

import com.neuralnlp.academy.engine.nn.*;

public final class NnLabResult {
    public final TrainingHistory history; public final Network network; public final Dataset train, test;
    public final double trainLoss, trainAccuracy, testLoss, testAccuracy;
    NnLabResult(TrainingHistory h, Network n, Dataset tr, Dataset te, double[] a, double[] b) { history = h; network = n; train = tr; test = te; trainLoss = a[0]; trainAccuracy = a[1]; testLoss = b[0]; testAccuracy = b[1]; }
}
