package com.neuralnlp.academy.engine.nlp;

import java.util.*;

/**
 * Stemmer sederhana untuk tujuan belajar (bukan pengganti Sastrawi): aturan imbuhan + kamus akar kata kecil untuk memilih
 * kandidat yang benar. Kata di luar kamus dikupas secara konservatif. Keterbatasan ini sengaja ditampilkan di pelajaran.
 */
public final class Stemmer {
    private Stemmer() {}

    private static final Set<String> ROOTS = new HashSet<String>(Arrays.asList(
        "kalah", "menang", "buat", "main", "makan", "minum", "lari", "tulis", "baca", "pakai", "ambil", "ajar", "belajar", "kerja", "jalan", "lihat", "dengar", "bicara", "cari", "beli", "jual",
        "bantu", "tanya", "jawab", "pikir", "kirim", "terima", "bawa", "datang", "pergi", "pulang", "tidur", "bangun", "mulai", "selesai", "ingat", "lupa", "suka", "cinta", "sayang", "senang",
        "sedih", "marah", "takut", "berani", "besar", "kecil", "baik", "buruk", "indah", "cantik", "bahagia", "tahu", "kenal", "coba", "pilih", "putar", "buka", "tutup", "nyala", "mati", "ubah",
        "ganti", "simpan", "hapus", "temu", "sapa", "undang", "latih", "didik", "tarik", "dorong", "angkat", "turun", "naik", "masuk", "keluar", "hitung", "ukur", "timbang", "tekan", "ketik",
        "rasa", "harap", "ajak", "kenang", "pimpin", "ikut", "tolong", "jaga", "rawat", "tanam", "tumbuh", "hidup", "panas", "dingin", "dapat", "tiru", "ulang", "sebut", "kata", "lapor"));

    private static String cutSuffix(String w, String suf) { return w.endsWith(suf) && w.length() - suf.length() >= 3 ? w.substring(0, w.length() - suf.length()) : null; }

    public static String stemIndonesian(String word) {
        String w = word.toLowerCase(Locale.ROOT);
        if (ROOTS.contains(w)) return w;
        for (String p : new String[]{"lah", "kah", "pun", "nya", "ku", "mu"}) { String c = cutSuffix(w, p); if (c != null) { w = c; break; } }
        List<String> bases = new ArrayList<String>(); bases.add(w);
        for (String d : new String[]{"kan", "an", "i"}) { String c = cutSuffix(w, d); if (c != null) { bases.add(c); break; } }
        String fallback = null;
        for (String b : bases) {
            if (ROOTS.contains(b)) return b;
            for (String c : prefixCandidates(b)) { if (ROOTS.contains(c)) return c; if (fallback == null && !c.equals(b)) fallback = c; }
        }
        // di luar kamus: kupas konservatif (sufiks turunan lalu prefiks yang aturannya jelas)
        String last = bases.get(bases.size() - 1);
        List<String> pc = prefixCandidates(last);
        if (pc.size() > 1) return pc.get(1);
        return last;
    }

    private static List<String> prefixCandidates(String b) {
        List<String> out = new ArrayList<String>(); out.add(b);
        String[][] pre = {{"meng", "", "k"}, {"meny", "s"}, {"men", "", "t"}, {"mem", "", "p"}, {"me", ""}, {"peng", "", "k"}, {"peny", "s"}, {"pen", "", "t"}, {"pem", "", "p"}, {"pe", ""},
                          {"ber", ""}, {"be", ""}, {"ter", ""}, {"di", ""}, {"ke", ""}, {"se", ""}, {"kau", ""}, {"ku", ""}};
        for (String[] p : pre) if (b.startsWith(p[0]) && b.length() - p[0].length() >= 3) {
            String rest = b.substring(p[0].length());
            for (int i = 1; i < p.length; i++) out.add(p[i] + rest);
        }
        return out;
    }

    private static final Map<String, String> IRREGULAR = new HashMap<String, String>();
    static {
        String[] s = {"was", "be", "were", "be", "is", "be", "are", "be", "been", "be", "am", "be", "has", "have", "had", "have", "did", "do", "does", "do", "went", "go", "goes", "go", "gone", "go",
            "better", "good", "best", "good", "children", "child", "mice", "mouse", "men", "man", "women", "woman", "feet", "foot", "teeth", "tooth", "ran", "run", "saw", "see", "ate", "eat", "wrote", "write"};
        for (int i = 0; i < s.length; i += 2) IRREGULAR.put(s[i], s[i + 1]);
    }

    /** Lematisasi Inggris sederhana: bentuk tak beraturan lewat kamus, sisanya lewat stem. */
    public static String lemmaEnglish(String word) {
        String w = word.toLowerCase(Locale.ROOT);
        String irr = IRREGULAR.get(w);
        return irr != null ? irr : stemEnglish(w);
    }

    /** Stem Inggris sederhana (aturan sufiks mirip Porter versi ringkas). */
    public static String stemEnglish(String word) {
        String w = word.toLowerCase(Locale.ROOT);
        if (w.length() <= 3) return w;
        if (w.endsWith("sses")) return w.substring(0, w.length() - 2);
        if (w.endsWith("ies") && w.length() > 4) return w.substring(0, w.length() - 3) + "y";
        if (w.endsWith("ing") && w.length() > 5) return undouble(w.substring(0, w.length() - 3));
        if (w.endsWith("ed") && w.length() > 4) return undouble(w.substring(0, w.length() - 2));
        if (w.endsWith("ly") && w.length() > 4) return w.substring(0, w.length() - 2);
        if (w.endsWith("s") && !w.endsWith("ss") && w.length() > 3) return w.substring(0, w.length() - 1);
        return w;
    }

    private static String undouble(String s) {
        int n = s.length();
        if (n >= 3 && s.charAt(n - 1) == s.charAt(n - 2) && "bdgmnprt".indexOf(s.charAt(n - 1)) >= 0) return s.substring(0, n - 1);
        return s;
    }
}
