# Neural & NLP Academy — Arsitektur (Fase 0 + Fase 1)

Dokumen ini ditulis sebelum implementasi dan diperbarui agar sesuai dengan apa yang benar-benar ada di repositori.

## 1. Status jujur terhadap spesifikasi

| Bagian spesifikasi | Status Fase 1 | Verifikasi |
|---|---|---|
| Dashboard belajar (progres total/per jalur, tahap, skor, runtun, rekomendasi) | Ada | Logika di engine diuji; UI belum dikompilasi |
| Kurikulum Neural Network (18 pelajaran) | Kerangka 18 + prasyarat; **3 pelajaran ditulis penuh** (nn-01..03) | Skema dan kode pelajaran diverifikasi skrip |
| Kurikulum NLP (20 pelajaran) | Kerangka 20 + prasyarat; **3 pelajaran ditulis penuh** (nlp-01..03) | idem |
| Laboratorium Jaringan Saraf | Ada (arsitektur, aktivasi, laju belajar, optimizer, pelatihan nyata, loss, batas keputusan, bobot/bias, metrik) | Engine diuji (cek gradien, XOR, optimizer) |
| Laboratorium NLP | Ada (tokenisasi kata/huruf/BPE, normalisasi bertahap, BoW, TF-IDF, klasifikasi Naive Bayes, identifikasi bahasa) | Engine diuji |
| Code Playground | Penampil + editor berwarna + perbandingan + keluaran diharapkan + tantangan. **Python tidak dieksekusi di aplikasi** (dinyatakan jelas di UI) | Keluaran diharapkan = hasil eksekusi nyata di PC |
| Sistem asesmen | MCQ, hitungan, penjelasan konsep (rubrik), keluaran kode, eksperimen praktik. **Ujian topik penuh belum ada** (Fase 2) | Diuji, termasuk terhadap aset asli |
| Progres & analitik | Pelajaran lulus, riwayat asesmen/eksperimen, kompetensi per konsep (dengan peluruhan lupa), konsep lemah, runtun. **Progres proyek praktik belum ada** | Logika diuji; Room belum dikompilasi |
| Mesin pengajaran adaptif | Ada: penguasaan konsep, pembukaan berdasar skor, remediasi prasyarat, ulangan saat terlupa, soal adaptif | Diuji |
| Offline-first | Ya: aset lokal, Room, DataStore, tanpa jaringan | — |
| UI Compose gelap biru tengah malam | Ada, sederhana (animasi minimal) | **Belum dikompilasi** |
| ONNX Runtime / LiteRT, Hugging Face, PyTorch | **Belum** (Fase 4). Hanya NumPy/PyTorch sebagai kode contoh; pelajaran Fase 1 memakai NumPy | — |
| APK debug/release | Dikonfigurasi (Gradle + workflow CI). **Tidak dibangun di lingkungan ini** | Perlu CI atau Android Studio |

Yang tidak diklaim: bahwa kode Kotlin/Compose/Room sudah terkompilasi atau teruji di perangkat. Itu belum pernah dijalankan; hanya modul `engine` (Java murni) dan aset yang diuji nyata.

## 2. Struktur repositori

```
neural-nlp-academy/
├─ settings.gradle.kts, build.gradle.kts, gradle.properties
├─ .github/workflows/build.yml        CI: uji engine + uji app + verifikasi Python + APK debug/release
├─ docs/ARCHITECTURE.md               dokumen ini
├─ tools/
│  ├─ gen_curriculum.py               sumber tunggal isi kurikulum -> JSON aset (menjalankan kode pelajaran untuk keluaran asli)
│  ├─ verify_lessons.py               menjalankan SEMUA cuplikan Python dan membandingkan dengan soal
│  └─ check_schema.py                 kontrak data aset vs parser Kotlin
├─ engine/                            modul JVM murni (Java, tanpa Android) — otak aplikasi, diuji otomatis
│  └─ com.neuralnlp.academy.engine
│     ├─ nn/          Network (MLP + backprop), Optimizer (SGD/Momentum/Adam), Activation, Dataset, TrainConfig, TrainingHistory
│     ├─ nlp/         TextNormalizer, Tokenizer, Bpe, Stemmer, BagOfWords, TfIdf, NaiveBayes, LanguageIdentifier, SemanticSearch, NlpData
│     ├─ lab/         NnLab, NlpLab (fasad eksperimen; UI hanya menampilkan hasil)
│     ├─ learning/    Curriculum (graf prasyarat), MasteryModel, UnlockPolicy, Recommender, Streak, Lesson, LessonRecord
│     └─ assessment/  Question, Answer, Grade, AssessmentEngine, ExamBuilder, ExamSession, ExamResult
└─ app/                               aplikasi Android (Kotlin, Compose)
   ├─ src/main/assets/curriculum/     curriculum.json (38 pelajaran) + lessons/*.json (pelajaran tertulis)
   └─ com.neuralnlp.academy
      ├─ data/        CurriculumRepository, ProgressRepository, SettingsStore (DataStore), db/ (Room)
      ├─ domain/      LessonContent, CurriculumJson (parser aset -> objek engine)
      ├─ AcademyViewModel, LessonViewModel   (MVVM, StateFlow)
      └─ ui/          theme/, components/, viz/ (6 visualisasi), lab/ (NnLabPanel, NlpLabPanel), screens/, AcademyNav
```

Mengapa engine di Java: modul ini dapat dikompilasi dan diuji tanpa Android sehingga logika inti (pelatihan, NLP, penilaian, adaptasi) benar-benar terverifikasi. Seluruh kode yang menyentuh Android tetap Kotlin.

## 3. Tanggung jawab modul dan batas antarmuka

- **engine** tidak tahu Android, UI, atau penyimpanan. Masukan/keluaran adalah objek polos. `NnLab.run(config, listener)` dan `NlpLab.*` adalah satu-satunya pintu eksperimen; `AssessmentEngine.grade`, `ExamBuilder`, `ExamSession`, `Recommender`, `MasteryModel` adalah satu-satunya pintu logika belajar.
- **data** menyimpan dan memuat; membangun ulang `MasteryModel` dan `LessonRecord` dari Room sehingga UI selalu menerima salinan baru (tanpa status bersama yang berubah diam-diam).
- **domain** mengubah JSON aset menjadi objek engine; tidak ada aturan belajar di sini.
- **ui** hanya menampilkan dan meneruskan aksi; tidak menghitung penilaian atau pembukaan pelajaran.

## 4. Siklus belajar dan aturan adaptif

Tahap per pelajaran: Konsep → Penjelasan → Matematika → Visualisasi → Implementasi → Eksperimen → Asesmen → Umpan balik.

- **Satu pelajaran sekali waktu**: layar pelajaran membuka satu pelajaran; tahap hanya bisa dilompati ke tahap yang sudah dicapai.
- **Tidak ada tombol "Selesai"**. Pelajaran lulus hanya bila skor asesmen terbaik ≥ 0,7 (`UnlockPolicy`). Pelajaran berikutnya terbuka hanya bila semua prasyarat lulus.
- **Penguasaan konsep** (`MasteryModel`): v ← v + lr · w · (skor − v), dengan lr = max(0,15; 0,5/(1+0,25·bukti)) dan w = 0,6 + 0,1·kesulitan. Satu jawaban benar belum berarti menguasai (diuji). Penguasaan efektif meluruh: v · exp(−hari/(7+6·min(bukti,8))).
- **Konsep lemah**: sudah diuji dan v < 0,6.
- **Rekomendasi** (`Recommender`), urutan prioritas: (1) remediasi — pelajaran yang dicoba tapi belum lulus dengan konsep v < 0,5 → rekomendasikan prasyarat yang memuat konsep itu; (2) lanjut ke pelajaran terbuka berikutnya yang sudah ditulis; (3) ulangan untuk pelajaran lulus yang penguasaan efektifnya < 0,75. Pelajaran `authored=false` tidak pernah direkomendasikan atau bisa dibuka.
- **Asesmen adaptif** (`ExamBuilder`): soal dengan konsep lemah diutamakan, kesulitan didekatkan ke penguasaan, jenis soal dibuat beragam.
- **Penilaian** (`AssessmentEngine`): pilihan ganda; angka dengan toleransi dan kredit sebagian; penjelasan konsep lewat rubrik gagasan+sinonim dengan pencocokan kata dasar (bukan teks persis) dan umpan balik gagasan yang belum disebut; keluaran kode baris demi baris dengan toleransi angka; eksperimen dinilai dari metrik hasil pelatihan nyata.

## 5. Skema database (Room, `academy.db`, versi 1)

| Tabel | Kolom | Fungsi |
|---|---|---|
| `lesson_progress` | `lessonId` PK, `attempts`, `bestScore`, `lastScore`, `lastAttemptAt` | lulus/terbuka |
| `concept_mastery` | `conceptId` PK, `value`, `evidence`, `lastDay` | penguasaan dan peluruhan |
| `assessment_attempt` | `id` PK auto, `lessonId` (indeks), `score`, `passed`, `createdAt`, `detail` (JSON skor per konsep) | riwayat asesmen |
| `experiment_run` | `id` PK auto, `kind`, `config`, `result`, `createdAt` | riwayat eksperimen |
| `daily_activity` | `day` PK (epoch day), `questions`, `lessons` | runtun belajar |

DataStore (`settings`): `battery_saver` (Boolean). Tabel progres proyek praktik akan ditambahkan di Fase 4 (belum ada, tidak dipalsukan).

## 6. Navigasi

Bar bawah: Beranda (`home`), Neural Network (`nn`), NLP (`nlp`), Lab (`labs`), Progres (`progress`). Pintasan di judul layar: Code Playground (`playground`) dan Pengaturan (`settings`). Layar pelajaran `lesson/{id}` menyembunyikan bar bawah. Tujuh tujuan sesuai spesifikasi tercakup; bar bawah dibatasi lima item sesuai pedoman Material.

## 7. Kompatibilitas dan performa Android

- minSdk 26, targetSdk/compileSdk 34. Tanpa izin khusus, tanpa internet.
- Tidak ada model ML besar. Pelatihan lab berjalan di `Dispatchers.Default`, bisa dihentikan, dengan batas epoch (500; hemat baterai 150) dan dataset ≤ 300 titik. Batas keputusan 36×36 (hemat baterai 20×20).
- Aset pelajaran dimuat per pelajaran dan disimpan di memori; kurikulum penuh hanya metadata.
- Tanda tangan APK memakai kunci tetap (`app/nara.keystore`) agar pembaruan menimpa instalasi lama dan progres tidak hilang. Kunci dan kata sandinya ada di repositori: cukup untuk aplikasi pribadi, jangan untuk rilis publik.

## 8. Pengujian dan verifikasi

Sudah dijalankan di lingkungan pengembangan ini:
- **Engine (50 uji JUnit-gaya, dijalankan dengan pelari lokal karena JUnit asli tidak bisa diunduh di sini)**: cek gradien analitik vs numerik (3 kombinasi aktivasi/loss), turunan aktivasi, XOR dipelajari dengan 8 neuron pada 10 seed, lebar 8 lebih andal daripada lebar 2 (diukur 20 seed), semua optimizer konvergen, lingkaran butuh lapisan tersembunyi, determinisme seed; stemmer/BPE/TF-IDF/BoW/Naive Bayes/identifikasi bahasa/pencarian; graf prasyarat, penguasaan, pembukaan, rekomendasi (lanjut/remediasi/ulangan), runtun; penilaian semua jenis soal, sesi ujian, pemilihan adaptif.
- **Uji aset (`LessonDataTest`)**: membaca JSON kurikulum asli; setiap soal menerima jawaban benarnya dan menolak jawaban salah; contoh jawaban konsep lolos rubrik.
- **Python**: `verify_lessons.py` menjalankan semua cuplikan kode pelajaran dengan NumPy dan mencocokkan keluarannya; `check_schema.py` memeriksa kontrak data.

Belum dijalankan (tidak ada Kotlin/Gradle/Android di lingkungan ini): kompilasi `app`, uji `CurriculumJsonTest`, KSP Room, build APK, dan seluruh UI. Workflow CI menjalankan semuanya.

Temuan yang mengubah desain: XOR dengan 3–4 neuron gagal pada sebagian seed (minimum lokal), sehingga uji dan pelajaran memakai 8 neuron; klasifikasi sentimen Inggris pada data kecil naik dari 0,70 ke 0,80 bila stopword dibuang, tetapi untuk bahasa Indonesia stopword tidak dibuang karena daftar memuat "tidak" yang membalik makna.

## 9. Peta jalan

- **Fase 2**: 5–6 pelajaran berikutnya per jalur (nn-04..08, nlp-04..07), ujian topik, animasi ringan, diagram teknis.
- **Fase 3**: eksekusi Python nyata terisolasi (opsi: Chaquopy dengan NumPy; proses terpisah dengan batas waktu/memori) — hanya diaktifkan setelah diuji; sampai saat itu Playground tetap berlabel demonstrasi.
- **Fase 4**: proyek praktik (tabel progres), eksperimen on-device ONNX Runtime Mobile/LiteRT dengan model kecil, contoh PyTorch/Hugging Face sebagai kode.
- **Fase 5**: pelajaran lanjutan (CNN, RNN, attention, Transformer, BERT/GPT), pencarian semantik dan chatbot.
