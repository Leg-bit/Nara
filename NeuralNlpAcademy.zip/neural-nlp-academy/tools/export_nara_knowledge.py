#!/usr/bin/env python3
"""Mengekspor pengetahuan pelajaran Academy menjadi bank pasangan 'pertanyaan => jawaban' untuk pencari balasan Nara.
Jalankan: python tools/export_nara_knowledge.py [berkas_keluaran]   (bawaan: nara-knowledge/knowledge.txt)
Lalu salin berkas itu ke app/src/main/assets/knowledge.txt pada proyek NaraCompanion dan bangun ulang Nara."""
import glob, json, os, re, sys

ROOT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "curriculum", "lessons")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "nara-knowledge", "knowledge.txt")
CONTEXT_BOUND = re.compile(r"tab Implementasi|kode di|kode pada|di atas|berikut|visualisasi|Laboratorium|asesmen|eksperimen", re.I)

def clean(s):            # pemisah format seed tidak boleh muncul di dalam teks
    return re.sub(r"\s+", " ", s.replace(";", ",").replace("=>", "->")).strip()

def shorten(text, limit=220):
    out = ""
    for sent in re.split(r"(?<=[.!?])\s+", clean(text)):
        if out and len(out) + len(sent) + 1 > limit: break
        out = (out + " " + sent).strip()
        if len(out) >= limit: break
    return out[:limit]

def main():
    rules, seen = [], set()
    def add(prompts, reply):
        ps = [clean(p).rstrip("?.! ") for p in prompts if p and not CONTEXT_BOUND.search(p)]
        ps = [p for p in ps if 4 <= len(p) <= 140 and p.lower() not in seen]
        reply = shorten(reply)
        if ps and len(reply) >= 12:
            seen.update(p.lower() for p in ps); rules.append((ps, reply))
    for path in sorted(glob.glob(os.path.join(ROOT, "*.json"))):
        L = json.load(open(path, encoding="utf-8")); t = L["title"].lower()
        add([f"apa itu {t}", f"jelaskan {t}", f"ceritakan tentang {t}", f"{t} itu apa"], L["concept"] + " " + (L["explanation"][0] if L["explanation"] else ""))
        for g in L.get("glossary", []):
            ts = g["terms"]
            add([p for t in ts for p in (f"apa itu {t}", f"jelaskan {t}", f"{t} itu apa", f"apa arti {t}")], g["definition"])
        for q in L["questions"]:
            if q["type"] == "MCQ": add([q["prompt"]], q["choices"][q["correct"]] + ". " + q["explanation"])
            # soal hitungan (NUMERIC) sengaja tidak diekspor: jawabannya penyelesaian untuk angka tertentu, bukan pengetahuan umum
            elif q["type"] == "SHORT_CONCEPT": add([q["prompt"]], q.get("modelAnswer", q["explanation"]))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        for ps, r in rules: f.write("; ".join(ps) + " => " + r + "\n")
    print(f"{len(rules)} aturan pengetahuan -> {OUT}")

if __name__ == "__main__":
    main()
