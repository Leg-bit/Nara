#!/usr/bin/env python3
"""Membangun aset kurikulum (JSON) dari satu sumber. Jalankan: python tools/gen_curriculum.py  (keluaran: app/src/main/assets/curriculum/).
Semua cuplikan kode dalam pelajaran diverifikasi oleh tools/verify_lessons.py (dijalankan sungguhan, keluaran dibandingkan)."""
import json, os, sys

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "curriculum")

# (id, judul, kesulitan, prasyarat, konsep, ditulis?)
NN = [
 ("nn-01", "Fondasi matematika", 1, [], ["vector", "dot_product", "matrix_multiply", "derivative"], True),
 ("nn-02", "Dasar machine learning", 1, ["nn-01"], ["dataset", "generalization", "overfitting", "metrics"], True),
 ("nn-03", "Neuron buatan", 1, ["nn-01"], ["neuron", "weights_bias", "activation_intro"], True),
 ("nn-04", "Perceptron", 2, ["nn-03"], ["perceptron", "linear_separability"], False),
 ("nn-05", "Forward propagation", 2, ["nn-03"], ["forward_pass", "layers"], False),
 ("nn-06", "Fungsi aktivasi", 2, ["nn-05"], ["sigmoid", "tanh", "relu"], False),
 ("nn-07", "Fungsi loss", 2, ["nn-02", "nn-05"], ["mse", "cross_entropy"], False),
 ("nn-08", "Backpropagation", 3, ["nn-01", "nn-06", "nn-07"], ["chain_rule", "backprop"], False),
 ("nn-09", "Gradient descent", 3, ["nn-08"], ["gradient_descent", "learning_rate"], False),
 ("nn-10", "Optimizer", 3, ["nn-09"], ["momentum", "adam"], False),
 ("nn-11", "Jaringan multi-lapis", 3, ["nn-10"], ["mlp", "capacity"], False),
 ("nn-12", "CNN", 4, ["nn-11"], ["convolution", "pooling"], False),
 ("nn-13", "RNN", 4, ["nn-11"], ["recurrence", "bptt"], False),
 ("nn-14", "LSTM dan GRU", 4, ["nn-13"], ["gates", "long_memory"], False),
 ("nn-15", "Mekanisme attention", 4, ["nn-14"], ["attention"], False),
 ("nn-16", "Transformer", 5, ["nn-15"], ["transformer", "positional_encoding"], False),
 ("nn-17", "Pelatihan dan optimasi model", 4, ["nn-11"], ["regularization", "batch_norm"], False),
 ("nn-18", "Evaluasi model", 3, ["nn-02", "nn-11"], ["cross_validation", "confusion_matrix"], False),
]
NLP = [
 ("nlp-01", "Dasar linguistik", 1, [], ["morphology", "syntax", "semantics", "zipf"], True),
 ("nlp-02", "Pra-pemrosesan teks", 1, ["nlp-01"], ["normalization", "stopwords", "slang"], True),
 ("nlp-03", "Tokenisasi", 1, ["nlp-02"], ["word_tokens", "char_tokens", "subword_bpe"], True),
 ("nlp-04", "Stemming dan lematisasi", 2, ["nlp-03"], ["stemming", "lemmatization"], False),
 ("nlp-05", "Bag of Words", 2, ["nlp-03"], ["bow"], False),
 ("nlp-06", "TF-IDF", 2, ["nlp-05"], ["tf", "idf"], False),
 ("nlp-07", "Word embeddings", 3, ["nlp-06", "nn-03"], ["embedding"], False),
 ("nlp-08", "Word2Vec", 3, ["nlp-07"], ["skipgram", "cbow"], False),
 ("nlp-09", "Identifikasi bahasa", 2, ["nlp-03"], ["char_ngrams", "langid"], False),
 ("nlp-10", "Klasifikasi teks", 2, ["nlp-06"], ["naive_bayes", "classification"], False),
 ("nlp-11", "Analisis sentimen", 3, ["nlp-10"], ["sentiment"], False),
 ("nlp-12", "Named Entity Recognition", 3, ["nlp-10"], ["ner", "sequence_labeling"], False),
 ("nlp-13", "NLP berbasis RNN", 4, ["nlp-08", "nn-13"], ["rnn_nlp"], False),
 ("nlp-14", "LSTM dan GRU untuk NLP", 4, ["nlp-13", "nn-14"], ["lstm_nlp"], False),
 ("nlp-15", "Attention untuk NLP", 4, ["nlp-14", "nn-15"], ["attention_nlp"], False),
 ("nlp-16", "Transformer untuk NLP", 5, ["nlp-15", "nn-16"], ["transformer_nlp"], False),
 ("nlp-17", "Dasar BERT dan GPT", 5, ["nlp-16"], ["bert", "gpt"], False),
 ("nlp-18", "Pencarian semantik", 4, ["nlp-08", "nlp-06"], ["semantic_search"], False),
 ("nlp-19", "Pemodelan bahasa", 4, ["nlp-13"], ["language_model", "perplexity"], False),
 ("nlp-20", "Pengembangan chatbot", 5, ["nlp-18", "nlp-19", "nlp-10"], ["retrieval_chatbot", "intent"], False),
]

def mcq(id, prompt, concepts, diff, choices, correct, expl):
    return {"id": id, "type": "MCQ", "prompt": prompt, "concepts": concepts, "difficulty": diff, "choices": choices, "correct": correct, "explanation": expl}
def num(id, prompt, concepts, diff, answer, tol, expl):
    return {"id": id, "type": "NUMERIC", "prompt": prompt, "concepts": concepts, "difficulty": diff, "answer": answer, "tolerance": tol, "explanation": expl}
def concept(id, prompt, concepts, diff, rubric, expl):
    return {"id": id, "type": "SHORT_CONCEPT", "prompt": prompt, "concepts": concepts, "difficulty": diff, "rubric": rubric, "explanation": expl}
def code(id, prompt, concepts, diff, expected, expl):
    return {"id": id, "type": "CODE_OUTPUT", "prompt": prompt, "concepts": concepts, "difficulty": diff, "expected": expected, "explanation": expl}
def exp(id, prompt, concepts, diff, metric, target, expl):
    return {"id": id, "type": "EXPERIMENT", "prompt": prompt, "concepts": concepts, "difficulty": diff, "metric": metric, "target": target, "explanation": expl}

LESSONS = {}

# Glosarium per pelajaran: definisi singkat yang akurat. Dipakai untuk pengetahuan Nara (export_nara_knowledge.py) dan kelak layar Glosarium.
GLOSSARY = {
 "nn-01": [
  (["dot product", "perkalian titik"], "Dot product dua vektor adalah jumlah hasil kali elemen yang berpasangan: a·b = Σ aᵢbᵢ. Hasilnya besar jika kedua vektor searah dan nol jika tegak lurus."),
  (["vektor"], "Vektor adalah daftar angka berurutan, misalnya fitur sebuah data seperti tinggi, berat, dan umur."),
  (["turunan", "derivatif"], "Turunan mengukur seberapa cepat keluaran fungsi berubah jika masukan digeser sedikit. Dalam pelatihan, turunan loss terhadap bobot menunjukkan arah yang menurunkan kesalahan."),
  (["perkalian matriks", "matriks kali vektor"], "Perkalian matriks dengan vektor adalah banyak dot product sekaligus: tiap baris matriks dikalikan dengan vektor. Satu lapisan jaringan saraf melakukan ini.")],
 "nn-02": [
  (["akurasi"], "Akurasi adalah jumlah prediksi yang benar dibagi jumlah seluruh data."),
  (["presisi", "precision"], "Presisi = TP / (TP + FP): dari semua data yang diprediksi positif, berapa yang benar-benar positif."),
  (["recall", "sensitivitas"], "Recall = TP / (TP + FN): dari semua data yang sebenarnya positif, berapa yang berhasil tertangkap model."),
  (["underfitting"], "Underfitting terjadi ketika model terlalu sederhana sehingga akurasi latih dan akurasi ujinya sama-sama rendah."),
  (["generalisasi"], "Generalisasi adalah kemampuan model bekerja baik pada data baru yang belum pernah dilihat, bukan hanya pada data latih."),
  (["fitur"], "Fitur adalah masukan yang menggambarkan sebuah data, sedangkan label adalah jawaban benar yang ingin diprediksi model.")],
 "nn-03": [
  (["bias"], "Bias adalah suku konstan pada neuron yang menggeser ambang aktivasi sehingga neuron bisa aktif walau semua masukan nol."),
  (["fungsi aktivasi", "aktivasi"], "Fungsi aktivasi mengubah jumlah berbobot z menjadi keluaran neuron. Aktivasi non-linear seperti sigmoid, tanh, dan ReLU membuat jaringan bisa mempelajari pola melengkung."),
  (["sigmoid"], "Sigmoid σ(z) = 1/(1+e^(−z)) membatasi keluaran ke antara 0 dan 1, dengan σ(0) = 0,5."),
  (["tanh"], "Tanh membatasi keluaran ke antara −1 dan 1 dan bernilai 0 saat masukannya 0."),
  (["bobot", "weight"], "Bobot menyatakan seberapa penting sebuah masukan bagi neuron; nilai bobot inilah yang dipelajari saat pelatihan.")],
 "nlp-01": [
  (["hukum zipf", "zipf"], "Hukum Zipf menyatakan frekuensi sebuah kata kira-kira berbanding terbalik dengan peringkatnya: f(r) ≈ C/r. Sedikit kata sangat sering muncul, banyak kata jarang."),
  (["morfologi"], "Morfologi mempelajari pembentukan kata, misalnya imbuhan: 'membuatkan' berakar pada 'buat'."),
  (["sintaksis"], "Sintaksis mempelajari urutan kata dalam kalimat, misalnya 'rumah besar' dalam bahasa Indonesia dan 'big house' dalam bahasa Inggris."),
  (["semantik"], "Semantik mempelajari makna kata dan kalimat, termasuk ambiguitas."),
  (["ambiguitas", "ambigu"], "Ambiguitas adalah ketika satu bentuk kata atau kalimat bermakna lebih dari satu, misalnya 'bisa' (dapat atau racun ular); konteks yang menentukan artinya.")],
 "nlp-02": [
  (["stopword", "kata henti"], "Stopword adalah kata yang sangat umum seperti 'yang' dan 'dan'. Membuangnya memfokuskan teks pada kata bermakna, tetapi membuang 'tidak' bisa membalik sentimen."),
  (["normalisasi teks", "normalisasi"], "Normalisasi teks menyeragamkan variasi seperti huruf besar-kecil, tanda baca, dan singkatan gaul agar kata yang sama dikenali sebagai satu kata."),
  (["singkatan gaul", "bahasa gaul"], "Singkatan gaul seperti 'gak' dan 'bgt' dibakukan menjadi 'tidak' dan 'banget' supaya komputer tidak menganggapnya kata yang berbeda.")],
 "nlp-03": [
  (["tokenisasi", "token"], "Tokenisasi memecah teks menjadi unit yang diproses model: kata, huruf, atau potongan kata (subkata)."),
  (["oov", "out of vocabulary"], "OOV (out-of-vocabulary) adalah kata yang tidak ada dalam kosakata model sehingga tidak dikenali; masalah utama token kata."),
  (["bpe", "byte pair encoding"], "BPE memulai dari huruf lalu berulang kali menggabungkan pasangan simbol yang paling sering muncul bersebelahan, sehingga kata sering menjadi satu token dan kata langka dipecah."),
  (["subkata", "subword"], "Subkata adalah potongan kata yang dipakai sebagai token, sehingga kata baru bisa disusun dari potongan yang sudah dikenal dan OOV hampir hilang.")],
}

# Contoh jawaban untuk soal konsep: dipakai uji otomatis (LessonDataTest) agar rubrik dijamin bisa dipenuhi jawaban wajar.
MODEL = {
 "nn-01-q5": "Turunan memberi tahu arah perubahan, yaitu kemiringan loss terhadap setiap bobot, sehingga bobot bisa digeser ke arah yang menurunkan kesalahan.",
 "nn-02-q4": "Overfitting terjadi ketika model menghafal data latih termasuk noise sehingga gagal pada data baru.",
 "nn-03-q5": "Neuron mengalikan setiap masukan dengan bobot, menjumlahkannya, menambah bias, lalu hasilnya dilewatkan fungsi aktivasi.",
 "nlp-01-q3": "Ambiguitas membuat satu kata punya makna ganda, misalnya bisa, dan hanya konteks yang membedakan artinya.",
 "nlp-02-q3": "Singkatan seperti gak dan tidak punya arti yang sama, tetapi dianggap kata berbeda oleh komputer, jadi harus dibakukan.",
 "nlp-03-q3": "Subkata memecah kata baru yang tidak dikenal menjadi potongan yang sudah ada di kosakata, sehingga OOV hampir hilang.",
}

LESSONS["nn-01"] = {
 "concept": "Jaringan saraf pada dasarnya adalah rangkaian operasi aljabar linear (perkalian vektor dan matriks) ditambah turunan untuk belajar.",
 "explanation": [
  "Vektor adalah daftar angka, misalnya fitur sebuah data: [tinggi, berat, umur]. Dot product dua vektor menjumlahkan hasil kali elemen yang berpasangan; hasilnya besar kalau keduanya 'searah'.",
  "Perkalian matriks dengan vektor adalah banyak dot product sekaligus: tiap baris matriks dikalikan dengan vektor. Satu lapisan jaringan saraf melakukan persis ini.",
  "Turunan mengukur seberapa cepat keluaran fungsi berubah jika masukan digeser sedikit. Saat melatih jaringan, turunan loss terhadap setiap bobot memberi tahu arah mana yang menurunkan kesalahan."],
 "math": ["a · b = Σᵢ aᵢ bᵢ", "(W x)ⱼ = Σᵢ Wⱼᵢ xᵢ     (W berukuran m×n, x berukuran n → hasil berukuran m)", "f'(x) = lim_{h→0} (f(x+h) − f(x)) / h", "Contoh: f(x) = x²  →  f'(x) = 2x, jadi f'(3) = 6"],
 "visualization": {"type": "dot_product", "title": "Geser dua vektor 2D dan lihat dot product serta sudutnya"},
 "implementation": {"language": "python", "steps": ["np.dot menghitung dot product.", "W @ a mengalikan matriks dengan vektor.", "Turunan numerik: selisih kecil dibagi h."],
  "code": "import numpy as np\na = np.array([1.0, 2.0, 3.0])\nb = np.array([4.0, -1.0, 2.0])\nprint(np.dot(a, b))\nW = np.array([[1.0, 0.0, 2.0], [0.0, 1.0, -1.0]])\nprint(W @ a)\nh = 1e-5\nf = lambda x: x**2\nprint(round((f(3 + h) - f(3)) / h, 3))"},
 "experiment": {"kind": "none", "instruction": "Gunakan visualisasi: buat dua vektor yang tegak lurus (dot product 0) lalu dua vektor searah (dot product maksimum)."},
 "exercises": ["Hitung dot product [2, 3, −1] · [1, 0, 4] dengan tangan, lalu cek dengan np.dot.", "Matriks 3×2 dikalikan vektor berukuran 2: berapa ukuran hasilnya?", "Perkirakan turunan f(x)=x³ di x=2 dengan selisih kecil."],
 "questions": [
  mcq("nn-01-q1", "Apa yang dihitung dot product dua vektor?", ["dot_product"], 1, ["Jumlah hasil kali elemen yang berpasangan", "Selisih kedua vektor", "Panjang vektor terpanjang", "Perkalian setiap elemen tanpa dijumlahkan"], 0, "Dot product = Σ aᵢbᵢ."),
  num("nn-01-q2", "Hitung dot product [2, 3] · [4, −1].", ["dot_product"], 1, 5.0, 0.01, "2·4 + 3·(−1) = 8 − 3 = 5."),
  num("nn-01-q3", "Berapa turunan f(x) = x² di x = 5?", ["derivative"], 2, 10.0, 0.01, "f'(x) = 2x, jadi f'(5) = 10."),
  mcq("nn-01-q4", "Matriks W berukuran 2×3 dikalikan vektor x berukuran 3. Berapa ukuran hasilnya?", ["matrix_multiply"], 2, ["3", "2", "2×3", "6"], 1, "Tiap dari 2 baris W menghasilkan satu angka, jadi hasilnya vektor berukuran 2."),
  concept("nn-01-q5", "Mengapa turunan penting saat melatih jaringan saraf?", ["derivative"], 3, [["arah", "kemiringan", "slope", "naik", "turun", "perubahan"], ["bobot", "parameter", "weight"], ["loss", "galat", "error", "kesalahan"]], "Turunan loss terhadap bobot menunjukkan ke arah mana bobot diubah agar loss mengecil."),
  code("nn-01-q6", "Apa keluaran baris pertama kode di tab Implementasi (print(np.dot(a, b)))? Tulis angkanya.", ["dot_product"], 1, "8.0", "1·4 + 2·(−1) + 3·2 = 4 − 2 + 6 = 8."),
 ]}

LESSONS["nn-02"] = {
 "concept": "Machine learning membangun model dari data. Tujuan sebenarnya adalah menggeneralisasi: bekerja baik pada data yang belum pernah dilihat.",
 "explanation": [
  "Data terdiri dari fitur (masukan) dan label (jawaban yang benar). Model belajar hubungan fitur ke label dari data latih.",
  "Kita selalu menguji pada data uji yang disisihkan. Skor di data latih saja menipu: model bisa sekadar menghafal.",
  "Overfitting: akurasi latih tinggi, akurasi uji rendah (model menghafal noise). Underfitting: model terlalu sederhana, akurasi latih dan uji sama-sama rendah.",
  "Akurasi saja kadang tidak cukup. Presisi = dari semua yang diprediksi positif, berapa yang benar. Recall = dari semua yang sebenarnya positif, berapa yang tertangkap."],
 "math": ["akurasi = jumlah benar / jumlah data", "presisi = TP / (TP + FP)", "recall = TP / (TP + FN)", "loss rata-rata = (1/n) Σ ℓ(ŷᵢ, yᵢ)"],
 "visualization": {"type": "dataset_scatter", "title": "Lihat dataset: mana yang bisa dipisah garis lurus?"},
 "implementation": {"language": "python", "steps": ["Akurasi = rata-rata kecocokan.", "TP: prediksi 1 dan benar 1.", "Presisi dan recall memakai penyebut berbeda."],
  "code": "import numpy as np\ny_true = np.array([1, 0, 1, 1, 0, 0, 1, 0])\ny_pred = np.array([1, 0, 0, 1, 1, 1, 1, 0])\nprint((y_true == y_pred).mean())\ntp = ((y_pred == 1) & (y_true == 1)).sum()\nprint(tp / (y_pred == 1).sum())\nprint(tp / (y_true == 1).sum())"},
 "experiment": {"kind": "nn", "preset": {"dataset": "circles", "hidden": [8], "activation": "TANH", "lr": 0.03, "epochs": 250, "optimizer": "ADAM"}, "instruction": "Latih jaringan [2,1] (tanpa lapisan tersembunyi) lalu [2,8,1] pada dataset Circles. Bandingkan akurasi UJI keduanya."},
 "exercises": ["Dari 10 prediksi, 7 benar. Berapa akurasinya?", "Mengapa kita tidak boleh melaporkan akurasi data latih sebagai hasil akhir?", "Sebutkan satu contoh kasus yang recall-nya lebih penting daripada presisi."],
 "questions": [
  mcq("nn-02-q1", "Untuk apa data uji dipisahkan dari data latih?", ["generalization"], 1, ["Mengukur kinerja pada data yang belum pernah dilihat model", "Supaya pelatihan lebih cepat", "Menambah jumlah data latih", "Mengurangi jumlah fitur"], 0, "Data uji mensimulasikan data baru di dunia nyata."),
  num("nn-02-q2", "Model benar pada 7 dari 10 data. Berapa akurasinya (0–1)?", ["metrics"], 1, 0.7, 0.01, "7/10 = 0,7."),
  mcq("nn-02-q3", "Akurasi latih 99% tetapi akurasi uji 62%. Apa kemungkinan penyebabnya?", ["overfitting"], 2, ["Overfitting", "Underfitting", "Data uji terlalu mudah", "Learning rate terlalu kecil"], 0, "Jarak besar antara skor latih dan uji adalah tanda khas overfitting."),
  concept("nn-02-q4", "Jelaskan apa itu overfitting.", ["overfitting"], 3, [["menghafal", "hafal", "memorisasi", "memorize", "terlalu cocok"], ["data latih", "training", "pelatihan"], ["data baru", "data uji", "test", "tidak terlihat", "unseen", "generalisasi"]], "Overfitting: model terlalu menyesuaikan diri dengan data latih (termasuk noise) sehingga gagal pada data baru."),
  num("nn-02-q5", "Model memprediksi 4 data sebagai positif; 3 di antaranya benar-benar positif. Berapa presisinya?", ["metrics"], 2, 0.75, 0.01, "Presisi = TP/(TP+FP) = 3/4."),
  code("nn-02-q6", "Jalankan kode di tab Implementasi. Tulis tiga baris keluarannya (akurasi, presisi, recall) dipisah baris baru.", ["metrics"], 3, "0.625\n0.6\n0.75", "Benar 5 dari 8 → 0,625. TP=3, prediksi positif=5 → 0,6. Positif sebenarnya=4 → 0,75."),
  exp("nn-02-q7", "Di Laboratorium Jaringan Saraf, latih pada dataset Circles dan capai akurasi uji ≥ 0,9. Kirim akurasi ujinya.", ["generalization", "overfitting"], 3, "akurasi uji", 0.9, "Lingkaran tidak bisa dipisah garis lurus; lapisan tersembunyi membuat batas keputusan melengkung."),
 ]}

LESSONS["nn-03"] = {
 "concept": "Neuron buatan menghitung jumlah berbobot masukannya ditambah bias, lalu melewatkannya ke fungsi aktivasi.",
 "explanation": [
  "Neuron menerima beberapa masukan x₁…xₙ. Setiap masukan punya bobot w yang menyatakan seberapa penting masukan itu. Neuron menjumlahkan wᵢxᵢ lalu menambahkan bias b.",
  "Bias menggeser ambang: tanpa bias, neuron selalu memberi nol saat semua masukan nol.",
  "Hasil jumlah z lalu dilewatkan fungsi aktivasi f. Aktivasi non-linear (sigmoid, tanh, ReLU) membuat tumpukan neuron bisa mempelajari pola melengkung; tanpa itu seluruh jaringan hanya setara satu transformasi linear."],
 "math": ["z = Σᵢ wᵢ xᵢ + b = w · x + b", "a = f(z)", "sigmoid: σ(z) = 1 / (1 + e^(−z)),  σ(0) = 0,5", "tanh(z) = (e^z − e^(−z)) / (e^z + e^(−z)),  tanh(0) = 0"],
 "visualization": {"type": "neuron", "title": "Atur bobot, bias, dan masukan; lihat z dan keluaran neuron"},
 "implementation": {"language": "python", "steps": ["z = w·x + b.", "sigmoid membatasi keluaran ke (0, 1).", "tanh membatasi ke (−1, 1)."],
  "code": "import numpy as np\ndef sigmoid(z): return 1 / (1 + np.exp(-z))\nx = np.array([0.5, -1.0])\nw = np.array([0.8, 0.2])\nb = 0.1\nz = np.dot(w, x) + b\nprint(round(z, 3))\nprint(round(sigmoid(z), 4))\nprint(round(np.tanh(z), 4))"},
 "experiment": {"kind": "nn", "preset": {"dataset": "and", "hidden": [], "activation": "TANH", "lr": 0.1, "epochs": 300, "optimizer": "ADAM"}, "instruction": "Latih satu neuron (jaringan [2,1]) pada dataset AND. Perhatikan nilai bobot dan bias yang dipelajari."},
 "exercises": ["Hitung z untuk x=[1,2], w=[0,5; −1], b=0,5.", "Mengapa dua lapisan linear tanpa aktivasi non-linear tidak lebih kuat daripada satu lapisan?", "Ubah bias pada visualisasi: apa yang terjadi pada titik keputusan?"],
 "questions": [
  num("nn-03-q1", "Hitung z untuk x = [0,5; −1], w = [0,8; 0,2], b = 0,1.", ["neuron"], 1, 0.3, 0.01, "z = 0,8·0,5 + 0,2·(−1) + 0,1 = 0,4 − 0,2 + 0,1 = 0,3."),
  num("nn-03-q2", "Berapa nilai sigmoid(0)?", ["activation_intro"], 1, 0.5, 0.01, "σ(0) = 1/(1+e⁰) = 1/2."),
  mcq("nn-03-q3", "Apa fungsi bias pada neuron?", ["weights_bias"], 2, ["Menggeser ambang aktivasi sehingga neuron bisa aktif walau masukan nol", "Menggandakan semua bobot", "Menghapus masukan yang kecil", "Menentukan jumlah neuron"], 0, "Bias adalah suku konstan yang menggeser z."),
  mcq("nn-03-q4", "Mengapa fungsi aktivasi non-linear diperlukan?", ["activation_intro"], 3, ["Tanpa itu, tumpukan lapisan hanya setara satu transformasi linear", "Agar jaringan lebih cepat dihitung", "Agar bobot tidak berubah", "Agar jumlah parameter berkurang"], 0, "Komposisi fungsi linear tetap linear."),
  concept("nn-03-q5", "Jelaskan cara kerja satu neuron buatan.", ["neuron", "weights_bias"], 3, [["bobot", "weight"], ["jumlah", "dot", "dijumlahkan", "penjumlahan", "kombinasi"], ["bias"], ["aktivasi", "activation"]], "Neuron menghitung z = w·x + b lalu keluarannya f(z)."),
  code("nn-03-q6", "Jalankan kode di tab Implementasi. Tulis tiga baris keluarannya.", ["neuron", "activation_intro"], 2, "0.3\n0.5744\n0.2913", "z = 0,3; σ(0,3) ≈ 0,5744; tanh(0,3) ≈ 0,2913."),
  exp("nn-03-q7", "Di Laboratorium Jaringan Saraf, latih satu neuron ([2,1]) pada dataset AND sampai akurasi 1,0. Kirim akurasinya.", ["neuron", "weights_bias"], 2, "akurasi", 1.0, "AND dapat dipisah garis lurus sehingga satu neuron cukup."),
 ]}

LESSONS["nlp-01"] = {
 "concept": "Bahasa punya lapisan struktur: bentuk kata (morfologi), susunan kalimat (sintaksis), makna (semantik). NLP harus menghadapi ketiganya.",
 "explanation": [
  "Morfologi: cara kata dibentuk. Bahasa Indonesia banyak memakai imbuhan (me-, ber-, -kan, -an) dan pengulangan (buku-buku): 'membuatkan' berakar pada 'buat'.",
  "Sintaksis: urutan kata. Bahasa Inggris 'big house' menaruh sifat sebelum benda; bahasa Indonesia 'rumah besar' sesudahnya. Bahasa Indonesia tidak mengubah bentuk kata untuk kala (tense).",
  "Semantik: makna, termasuk ambiguitas. 'Bisa' berarti 'dapat' atau 'racun ular'; konteks yang menentukan.",
  "Statistik bahasa: hukum Zipf menyatakan frekuensi kata kira-kira berbanding terbalik dengan peringkatnya, jadi sedikit kata sangat sering muncul dan sangat banyak kata jarang."],
 "math": ["Zipf: f(r) ≈ C / r   (f = frekuensi, r = peringkat kata)", "Contoh: jika kata peringkat 1 muncul 1000 kali, peringkat 2 ≈ 500 kali, peringkat 4 ≈ 250 kali"],
 "visualization": {"type": "lang_id", "title": "Ketik kalimat dan lihat peluang bahasa (Indonesia atau Inggris)"},
 "implementation": {"language": "python", "steps": ["Counter menghitung frekuensi kata.", "most_common(2) mengambil dua kata teratas."],
  "code": "from collections import Counter\ntext = \"saya makan nasi saya minum teh saya suka teh\"\nc = Counter(text.split())\nprint(c.most_common(2))"},
 "experiment": {"kind": "nlp", "preset": {"tab": "langid"}, "instruction": "Di Laboratorium NLP tab Identifikasi Bahasa, coba kalimat campuran Indonesia–Inggris dan perhatikan perubahan peluangnya."},
 "exercises": ["Tentukan akar kata dari 'pembelajaran', 'dimakan', 'berlarian'.", "Beri satu contoh kalimat ambigu dalam bahasa Indonesia.", "Hitung frekuensi kata pada paragraf pendek buatanmu; apakah mengikuti pola Zipf?"],
 "questions": [
  mcq("nlp-01-q1", "Manakah contoh morfologi?", ["morphology"], 1, ["'membuatkan' dibentuk dari akar 'buat' dengan imbuhan", "Urutan subjek-predikat-objek", "Arti ganda kata 'bisa'", "Jumlah kata dalam kalimat"], 0, "Morfologi mempelajari pembentukan kata."),
  mcq("nlp-01-q2", "Perbedaan urutan kata 'big house' dan 'rumah besar' termasuk aspek apa?", ["syntax"], 2, ["Sintaksis", "Morfologi", "Fonologi", "Statistik Zipf"], 0, "Urutan kata dalam frasa adalah sintaksis."),
  concept("nlp-01-q3", "Mengapa ambiguitas menyulitkan komputer memahami teks? Beri contoh.", ["semantics"], 3, [["konteks", "context"], ["makna", "arti", "ganda", "ambigu", "dua"], ["bisa", "bank", "contoh"]], "Satu bentuk kata dapat bermakna banyak; hanya konteks yang membedakan."),
  num("nlp-01-q4", "Menurut hukum Zipf, jika kata peringkat 1 muncul 1000 kali, kira-kira berapa kali kata peringkat 4 muncul?", ["zipf"], 3, 250.0, 0.05, "f(4) ≈ 1000/4 = 250."),
  code("nlp-01-q5", "Apa keluaran kode di tab Implementasi? Tulis persis.", ["zipf"], 2, "[('saya', 3), ('teh', 2)]", "'saya' muncul 3 kali, 'teh' 2 kali."),
  mcq("nlp-01-q6", "Apa ciri bahasa Indonesia terkait kala (tense)?", ["morphology"], 2, ["Kata kerja tidak berubah bentuk untuk kala", "Selalu memakai akhiran -ed", "Memakai artikel 'the'", "Urutan kata bebas total"], 0, "Kala dinyatakan dengan keterangan waktu (kemarin, sudah), bukan perubahan bentuk kata."),
 ]}

LESSONS["nlp-02"] = {
 "concept": "Pra-pemrosesan mengubah teks mentah menjadi bentuk seragam. Tiap langkah menghilangkan variasi, tetapi juga bisa membuang informasi.",
 "explanation": [
  "Langkah umum: huruf kecil, buang tanda baca, bakukan singkatan gaul, buang stopword, stemming. Urutan penting: huruf kecil dulu agar 'BGT' dan 'bgt' dikenali sebagai kamus yang sama.",
  "Teks media sosial penuh singkatan (gak, bgt, yg). Tanpa dibakukan, komputer menganggap 'gak' dan 'tidak' dua kata berbeda.",
  "Stopword (kata sangat umum seperti 'yang', 'dan') bisa dibuang untuk memfokuskan kata bermakna. Hati-hati: membuang 'tidak' mengubah 'tidak suka' menjadi 'suka' dan membalik sentimen. Setiap langkah adalah pertukaran antara keseragaman dan kehilangan informasi."],
 "math": ["ukuran kosakata V = jumlah kata unik; pra-pemrosesan yang baik memperkecil V tanpa membuang makna", "Contoh: 'Gue gak suka BGT' → gue gak suka bgt → saya tidak suka banget"],
 "visualization": {"type": "norm_steps", "title": "Aktifkan langkah-langkah dan lihat teks berubah di tiap tahap"},
 "implementation": {"language": "python", "steps": ["Huruf kecil lalu hapus tanda baca dengan regex.", "Kamus mengganti singkatan per kata."],
  "code": "import re\ntext = \"Gue gak suka makanan ini, BGT!!\"\nt = text.lower()\nt = re.sub(r\"[^\\w\\s]\", \" \", t)\nt = re.sub(r\"\\s+\", \" \", t).strip()\nprint(t)\nslang = {\"gue\": \"saya\", \"gak\": \"tidak\", \"bgt\": \"banget\"}\nprint(\" \".join(slang.get(w, w) for w in t.split()))"},
 "experiment": {"kind": "nlp", "preset": {"tab": "normalize"}, "instruction": "Di Laboratorium NLP tab Normalisasi, bandingkan kalimat dengan dan tanpa pembuangan stopword. Cari kalimat yang maknanya berubah."},
 "exercises": ["Tulis dua singkatan gaul lain dan padanan bakunya.", "Beri contoh kalimat yang maknanya terbalik jika 'tidak' dibuang.", "Mengapa huruf kecil dilakukan sebelum penggantian kamus?"],
 "questions": [
  mcq("nlp-02-q1", "Mengapa teks diubah menjadi huruf kecil sebelum mencari di kamus singkatan?", ["normalization"], 1, ["Agar 'BGT' dan 'bgt' dianggap kata yang sama", "Agar teks menjadi lebih pendek", "Agar tanda baca hilang", "Agar stopword terhapus"], 0, "Kamus berisi bentuk huruf kecil; variasi huruf harus diseragamkan dulu."),
  mcq("nlp-02-q2", "Apa risiko membuang stopword 'tidak' pada analisis sentimen?", ["stopwords"], 2, ["Kalimat negatif dapat tampak positif", "Teks menjadi lebih panjang", "Kosakata membesar", "Tidak ada risiko"], 0, "'tidak suka' menjadi 'suka' sehingga sentimen terbalik."),
  concept("nlp-02-q3", "Mengapa singkatan gaul perlu dibakukan sebelum analisis?", ["slang"], 2, [["sama", "satu", "seragam", "baku", "padanan", "arti"], ["kata", "token", "kosakata", "berbeda", "terpisah"]], "Tanpa pembakuan, 'gak' dan 'tidak' dihitung sebagai dua kata berbeda sehingga statistik terpecah."),
  num("nlp-02-q4", "Kalimat 'saya tidak suka makanan ini banget' diproses: stopword saya, tidak, ini dibuang. Berapa kata tersisa?", ["stopwords"], 2, 3.0, 0.01, "Tersisa: suka, makanan, banget."),
  code("nlp-02-q5", "Tulis dua baris keluaran kode di tab Implementasi.", ["normalization", "slang"], 3, "gue gak suka makanan ini bgt\nsaya tidak suka makanan ini banget", "Baris pertama setelah huruf kecil dan tanpa tanda baca; baris kedua setelah kamus singkatan."),
  mcq("nlp-02-q6", "Urutan yang paling masuk akal?", ["normalization"], 3, ["huruf kecil → buang tanda baca → bakukan singkatan → buang stopword", "buang stopword → huruf kecil → bakukan singkatan", "bakukan singkatan → huruf kecil → buang tanda baca", "stemming → huruf kecil → buang stopword"], 0, "Penyeragaman dasar dulu, baru langkah yang bergantung pada bentuk kata."),
 ]}

LESSONS["nlp-03"] = {
 "concept": "Tokenisasi memecah teks menjadi unit yang diproses model: kata, huruf, atau potongan kata (subkata).",
 "explanation": [
  "Token kata sederhana dan mudah dibaca, tetapi kosakatanya besar dan kata baru (out-of-vocabulary, OOV) tidak dikenal.",
  "Token huruf tidak punya OOV, tetapi urutannya panjang dan tiap token nyaris tanpa makna.",
  "Subkata (mis. Byte-Pair Encoding) di tengah-tengah: mulai dari huruf, lalu berulang kali menggabungkan pasangan simbol yang paling sering muncul. Kata sering menjadi satu token, kata langka dipecah menjadi potongan yang dikenal sehingga OOV hampir hilang."],
 "math": ["BPE: pilih pasangan (a, b) dengan hitungan terbanyak di korpus, gabungkan menjadi simbol baru 'ab', ulangi M kali", "Ukuran kosakata akhir ≈ jumlah huruf unik + M"],
 "visualization": {"type": "tokenization", "title": "Bandingkan token kata, huruf, dan subkata (BPE) untuk teks yang kamu ketik"},
 "implementation": {"language": "python", "steps": ["split() memecah pada spasi.", "set() mengambil kata unik, sorted() mengurutkan."],
  "code": "text = \"Belajar NLP itu seru!\"\nwords = text.lower().replace(\"!\", \"\").split()\nprint(words)\nprint(len(text))\nprint(sorted(set(words)))"},
 "experiment": {"kind": "nlp", "preset": {"tab": "tokenize"}, "instruction": "Di Laboratorium NLP tab Tokenisasi, bandingkan jumlah token kata, huruf, dan subkata untuk kalimat yang sama, lalu coba kata yang tidak ada di korpus."},
 "exercises": ["Hitung jumlah token kata dan huruf untuk 'aku suka belajar'.", "Mengapa kata 'ketidakpastian' bisa menjadi masalah bagi tokenisasi kata?", "Latih BPE dengan 10 gabungan pada kalimat pilihanmu."],
 "questions": [
  mcq("nlp-03-q1", "Apa masalah utama token kata?", ["word_tokens"], 1, ["Kata baru yang tidak ada di kosakata (OOV) tidak dikenal", "Urutan token terlalu panjang", "Tidak bisa dibaca manusia", "Hanya bekerja untuk bahasa Inggris"], 0, "Kosakata tetap, jadi kata baru menjadi 'tidak dikenal'."),
  mcq("nlp-03-q2", "Apa yang digabung oleh BPE pada tiap langkah?", ["subword_bpe"], 2, ["Pasangan simbol yang paling sering muncul bersebelahan", "Dua kata acak", "Pasangan simbol paling jarang", "Seluruh kalimat"], 0, "BPE greedy: gabungkan pasangan paling sering."),
  concept("nlp-03-q3", "Apa keuntungan tokenisasi subkata dibanding token kata?", ["subword_bpe"], 3, [["kata baru", "oov", "out-of-vocabulary", "tidak dikenal", "langka"], ["subkata", "potongan", "bagian kata", "subword", "pecah", "dipecah"]], "Kata langka dipecah menjadi potongan yang dikenal, jadi OOV hampir tidak ada dengan kosakata yang tetap kecil."),
  num("nlp-03-q4", "Berapa token huruf (karakter, termasuk spasi dan tanda baca) pada 'Belajar NLP itu seru!'?", ["char_tokens"], 2, 21.0, 0.01, "7 + 1 + 3 + 1 + 3 + 1 + 5 = 21."),
  code("nlp-03-q5", "Tulis tiga baris keluaran kode di tab Implementasi.", ["word_tokens", "char_tokens"], 2, "['belajar', 'nlp', 'itu', 'seru']\n21\n['belajar', 'itu', 'nlp', 'seru']", "Daftar kata, jumlah karakter, lalu kata unik terurut."),
  mcq("nlp-03-q6", "Mana yang punya urutan token terpanjang untuk kalimat yang sama?", ["char_tokens"], 1, ["Token huruf", "Token kata", "Token subkata", "Semuanya sama"], 0, "Setiap huruf menjadi satu token."),
 ]}

def lesson_meta(rows, track):
    return [{"id": r[0], "track": track, "order": i + 1, "title": r[1], "difficulty": r[2], "prerequisites": r[3], "concepts": r[4], "authored": r[5]} for i, r in enumerate(rows)]

def run_code(code):
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(compile(code, "<lesson>", "exec"), {})
    return buf.getvalue().strip()

def main():
    os.makedirs(os.path.join(OUT, "lessons"), exist_ok=True)
    meta = lesson_meta(NN, "nn") + lesson_meta(NLP, "nlp")
    authored = {m["id"] for m in meta if m["authored"]}
    assert authored == set(LESSONS), (authored ^ set(LESSONS))
    with open(os.path.join(OUT, "curriculum.json"), "w", encoding="utf-8") as f:
        json.dump({"version": 1, "lessons": meta}, f, ensure_ascii=False, indent=1)
    for lid, body in LESSONS.items():
        m = next(x for x in meta if x["id"] == lid)
        body = dict(body); body.update({"id": lid, "title": m["title"], "track": m["track"], "concepts": m["concepts"]})
        body["glossary"] = [{"terms": t, "definition": d} for t, d in GLOSSARY[lid]]
        body["implementation"] = dict(body["implementation"]); body["implementation"]["expected"] = run_code(body["implementation"]["code"])   # keluaran sungguhan hasil eksekusi
        for q in body["questions"]:
            if q["type"] == "SHORT_CONCEPT": q["modelAnswer"] = MODEL[q["id"]]
            assert q["concepts"] and all(c in m["concepts"] for c in q["concepts"]), (lid, q["id"], q["concepts"])
        with open(os.path.join(OUT, "lessons", lid + ".json"), "w", encoding="utf-8") as f:
            json.dump(body, f, ensure_ascii=False, indent=1)
    print("curriculum:", len(meta), "pelajaran,", len(LESSONS), "sudah ditulis,", sum(len(b["questions"]) for b in LESSONS.values()), "soal")

if __name__ == "__main__":
    main()
