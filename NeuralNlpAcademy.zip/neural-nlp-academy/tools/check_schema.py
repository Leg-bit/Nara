#!/usr/bin/env python3
"""Memeriksa kontrak data aset kurikulum terhadap yang dibaca parser Kotlin (CurriculumJson.kt): kunci wajib, nilai enum, jenis visualisasi."""
import glob, json, os, sys
ROOT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "curriculum")
VIZ = {"dot_product", "dataset_scatter", "neuron", "lang_id", "norm_steps", "tokenization"}
DATASETS = {"xor", "and", "blobs", "circles", "moons"}; ACTS = {"LINEAR", "SIGMOID", "TANH", "RELU", "LEAKY_RELU"}; OPTS = {"SGD", "MOMENTUM", "ADAM"}
NLP_TABS = {"tokenize", "normalize", "tfidf", "classify", "langid"}
NEED = {"MCQ": ["choices", "correct"], "NUMERIC": ["answer", "tolerance"], "SHORT_CONCEPT": ["rubric"], "CODE_OUTPUT": ["expected"], "EXPERIMENT": ["metric", "target"]}
bad = []
def need(o, keys, where):
    for k in keys:
        if k not in o: bad.append(f"{where}: kunci '{k}' hilang")
meta = json.load(open(os.path.join(ROOT, "curriculum.json"), encoding="utf-8"))
need(meta, ["lessons"], "curriculum")
for m in meta["lessons"]: need(m, ["id", "track", "order", "title", "difficulty", "prerequisites", "concepts", "authored"], m.get("id", "?"))
for path in sorted(glob.glob(os.path.join(ROOT, "lessons", "*.json"))):
    L = json.load(open(path, encoding="utf-8")); w = L.get("id", path)
    need(L, ["id", "title", "track", "concept", "explanation", "math", "visualization", "implementation", "experiment", "exercises", "questions"], w)
    need(L["visualization"], ["type", "title"], w + ".visualization"); need(L["implementation"], ["language", "code", "expected", "steps"], w + ".implementation")
    if L["visualization"]["type"] not in VIZ: bad.append(f"{w}: visualisasi '{L['visualization']['type']}' tidak didukung aplikasi")
    ex = L["experiment"]; need(ex, ["kind", "instruction"], w + ".experiment")
    if ex["kind"] == "nn":
        pr = ex.get("preset", {})
        if pr.get("dataset") not in DATASETS or pr.get("activation") not in ACTS or pr.get("optimizer") not in OPTS: bad.append(f"{w}: preset nn tidak valid {pr}")
        if not isinstance(pr.get("hidden"), list): bad.append(f"{w}: preset.hidden harus list")
    elif ex["kind"] == "nlp":
        if ex.get("preset", {}).get("tab") not in NLP_TABS: bad.append(f"{w}: tab nlp tidak valid")
    elif ex["kind"] != "none": bad.append(f"{w}: jenis eksperimen tidak dikenal")
    for q in L["questions"]:
        need(q, ["id", "type", "prompt", "concepts", "difficulty", "explanation"] + NEED.get(q["type"], ["__jenis_tidak_dikenal__"]), q.get("id", "?"))
        if q["type"] == "EXPERIMENT" and ex["kind"] != "nn": bad.append(f"{q['id']}: soal EXPERIMENT butuh eksperimen nn pada pelajaran")
        if not 1 <= q["difficulty"] <= 5: bad.append(f"{q['id']}: kesulitan di luar 1..5")
print("\n".join(bad) if bad else "skema aset OK")
sys.exit(1 if bad else 0)
