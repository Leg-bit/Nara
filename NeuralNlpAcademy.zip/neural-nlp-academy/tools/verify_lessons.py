#!/usr/bin/env python3
"""Menjalankan SEMUA cuplikan kode pelajaran dan membandingkan keluarannya dengan jawaban soal CODE_OUTPUT dan dengan soal NUMERIC
yang dapat dihitung ulang. Gagal (exit 1) kalau ada yang tidak cocok. Jalankan: python tools/verify_lessons.py"""
import io, json, os, sys, contextlib, glob

ROOT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "curriculum")

def run(code):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(compile(code, "<lesson>", "exec"), {})
    return buf.getvalue().strip()

def main():
    bad = 0
    meta = json.load(open(os.path.join(ROOT, "curriculum.json"), encoding="utf-8"))["lessons"]
    ids = {m["id"] for m in meta}
    for m in meta:
        for p in m["prerequisites"]:
            if p not in ids: print("prasyarat tidak dikenal:", m["id"], p); bad += 1
    for path in sorted(glob.glob(os.path.join(ROOT, "lessons", "*.json"))):
        L = json.load(open(path, encoding="utf-8"))
        assert len(L["questions"]) >= 5, L["id"] + " butuh >= 5 soal"
        assert L["implementation"]["expected"] == run(L["implementation"]["code"]), L["id"] + ": keluaran tersimpan != hasil eksekusi"
        out = run(L["implementation"]["code"])
        codeqs = [q for q in L["questions"] if q["type"] == "CODE_OUTPUT"]
        for q in codeqs:
            full_expected = q["expected"].strip()
            # soal boleh menanyakan sebagian baris pertama; cocokkan baris-baris yang diminta dengan awal keluaran
            exp_lines = full_expected.split("\n"); out_lines = out.split("\n")
            ok = out_lines[:len(exp_lines)] == exp_lines   # baris yang diminta harus sama persis dengan baris awal keluaran
            print(("OK   " if ok else "GAGAL"), L["id"], q["id"], repr(full_expected), "<-", repr(out))
            bad += 0 if ok else 1
        for q in L["questions"]:
            if q["type"] == "MCQ": assert 0 <= q["correct"] < len(q["choices"]), q["id"]
            if q["type"] == "SHORT_CONCEPT": assert q.get("modelAnswer"), q["id"]
            if q["type"] == "SHORT_CONCEPT": assert q["rubric"] and all(g for g in q["rubric"]), q["id"]
    print("selesai:", "ADA YANG GAGAL" if bad else "semua cuplikan kode cocok dengan jawaban soal")
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
