package com.neuralnlp.academy

import com.neuralnlp.academy.domain.CurriculumJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Memuat aset kurikulum yang sebenarnya (dari folder assets) dan memastikan seluruhnya valid dan konsisten. */
class CurriculumJsonTest {
    private val root = File("src/main/assets/curriculum")

    @Test fun curriculumIsValidAndHasBothTracks() {
        val c = CurriculumJson.parseCurriculum(File(root, "curriculum.json").readText())
        assertTrue(c.validate().joinToString(), c.validate().isEmpty())
        assertEquals(18, c.track("nn").size)
        assertEquals(20, c.track("nlp").size)
    }

    @Test fun everyAuthoredLessonHasLoadableContentAndQuestions() {
        val c = CurriculumJson.parseCurriculum(File(root, "curriculum.json").readText())
        val authored = c.all().filter { it.authored }
        assertTrue(authored.isNotEmpty())
        for (l in authored) {
            val content = CurriculumJson.parseLesson(File(root, "lessons/${l.id}.json").readText())
            assertEquals(l.id, content.id)
            assertTrue("${l.id} butuh >= 5 soal", content.questions.size >= 5)
            assertTrue(content.questions.all { q -> q.concepts.all { it in l.concepts } })
        }
    }

    @Test fun lessonsWithoutContentFileAreNotMarkedAuthored() {
        val c = CurriculumJson.parseCurriculum(File(root, "curriculum.json").readText())
        for (l in c.all()) assertEquals(l.id, l.authored, File(root, "lessons/${l.id}.json").exists())
    }
}
