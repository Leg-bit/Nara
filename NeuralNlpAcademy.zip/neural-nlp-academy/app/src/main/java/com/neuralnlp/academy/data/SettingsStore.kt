package com.neuralnlp.academy.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore("settings")

/** batterySaver: membatasi epoch laboratorium (150) dan menurunkan resolusi batas keputusan. */
data class AppSettings(val batterySaver: Boolean)

class SettingsStore(private val context: Context) {
    private val keySaver = booleanPreferencesKey("battery_saver")
    val flow: Flow<AppSettings> = context.settingsStore.data.map { AppSettings(it[keySaver] ?: false) }
    suspend fun setBatterySaver(v: Boolean) { context.settingsStore.edit { it[keySaver] = v } }
}
