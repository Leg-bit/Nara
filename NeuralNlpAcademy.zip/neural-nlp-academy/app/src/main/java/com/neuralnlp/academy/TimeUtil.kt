package com.neuralnlp.academy

import java.time.LocalDate

/** Hari ini sebagai epoch day (dipakai untuk peluruhan penguasaan dan runtun belajar). */
fun todayEpochDay(): Long = LocalDate.now().toEpochDay()
