package com.neuralnlp.academy.data

import android.content.Context
import com.neuralnlp.academy.domain.CurriculumJson
import com.neuralnlp.academy.domain.LessonContent
import com.neuralnlp.academy.engine.learning.Curriculum

/** Membaca kurikulum dan isi pelajaran dari aset (offline sepenuhnya). Isi pelajaran dimuat saat dibutuhkan lalu disimpan di memori. */
class CurriculumRepository(private val context: Context) {
    val curriculum: Curriculum by lazy {
        CurriculumJson.parseCurriculum(read("curriculum/curriculum.json")).also {
            val problems = it.validate()
            check(problems.isEmpty()) { "kurikulum tidak valid: $problems" }
        }
    }

    private val cache = HashMap<String, LessonContent>()

    fun lesson(id: String): LessonContent? {
        cache[id]?.let { return it }
        val meta = curriculum.get(id) ?: return null
        if (!meta.authored) return null
        val content = CurriculumJson.parseLesson(read("curriculum/lessons/$id.json"))
        cache[id] = content
        return content
    }

    fun authoredContents(): List<LessonContent> = curriculum.topologicalOrder().filter { it.authored }.mapNotNull { lesson(it.id) }

    private fun read(path: String): String = context.assets.open(path).bufferedReader().use { it.readText() }
}
