package com.neuralnlp.academy.ui.viz

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuralnlp.academy.engine.lab.NlpLab
import com.neuralnlp.academy.engine.lab.NnLab
import com.neuralnlp.academy.engine.nlp.LanguageIdentifier
import com.neuralnlp.academy.engine.nlp.TextNormalizer
import com.neuralnlp.academy.engine.nn.Activation
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.Chips
import com.neuralnlp.academy.ui.components.LabeledSlider
import com.neuralnlp.academy.ui.components.f2
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.Surface2
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn
import kotlin.math.acos
import kotlin.math.hypot

/** Memilih visualisasi interaktif sesuai jenis pada berkas pelajaran. */
@Composable
fun LessonViz(type: String) {
    when (type) {
        "dot_product" -> DotProductViz()
        "dataset_scatter" -> DatasetScatterViz()
        "neuron" -> NeuronViz()
        "lang_id" -> LangIdViz()
        "norm_steps" -> NormStepsViz()
        "tokenization" -> TokenizationViz()
        else -> Text("Visualisasi \"$type\" belum tersedia.", color = Warn)
    }
}

@Composable
private fun DotProductViz() {
    var ax by remember { mutableStateOf(2f) }; var ay by remember { mutableStateOf(1f) }
    var bx by remember { mutableStateOf(1f) }; var by by remember { mutableStateOf(2f) }
    val dot = ax * bx + ay * by
    val na = hypot(ax, ay); val nb = hypot(bx, by)
    val angle = if (na * nb < 1e-6f) 0.0 else Math.toDegrees(acos((dot / (na * nb)).coerceIn(-1f, 1f).toDouble()))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)) {
            val c = Offset(size.width / 2, size.height / 2); val s = size.height / 8.5f
            drawLine(Color(0x33FFFFFF), Offset(0f, c.y), Offset(size.width, c.y), 1f); drawLine(Color(0x33FFFFFF), Offset(c.x, 0f), Offset(c.x, size.height), 1f)
            drawLine(Electric, c, Offset(c.x + ax * s, c.y - ay * s), 5f)
            drawLine(Good, c, Offset(c.x + bx * s, c.y - by * s), 5f)
        }
        Text("a (biru) = (${f2(ax.toDouble())}, ${f2(ay.toDouble())})   b (hijau) = (${f2(bx.toDouble())}, ${f2(by.toDouble())})", color = TextLo, fontSize = 12.sp)
        LabeledSlider("a.x", ax, -3f..3f, f2(ax.toDouble())) { ax = it }; LabeledSlider("a.y", ay, -3f..3f, f2(ay.toDouble())) { ay = it }
        LabeledSlider("b.x", bx, -3f..3f, f2(bx.toDouble())) { bx = it }; LabeledSlider("b.y", by, -3f..3f, f2(by.toDouble())) { by = it }
        Text("a · b = ${f2(dot.toDouble())}      sudut = ${f2(angle)}°", color = TextHi, fontSize = 15.sp)
        Text(if (kotlin.math.abs(dot) < 0.05f) "Dot product ≈ 0: kedua vektor tegak lurus." else if (dot > 0) "Dot product positif: kedua vektor cenderung searah." else "Dot product negatif: kedua vektor cenderung berlawanan.", color = TextLo, fontSize = 13.sp)
    }
}

@Composable
private fun DatasetScatterViz() {
    var name by remember { mutableStateOf("circles") }
    val ds = remember(name) { NnLab.dataset(name) }
    val notes = mapOf("xor" to "XOR: tidak bisa dipisah satu garis lurus.", "and" to "AND: bisa dipisah satu garis lurus.", "blobs" to "Blobs: dua gumpalan, mudah dipisah garis lurus.",
        "circles" to "Circles: lingkaran dalam dan luar, butuh batas melengkung.", "moons" to "Moons: dua bulan sabit, butuh batas melengkung.")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Chips(listOf("xor", "and", "blobs", "circles", "moons"), name, { it }) { name = it }
        Canvas(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)) {
            var x0 = Double.MAX_VALUE; var x1 = -Double.MAX_VALUE; var y0 = Double.MAX_VALUE; var y1 = -Double.MAX_VALUE
            for (p in ds.x) { x0 = minOf(x0, p[0]); x1 = maxOf(x1, p[0]); y0 = minOf(y0, p[1]); y1 = maxOf(y1, p[1]) }
            val mx = (x1 - x0) * 0.1 + 1e-6; val my = (y1 - y0) * 0.1 + 1e-6
            for (i in ds.x.indices) {
                val px = ((ds.x[i][0] - x0 + mx) / (x1 - x0 + 2 * mx) * size.width).toFloat()
                val py = (size.height - (ds.x[i][1] - y0 + my) / (y1 - y0 + 2 * my) * size.height).toFloat()
                drawCircle(if (ds.y[i] > 0.5) Electric else Bad, 7f, Offset(px, py))
            }
        }
        Text("${ds.size()} titik • biru = kelas 1, merah = kelas 0. ${notes[name] ?: ""}", color = TextLo, fontSize = 13.sp)
    }
}

@Composable
private fun NeuronViz() {
    var x1 by remember { mutableStateOf(0.5f) }; var x2 by remember { mutableStateOf(-1f) }
    var w1 by remember { mutableStateOf(0.8f) }; var w2 by remember { mutableStateOf(0.2f) }; var b by remember { mutableStateOf(0.1f) }
    var act by remember { mutableStateOf(Activation.SIGMOID) }
    val z = (w1 * x1 + w2 * x2 + b).toDouble(); val a = act.apply(z)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Chips(listOf(Activation.SIGMOID, Activation.TANH, Activation.RELU, Activation.LEAKY_RELU, Activation.LINEAR), act, { it.name }) { act = it }
        Canvas(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)) {
            val path = Path(); var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
            for (i in 0..80) { val v = act.apply(-4.0 + 8.0 * i / 80); lo = minOf(lo, v); hi = maxOf(hi, v) }
            if (hi - lo < 1e-9) hi = lo + 1
            fun px(zz: Double) = ((zz + 4.0) / 8.0 * size.width).toFloat()
            fun py(v: Double) = (size.height - (v - lo) / (hi - lo) * (size.height - 10f) - 5f).toFloat()
            for (i in 0..80) { val zz = -4.0 + 8.0 * i / 80; val p = Offset(px(zz), py(act.apply(zz))); if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
            drawPath(path, Electric, style = Stroke(3f))
            drawCircle(Warn, 9f, Offset(px(z.coerceIn(-4.0, 4.0)), py(act.apply(z.coerceIn(-4.0, 4.0)))))
        }
        LabeledSlider("x₁", x1, -2f..2f, f2(x1.toDouble())) { x1 = it }; LabeledSlider("x₂", x2, -2f..2f, f2(x2.toDouble())) { x2 = it }
        LabeledSlider("w₁", w1, -2f..2f, f2(w1.toDouble())) { w1 = it }; LabeledSlider("w₂", w2, -2f..2f, f2(w2.toDouble())) { w2 = it }
        LabeledSlider("bias b", b, -2f..2f, f2(b.toDouble())) { b = it }
        Text("z = w·x + b = ${f2(z)}      keluaran a = ${act.name.lowercase()}(z) = ${f2(a)}", color = TextHi, fontSize = 14.sp)
    }
}

@Composable
private fun LangIdViz() {
    val li = remember { LanguageIdentifier() }
    var text by remember { mutableStateOf("Saya sedang belajar kecerdasan buatan") }
    val p = remember(text) { li.probabilities(text) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Ketik kalimat") })
        for ((lang, v) in p) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (lang == "id") "Indonesia" else "Inggris", color = TextHi, fontSize = 13.sp, modifier = Modifier.size(width = 78.dp, height = 20.dp))
                Column(Modifier.weight(1f)) { Bar(v.toFloat(), color = if (lang == "id") Good else Electric) }
                Text(pct(v), color = TextLo, fontSize = 13.sp)
            }
        }
        Text("Deteksi: ${li.detect(text)}  (Naive Bayes atas trigram huruf, data kecil — kalimat sangat pendek kurang andal)", color = TextLo, fontSize = 12.sp)
    }
}

@Composable
private fun NormStepsViz() {
    var text by remember { mutableStateOf("Gue gak suka makanan ini, BGT!!") }
    var slang by remember { mutableStateOf(true) }; var stop by remember { mutableStateOf(false) }; var stem by remember { mutableStateOf(false) }
    val steps = remember(text, slang, stop, stem) {
        val o = TextNormalizer.Options(); o.expandSlang = slang; o.removeStopwords = stop; o.stem = stem
        TextNormalizer.steps(text, o)
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Teks mentah") })
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(slang, { slang = it }); Spacer(Modifier.size(8.dp)); Text("Bakukan singkatan gaul", color = TextHi, fontSize = 13.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(stop, { stop = it }); Spacer(Modifier.size(8.dp)); Text("Buang stopword", color = TextHi, fontSize = 13.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(stem, { stem = it }); Spacer(Modifier.size(8.dp)); Text("Stemming", color = TextHi, fontSize = 13.sp) }
        for ((i, s) in steps.withIndex()) Text("${i + 1}. ${s.name}: ${s.result}", color = if (i == steps.size - 1) Good else TextLo, fontSize = 13.sp)
    }
}

@Composable
private fun TokenizationViz() {
    var text by remember { mutableStateOf("Belajar membaca itu seru") }
    var merges by remember { mutableStateOf(30f) }
    val v = remember(text, merges.toInt()) { NlpLab.tokenize(text, merges.toInt()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Teks") })
        LabeledSlider("Jumlah gabungan BPE", merges, 0f..60f, merges.toInt().toString()) { merges = it }
        Text("Kata (${v.words.size}): ${v.words.joinToString(" | ")}", color = TextHi, fontSize = 13.sp)
        Text("Subkata BPE (${v.subwords.size}): ${v.subwords.joinToString(" | ")}", color = Good, fontSize = 13.sp)
        Text("Huruf (${v.chars.size}): ${v.chars.joinToString("·")}", color = TextLo, fontSize = 13.sp)
        Text("BPE dilatih pada korpus mini (Indonesia + Inggris). Dengan 0 gabungan, subkata = huruf; makin banyak gabungan, kata yang sering muncul makin menyatu.", color = TextLo, fontSize = 12.sp)
    }
}
