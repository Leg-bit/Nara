package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.engine.learning.UnlockPolicy
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.Pill
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn

/** Daftar pelajaran sebuah jalur. Status memakai aturan engine: hanya skor asesmen yang membuka pelajaran berikutnya. */
@Composable
fun TrackScreen(track: String, vm: AcademyViewModel, nav: NavController) {
    val records by vm.records.collectAsState()
    val lessons = vm.curriculum.track(track)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader(if (track == "nn") "Neural Network Academy" else "NLP Academy", nav) }
        items(lessons) { l ->
            val rec = records[l.id]
            val unlocked = UnlockPolicy.isUnlocked(l, records)
            val open = l.authored && unlocked
            Panel(Modifier.clickable(enabled = open) { nav.navigate("lesson/${l.id}") }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${l.order}. ${l.title}", color = if (open) TextHi else TextLo, fontSize = 15.sp)
                    when {
                        !l.authored -> Pill("Segera hadir", TextLo)
                        rec != null && rec.passed() -> Pill("Lulus ${pct(rec.bestScore)}", Good)
                        !unlocked -> Pill("Terkunci", Warn)
                        rec != null && rec.attempts > 0 -> Pill("Terbaik ${pct(rec.bestScore)}", Electric)
                        else -> Pill("Tersedia", Electric)
                    }
                }
                val sub = when {
                    !l.authored -> "Materi belum ditulis; belum bisa dibuka."
                    !unlocked -> "Lulus dulu: " + l.prerequisites.filter { !UnlockPolicy.isPassed(records, it) }.joinToString { vm.curriculum.get(it)?.title ?: it }
                    else -> "Kesulitan ${"●".repeat(l.difficulty)}${"○".repeat(5 - l.difficulty)} • konsep: ${l.concepts.joinToString(", ")}"
                }
                Text(sub, color = TextLo, fontSize = 12.sp)
            }
        }
    }
}
