package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo

@Composable
fun SettingsScreen(vm: AcademyViewModel, nav: NavController) {
    val settings by vm.settings.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("←") }
            Text("Pengaturan", color = TextHi, fontSize = 22.sp)
        }
        Panel(title = "Performa") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mode hemat baterai", color = TextHi, fontSize = 15.sp)
                    Text("Membatasi epoch laboratorium (maks 150), memperbesar batch, dan menurunkan resolusi batas keputusan.", color = TextLo, fontSize = 12.sp)
                }
                Switch(settings.batterySaver, { vm.setBatterySaver(it) })
            }
        }
        Panel(title = "Data") {
            Text("Semua kurikulum, soal, progres, dan riwayat tersimpan di HP ini (Room). Tidak ada akun, tidak ada internet yang dibutuhkan.", color = TextLo, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { confirm = true }) { Text("Reset semua progres", color = Bad) }
        }
        Panel(title = "Tentang") {
            Text("Neural & NLP Academy 0.1.0 (fase 1). Mesin pelatihan, NLP, asesmen, dan rekomendasi adalah kode Java murni yang diuji otomatis. Python belum dieksekusi di aplikasi; pelajaran yang belum ditulis ditandai \"Segera hadir\".", color = TextLo, fontSize = 13.sp)
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("Reset progres?") }, text = { Text("Skor, penguasaan konsep, riwayat asesmen dan eksperimen akan dihapus permanen.") },
        confirmButton = { TextButton(onClick = { vm.resetAll(); confirm = false }) { Text("Hapus", color = Bad) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } })
}
