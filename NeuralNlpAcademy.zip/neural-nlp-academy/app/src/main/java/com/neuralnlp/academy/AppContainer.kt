package com.neuralnlp.academy

import android.app.Application
import android.content.Context
import com.neuralnlp.academy.data.CurriculumRepository
import com.neuralnlp.academy.data.ProgressRepository
import com.neuralnlp.academy.data.SettingsStore
import com.neuralnlp.academy.data.db.AcademyDatabase

/** Wadah dependensi sederhana (tanpa framework DI). */
class AppContainer(context: Context) {
    val curriculum = CurriculumRepository(context)
    val progress = ProgressRepository(AcademyDatabase.create(context))
    val settings = SettingsStore(context)
}

class AcademyApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
