package com.neuralnlp.academy.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [LessonProgressEntity::class, ConceptMasteryEntity::class, AssessmentAttemptEntity::class, ExperimentRunEntity::class, DailyActivityEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AcademyDatabase : RoomDatabase() {
    abstract fun progressDao(): ProgressDao

    companion object {
        fun create(context: Context): AcademyDatabase =
            Room.databaseBuilder(context.applicationContext, AcademyDatabase::class.java, "academy.db").build()
    }
}
