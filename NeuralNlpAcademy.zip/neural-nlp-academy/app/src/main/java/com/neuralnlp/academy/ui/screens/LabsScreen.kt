package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.engine.lab.NnLabConfig
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.lab.NlpLabPanel
import com.neuralnlp.academy.ui.lab.NnLabPanel
import com.neuralnlp.academy.ui.lab.describe
import com.neuralnlp.academy.ui.theme.Surface1

@Composable
fun LabsScreen(vm: AcademyViewModel, nav: NavController) {
    val settings by vm.settings.collectAsState()
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Laboratorium", nav)
        TabRow(selectedTabIndex = tab, containerColor = Surface1) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Jaringan Saraf") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("NLP") })
        }
        if (tab == 0) NnLabPanel(NnLabConfig(), settings.batterySaver, { cfg, r -> vm.recordExperiment("nn", describe(cfg), "uji ${pct(r.testAccuracy)}, latih ${pct(r.trainAccuracy)}") })
        else NlpLabPanel(null)
    }
}
