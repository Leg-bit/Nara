package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.AppContainer
import com.neuralnlp.academy.LessonViewModel
import com.neuralnlp.academy.domain.LessonContent
import com.neuralnlp.academy.engine.assessment.Answer
import com.neuralnlp.academy.engine.assessment.Question
import com.neuralnlp.academy.engine.assessment.QuestionType
import com.neuralnlp.academy.engine.lab.NnLabConfig
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.CodeBlock
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.Pill
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.lab.NlpLabPanel
import com.neuralnlp.academy.ui.lab.NnLabPanel
import com.neuralnlp.academy.ui.lab.describe
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.Surface2
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn
import com.neuralnlp.academy.ui.viz.LessonViz
import com.neuralnlp.academy.engine.assessment.Grade
import com.neuralnlp.academy.engine.learning.Recommendation

/** Satu pelajaran: konsep -> penjelasan -> matematika -> visualisasi -> implementasi -> eksperimen -> asesmen -> umpan balik. */
@Composable
fun LessonScreen(container: AppContainer, lessonId: String, vm: AcademyViewModel, nav: NavController) {
    val lvm: LessonViewModel = viewModel(key = "lesson-$lessonId", factory = viewModelFactory { initializer { LessonViewModel(container, lessonId) } })
    val content = lvm.content
    val lesson = lvm.lesson
    if (content == null || lesson == null) {
        Column(Modifier.padding(16.dp)) { Text("Pelajaran belum tersedia.", color = Warn); OutlinedButton(onClick = { nav.popBackStack() }) { Text("Kembali") } }
        return
    }
    val stage by lvm.stage.collectAsState()
    val exam by lvm.exam.collectAsState()
    val settings by vm.settings.collectAsState()
    var maxStage by remember { mutableStateOf(0) }
    if (stage > maxStage) maxStage = stage

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("←") }
            Text(content.title, color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LessonViewModel.STAGES.forEachIndexed { i, s ->
                val reachable = i <= maxStage
                Text("${i + 1}. $s", fontSize = 12.sp, color = if (i == stage) Color.White else if (reachable) TextHi else TextLo,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (i == stage) Electric else Surface2)
                        .clickable(enabled = reachable) { lvm.goTo(i) }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (stage) {
                0 -> Panel(title = "Konsep") {
                    Text(content.concept, color = TextHi, fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Konsep yang dinilai: ${lesson.concepts.joinToString(", ")}", color = TextLo, fontSize = 12.sp)
                    Text("Prasyarat: ${if (lesson.prerequisites.isEmpty()) "tidak ada" else lesson.prerequisites.joinToString { vm.curriculum.get(it)?.title ?: it }}", color = TextLo, fontSize = 12.sp)
                }
                1 -> Panel(title = "Penjelasan") { content.explanation.forEach { Text(it, color = TextHi, fontSize = 15.sp, lineHeight = 22.sp); Spacer(Modifier.height(8.dp)) } }
                2 -> Panel(title = "Fondasi matematika") { content.math.forEach { Text(it, color = TextHi, fontSize = 14.sp, fontFamily = FontFamily.Monospace); Spacer(Modifier.height(6.dp)) } }
                3 -> Panel(title = content.viz.title) { LessonViz(content.viz.type) }
                4 -> ImplementationStage(content)
                5 -> ExperimentStage(content, settings.batterySaver, vm)
                6 -> AssessmentStage(content, lvm, settings.batterySaver, vm)
                else -> FeedbackStage(lvm, vm, nav)
            }
        }
        if (stage < LessonViewModel.ASSESSMENT) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(enabled = stage > 0, onClick = { lvm.goTo(stage - 1) }) { Text("Sebelumnya") }
                Button(onClick = { lvm.goTo(stage + 1) }) { Text(if (stage == LessonViewModel.ASSESSMENT - 1) "Ke asesmen" else "Lanjut") }
            }
        }
    }
}

@Composable
private fun ImplementationStage(c: LessonContent) {
    Panel(title = "Implementasi (${c.impl.language})") {
        CodeBlock(c.impl.code)
        Spacer(Modifier.height(8.dp))
        c.impl.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", color = TextHi, fontSize = 13.sp) }
        Spacer(Modifier.height(8.dp))
        Text("Keluaran yang diharapkan (hasil eksekusi nyata saat kurikulum dibangun):", color = TextLo, fontSize = 12.sp)
        CodeBlock(c.impl.expected)
        Spacer(Modifier.height(6.dp))
        Text("Catatan: aplikasi ini belum menjalankan Python di dalam HP. Kode ini adalah demonstrasi; eksperimen yang benar-benar berjalan ada di tab Eksperimen dan Laboratorium. Kamu bisa menyalin kode ke Pydroid/Termux untuk mencobanya.", color = Warn, fontSize = 12.sp)
    }
}

@Composable
private fun ExperimentStage(c: LessonContent, saver: Boolean, vm: AcademyViewModel) {
    Panel(title = "Eksperimen") {
        Text(c.experiment.instruction, color = TextHi, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        when (c.experiment.kind) {
            "nn" -> NnLabPanel(c.experiment.nnPreset ?: NnLabConfig(), saver, { cfg, r -> vm.recordExperiment("nn", describe(cfg), "uji ${pct(r.testAccuracy)}, latih ${pct(r.trainAccuracy)}") })
            "nlp" -> NlpLabPanel(c.experiment.nlpTab)
            else -> Text("Pelajaran ini memakai visualisasi interaktif sebagai eksperimennya (tab Visualisasi).", color = TextLo, fontSize = 13.sp)
        }
    }
    Panel(title = "Latihan mandiri") { c.exercises.forEachIndexed { i, e -> Text("${i + 1}. $e", color = TextHi, fontSize = 14.sp); Spacer(Modifier.height(4.dp)) } }
}

@Composable
private fun AssessmentStage(c: LessonContent, lvm: LessonViewModel, saver: Boolean, vm: AcademyViewModel) {
    val exam by lvm.exam.collectAsState()
    val e = exam
    if (e == null || (e.question == null && e.result == null)) {
        Panel(title = "Asesmen") {
            Text("Soal dipilih adaptif: konsep yang masih lemah diutamakan dan tingkat kesulitan disesuaikan dengan penguasaanmu. Pelajaran berikutnya hanya terbuka jika skor ≥ 70%. Menekan tombol lanjut saja tidak membuka apa pun.", color = TextHi, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { lvm.startExam() }) { Text("Mulai asesmen") }
        }
        return
    }
    val q = e.question ?: return
    Panel(title = "Soal ${if (e.grade != null) e.index else e.index + 1} dari ${e.total}") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Pill(q.type.name, Electric); Pill("kesulitan ${q.difficulty}", Warn) }
        Spacer(Modifier.height(8.dp))
        Text(q.prompt, color = TextHi, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        val g = e.grade
        if (g == null) QuestionInput(q, c, saver, vm) { lvm.submit(it) }
        else {
            Text(if (g.correct()) "Benar" else if (g.score > 0) "Sebagian benar (${pct(g.score)})" else "Belum tepat", color = if (g.correct()) Good else if (g.score > 0) Warn else Bad, fontWeight = FontWeight.SemiBold)
            Text(g.feedback, color = TextHi, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { lvm.next() }) { Text(if (e.index >= e.total) "Lihat hasil" else "Soal berikutnya") }
        }
    }
}

@Composable
private fun QuestionInput(q: Question, c: LessonContent, saver: Boolean, vm: AcademyViewModel, onSubmit: (Answer) -> Unit) {
    when (q.type) {
        QuestionType.MCQ -> {
            var sel by remember(q.id) { mutableStateOf(-1) }
            q.choices.forEachIndexed { i, ch ->
                Row(Modifier.fillMaxWidth().clickable { sel = i }, verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = sel == i, onClick = { sel = i }); Text(ch, color = TextHi, fontSize = 14.sp) }
            }
            Button(enabled = sel >= 0, onClick = { onSubmit(Answer.choice(sel)) }) { Text("Jawab") }
        }
        QuestionType.NUMERIC -> {
            var t by remember(q.id) { mutableStateOf("") }
            OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text("Jawaban (angka)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Button(enabled = t.isNotBlank(), onClick = { onSubmit(t.replace(',', '.').trim().toDoubleOrNull()?.let { Answer.number(it) } ?: Answer.text(t)) }) { Text("Jawab") }
        }
        QuestionType.SHORT_CONCEPT, QuestionType.CODE_OUTPUT -> {
            var t by remember(q.id) { mutableStateOf("") }
            OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text(if (q.type == QuestionType.CODE_OUTPUT) "Keluaran (satu baris per baris)" else "Penjelasanmu") }, minLines = 3,
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = if (q.type == QuestionType.CODE_OUTPUT) FontFamily.Monospace else FontFamily.Default))
            if (q.type == QuestionType.CODE_OUTPUT) {
                Spacer(Modifier.height(4.dp)); Text("Kode ada di tahap Implementasi; baca keluarannya dengan teliti.", color = TextLo, fontSize = 12.sp)
            }
            Button(enabled = t.isNotBlank(), onClick = { onSubmit(Answer.text(t)) }) { Text("Jawab") }
        }
        QuestionType.EXPERIMENT -> {
            Text("Atur dan jalankan eksperimen. Hasil (${q.metricName}) dihitung dari pelatihan nyata, bukan diketik. Target: ${pct(q.target)}.", color = TextLo, fontSize = 13.sp)
            NnLabPanel(c.experiment.nnPreset ?: NnLabConfig(), saver, { cfg, r -> vm.recordExperiment("nn", describe(cfg), "uji ${pct(r.testAccuracy)}, latih ${pct(r.trainAccuracy)}") }) { acc -> onSubmit(Answer.number(acc)) }
        }
    }
}

@Composable
private fun FeedbackStage(lvm: LessonViewModel, vm: AcademyViewModel, nav: NavController) {
    val exam by lvm.exam.collectAsState()
    val r = exam?.result
    if (r == null) { Panel(title = "Umpan balik") { Text("Selesaikan asesmen untuk melihat umpan balik.", color = TextLo) }; return }
    Panel(title = "Hasil asesmen") {
        Text(pct(r.score), color = if (r.passed()) Good else Warn, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(if (r.passed()) "Lulus. Pelajaran berikutnya dibuka berdasarkan skor ini." else "Belum lulus (batas 70%). Pelajaran berikutnya tetap terkunci. Perbaiki konsep lemah lalu ulangi.", color = TextHi, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Text("Skor per konsep", color = TextLo, fontSize = 13.sp)
        for ((k, v) in r.conceptScores) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k, color = TextHi, fontSize = 13.sp); Text(pct(v), color = if (v >= 0.6) Good else Bad, fontSize = 13.sp) }
            Bar(v.toFloat(), color = if (v >= 0.6) Good else Bad)
            Spacer(Modifier.height(4.dp))
        }
        if (r.weakConcepts.isNotEmpty()) Text("Konsep lemah: ${r.weakConcepts.joinToString(", ")}", color = Bad, fontSize = 13.sp)
    }
    val rec = exam?.recommendation
    if (rec != null) Panel(title = "Langkah berikutnya") {
        Text(vm.curriculum.get(rec.lessonId)?.title ?: rec.lessonId, color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(rec.reason, color = TextLo, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { nav.navigate("lesson/${rec.lessonId}") }) { Text(if (rec.lessonId == lvm.lessonId) "Mulai ulang pelajaran ini" else "Buka pelajaran itu") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { lvm.retry() }) { Text("Ulangi asesmen") }
        OutlinedButton(onClick = { nav.popBackStack() }) { Text("Ke daftar pelajaran") }
    }
}
