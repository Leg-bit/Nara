package com.neuralnlp.academy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.neuralnlp.academy.domain.LessonContent
import com.neuralnlp.academy.engine.assessment.Answer
import com.neuralnlp.academy.engine.assessment.ExamBuilder
import com.neuralnlp.academy.engine.assessment.ExamResult
import com.neuralnlp.academy.engine.assessment.ExamSession
import com.neuralnlp.academy.engine.assessment.Grade
import com.neuralnlp.academy.engine.assessment.Question
import com.neuralnlp.academy.engine.learning.Lesson
import com.neuralnlp.academy.engine.learning.MasteryModel
import com.neuralnlp.academy.engine.learning.Recommendation
import com.neuralnlp.academy.engine.learning.Recommender
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Random

/** Satu pelajaran: tahap belajar (siklus konsep -> umpan balik) dan sesi asesmen adaptif. */
class LessonViewModel(private val c: AppContainer, val lessonId: String) : ViewModel() {
    companion object {
        val STAGES = listOf("Konsep", "Penjelasan", "Matematika", "Visualisasi", "Implementasi", "Eksperimen", "Asesmen", "Umpan balik")
        const val ASSESSMENT = 6
        const val FEEDBACK = 7
    }

    /** index = jumlah soal yang sudah dijawab; grade != null berarti soal [question] baru dijawab dan umpan baliknya ditampilkan. */
    data class ExamUi(val index: Int, val total: Int, val question: Question?, val grade: Grade?, val result: ExamResult?, val recommendation: Recommendation?)

    val lesson: Lesson? = c.curriculum.curriculum.get(lessonId)
    val content: LessonContent? = c.curriculum.lesson(lessonId)

    private val _stage = MutableStateFlow(0)
    val stage: StateFlow<Int> = _stage
    private val _exam = MutableStateFlow<ExamUi?>(null)
    val exam: StateFlow<ExamUi?> = _exam

    private var session: ExamSession? = null
    private var mastery = MasteryModel()
    private var answered = 0

    fun goTo(i: Int) { _stage.value = i.coerceIn(0, STAGES.size - 1) }

    fun startExam() {
        val pool = content?.questions ?: return
        viewModelScope.launch {
            mastery = c.progress.mastery.first()
            val n = minOf(5, pool.size)
            val s = ExamSession(ExamBuilder.build(pool, mastery, n, Random(System.nanoTime())))
            session = s; answered = 0
            _exam.value = ExamUi(0, n, s.current(), null, null, null)
        }
    }

    fun submit(a: Answer) {
        val s = session ?: return
        val q = s.current() ?: return
        val g = s.submit(a)
        answered++
        _exam.value = ExamUi(answered, s.questions().size, q, g, null, null)
    }

    fun next() {
        val s = session ?: return
        if (s.finished()) finishExam() else _exam.value = ExamUi(answered, s.questions().size, s.current(), null, null, null)
    }

    private fun finishExam() {
        val s = session ?: return
        viewModelScope.launch {
            val today = todayEpochDay()
            val result = s.finish(mastery, today)
            c.progress.recordAssessment(lessonId, result, mastery, s.questions().size, today)
            val rec = Recommender.next(c.curriculum.curriculum, c.progress.records.first(), mastery, today)
            _exam.value = ExamUi(answered, s.questions().size, null, null, result, rec)
            _stage.value = FEEDBACK
        }
    }

    /** Mulai ulang asesmen setelah umpan balik. */
    fun retry() { session = null; _exam.value = null; _stage.value = ASSESSMENT; startExam() }
}
