package com.neuralnlp.academy.domain

import com.neuralnlp.academy.engine.assessment.Question
import com.neuralnlp.academy.engine.learning.Curriculum
import com.neuralnlp.academy.engine.learning.Lesson
import com.neuralnlp.academy.engine.lab.NnLabConfig
import com.neuralnlp.academy.engine.nn.Activation
import com.neuralnlp.academy.engine.nn.OptimizerType
import org.json.JSONArray
import org.json.JSONObject

/** Mengurai berkas aset kurikulum (JSON) menjadi objek engine. Tidak bergantung pada Android selain org.json. */
object CurriculumJson {
    private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

    fun parseCurriculum(text: String): Curriculum {
        val c = Curriculum()
        val arr = JSONObject(text).getJSONArray("lessons")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            c.add(Lesson(o.getString("id"), o.getString("track"), o.getInt("order"), o.getString("title"), o.getInt("difficulty"),
                o.getJSONArray("prerequisites").strings(), o.getJSONArray("concepts").strings(), o.getBoolean("authored")))
        }
        return c
    }

    fun parseNnPreset(o: JSONObject): NnLabConfig {
        val c = NnLabConfig()
        c.dataset = o.optString("dataset", c.dataset)
        val h = o.optJSONArray("hidden")
        if (h != null) c.hidden = IntArray(h.length()) { h.getInt(it) }
        c.activation = Activation.valueOf(o.optString("activation", c.activation.name))
        c.learningRate = o.optDouble("lr", c.learningRate)
        c.epochs = o.optInt("epochs", c.epochs)
        c.optimizer = OptimizerType.valueOf(o.optString("optimizer", c.optimizer.name))
        return c
    }

    fun parseQuestion(o: JSONObject): Question {
        val id = o.getString("id"); val prompt = o.getString("prompt"); val concepts = o.getJSONArray("concepts").strings()
        val diff = o.getInt("difficulty"); val expl = o.getString("explanation")
        return when (o.getString("type")) {
            "MCQ" -> Question.mcq(id, prompt, concepts, diff, o.getJSONArray("choices").strings(), o.getInt("correct"), expl)
            "NUMERIC" -> Question.numeric(id, prompt, concepts, diff, o.getDouble("answer"), o.getDouble("tolerance"), expl)
            "SHORT_CONCEPT" -> {
                val r = o.getJSONArray("rubric")
                Question.concept(id, prompt, concepts, diff, (0 until r.length()).map { r.getJSONArray(it).strings() }, expl)
            }
            "CODE_OUTPUT" -> Question.codeOutput(id, prompt, concepts, diff, o.getString("expected"), expl)
            "EXPERIMENT" -> Question.experiment(id, prompt, concepts, diff, o.getString("metric"), o.getDouble("target"), expl)
            else -> throw IllegalArgumentException("jenis soal tidak dikenal pada $id")
        }
    }

    fun parseLesson(text: String): LessonContent {
        val o = JSONObject(text)
        val v = o.getJSONObject("visualization"); val im = o.getJSONObject("implementation"); val ex = o.getJSONObject("experiment")
        val kind = ex.getString("kind")
        val spec = ExperimentSpec(kind, ex.getString("instruction"),
            if (kind == "nn") parseNnPreset(ex.getJSONObject("preset")) else null,
            if (kind == "nlp") ex.getJSONObject("preset").optString("tab") else null)
        val qs = o.getJSONArray("questions")
        return LessonContent(o.getString("id"), o.getString("title"), o.getString("track"), o.getString("concept"),
            o.getJSONArray("explanation").strings(), o.getJSONArray("math").strings(), Viz(v.getString("type"), v.getString("title")),
            Impl(im.getString("language"), im.getString("code"), im.getString("expected"), im.getJSONArray("steps").strings()),
            spec, o.getJSONArray("exercises").strings(), (0 until qs.length()).map { parseQuestion(qs.getJSONObject(it)) })
    }
}
