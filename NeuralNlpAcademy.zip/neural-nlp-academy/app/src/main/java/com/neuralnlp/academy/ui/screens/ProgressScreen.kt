package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.engine.learning.UnlockPolicy
import com.neuralnlp.academy.todayEpochDay
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.Pill
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProgressScreen(vm: AcademyViewModel, nav: NavController) {
    val records by vm.records.collectAsState()
    val mastery by vm.mastery.collectAsState()
    val attempts by vm.attempts.collectAsState()
    val experiments by vm.experiments.collectAsState()
    val streak by vm.streak.collectAsState()
    val today = todayEpochDay()
    val fmt = SimpleDateFormat("dd MMM HH:mm", Locale("id"))
    val authored = vm.curriculum.all().filter { it.authored }
    val passed = authored.count { UnlockPolicy.isPassed(records, it.id) }
    val weak = mastery.weakConcepts()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Progres & Analitik", nav)
        Panel(title = "Ringkasan") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("$passed lulus", Good); Pill("${attempts.size} asesmen", Electric); Pill("${experiments.size} eksperimen", Warn); Pill("runtun $streak hari", Warn) }
        }
        Panel(title = "Kompetensi per topik") {
            if (mastery.all().isEmpty()) Text("Belum ada data. Selesaikan sebuah asesmen.", color = TextLo, fontSize = 13.sp)
            for (l in authored) {
                val tested = l.concepts.filter { mastery.get(it) != null }
                if (tested.isEmpty()) continue
                Text(l.title, color = TextHi, fontSize = 14.sp)
                for (c in tested) {
                    val eff = mastery.effective(c, today); val raw = mastery.value(c)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c, color = TextLo, fontSize = 12.sp); Text("${pct(eff)}${if (raw - eff > 0.05) " (turun dari ${pct(raw)} karena lama tak diulang)" else ""}", color = TextLo, fontSize = 12.sp)
                    }
                    Bar(eff.toFloat(), color = if (eff >= 0.6) Good else Bad)
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
        Panel(title = "Konsep lemah") {
            if (weak.isEmpty()) Text("Tidak ada konsep lemah yang terdeteksi.", color = TextLo, fontSize = 13.sp)
            for (c in weak) Text("• $c (${pct(mastery.value(c))})", color = Bad, fontSize = 13.sp)
        }
        Panel(title = "Riwayat asesmen") {
            if (attempts.isEmpty()) Text("Belum ada.", color = TextLo, fontSize = 13.sp)
            for (a in attempts.take(20)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${fmt.format(Date(a.createdAt))}  ${vm.curriculum.get(a.lessonId)?.title ?: a.lessonId}", color = TextHi, fontSize = 12.sp)
                    Text(pct(a.score) + if (a.passed) " ✓" else " ✗", color = if (a.passed) Good else Bad, fontSize = 12.sp)
                }
            }
        }
        Panel(title = "Riwayat eksperimen pelatihan") {
            if (experiments.isEmpty()) Text("Belum ada. Jalankan eksperimen di tab Laboratorium.", color = TextLo, fontSize = 13.sp)
            for (e in experiments.take(20)) { Text("${fmt.format(Date(e.createdAt))} • ${e.config}", color = TextHi, fontSize = 12.sp); Text("   → ${e.result}", color = TextLo, fontSize = 12.sp) }
        }
    }
}
