package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.engine.learning.Recommendation
import com.neuralnlp.academy.engine.learning.UnlockPolicy
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.Pill
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn

/** Judul layar dengan pintasan ke Playground dan Pengaturan. */
@Composable
fun ScreenHeader(title: String, nav: NavController) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(title, color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(onClick = { nav.navigate("playground") }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) { Text("</>", fontSize = 13.sp) }
            OutlinedButton(onClick = { nav.navigate("settings") }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) { Text("Pengaturan", fontSize = 12.sp) }
        }
    }
}

@Composable
fun HomeScreen(vm: AcademyViewModel, nav: NavController) {
    val records by vm.records.collectAsState()
    val mastery by vm.mastery.collectAsState()
    val attempts by vm.attempts.collectAsState()
    val streak by vm.streak.collectAsState()
    val rec by vm.recommendation.collectAsState()
    val all = vm.curriculum.all().toList()
    val authored = all.filter { it.authored }
    val passed = authored.count { UnlockPolicy.isPassed(records, it.id) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Neural & NLP Academy", nav)
        Panel(title = "Progres keseluruhan") {
            Text("$passed dari ${authored.size} pelajaran tersedia sudah lulus", color = TextHi, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Bar(if (authored.isEmpty()) 0f else passed / authored.size.toFloat(), color = Good)
            Spacer(Modifier.height(6.dp))
            Text("Kurikulum penuh: ${all.size} pelajaran. ${authored.size} sudah ditulis lengkap; sisanya muncul sebagai \"Segera hadir\" dan belum bisa dibuka.", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("Runtun $streak hari", if (streak > 0) Warn else TextLo); Pill("${attempts.size} asesmen", Electric) }
        }
        for ((track, name) in listOf("nn" to "Neural Network", "nlp" to "NLP")) {
            val lessons = vm.curriculum.track(track)
            val av = lessons.filter { it.authored }
            val ps = av.count { UnlockPolicy.isPassed(records, it.id) }
            val tested = lessons.flatMap { it.concepts }.filter { mastery.get(it) != null }
            val avg = if (tested.isEmpty()) 0.0 else mastery.average(tested)
            val last = lessons.lastOrNull { UnlockPolicy.isPassed(records, it.id) }
            Panel(title = name) {
                Text("$ps / ${av.size} lulus (dari ${lessons.size} pelajaran)", color = TextHi, fontSize = 14.sp)
                Bar(if (av.isEmpty()) 0f else ps / av.size.toFloat())
                Spacer(Modifier.height(4.dp))
                val lastTitle = last?.title
                Text("Tahap saat ini: " + (if (lastTitle != null) "terakhir lulus \"$lastTitle\"" else "belum mulai"), color = TextLo, fontSize = 12.sp)
                Text("Penguasaan konsep teruji: ${if (tested.isEmpty()) "-" else pct(avg)}", color = TextLo, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { nav.navigate(track) }) { Text("Buka kurikulum $name") }
            }
        }
        RecommendationCard(rec, vm) { id -> nav.navigate("lesson/$id") }
        Panel(title = "Skor asesmen terbaru") {
            if (attempts.isEmpty()) Text("Belum ada asesmen. Mulai pelajaran pertama.", color = TextLo, fontSize = 13.sp)
            for (a in attempts.take(5)) {
                val t = vm.curriculum.get(a.lessonId)?.title ?: a.lessonId
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(t, color = TextHi, fontSize = 13.sp); Text(pct(a.score) + if (a.passed) " ✓" else " ✗", color = if (a.passed) Good else Bad, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun RecommendationCard(rec: Recommendation?, vm: AcademyViewModel, open: (String) -> Unit) {
    Panel(title = "Rekomendasi berikutnya") {
        if (rec == null) { Text("Semua pelajaran yang tersedia sudah lulus dan masih segar di ingatan. Pelajaran baru akan ditambahkan di versi berikutnya.", color = TextLo, fontSize = 13.sp); return@Panel }
        val title = vm.curriculum.get(rec.lessonId)?.title ?: rec.lessonId
        Text(title, color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(rec.reason, color = TextLo, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { open(rec.lessonId) }) { Text(when (rec.type) { Recommendation.Type.REMEDIATE -> "Perkuat sekarang"; Recommendation.Type.REVIEW -> "Ulangi"; else -> "Mulai belajar" }) }
    }
}
