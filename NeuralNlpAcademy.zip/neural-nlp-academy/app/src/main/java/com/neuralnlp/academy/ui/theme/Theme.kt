package com.neuralnlp.academy.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Midnight = Color(0xFF0B1224)
val Surface1 = Color(0xFF121C36)
val Surface2 = Color(0xFF1A2748)
val Electric = Color(0xFF2D9CFF)
val ElectricDim = Color(0xFF1B5FA8)
val TextHi = Color(0xFFE6EDF7)
val TextLo = Color(0xFF93A4C3)
val Good = Color(0xFF3DDC97)
val Warn = Color(0xFFFFB74D)
val Bad = Color(0xFFFF6B6B)

private val Scheme = darkColorScheme(
    primary = Electric, onPrimary = Color.White, secondary = Color(0xFF6FB8FF), onSecondary = Color.Black,
    background = Midnight, onBackground = TextHi, surface = Surface1, onSurface = TextHi,
    surfaceVariant = Surface2, onSurfaceVariant = TextLo, error = Bad,
)

/** Tema gelap biru tengah malam dengan aksen biru listrik. */
@Composable
fun AcademyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}
