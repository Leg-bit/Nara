package com.neuralnlp.academy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.neuralnlp.academy.ui.AcademyNav
import com.neuralnlp.academy.ui.theme.AcademyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as AcademyApp).container
        setContent {
            AcademyTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AcademyNav(container) }
            }
        }
    }
}
