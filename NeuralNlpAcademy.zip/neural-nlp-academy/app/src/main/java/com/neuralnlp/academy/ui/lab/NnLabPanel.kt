package com.neuralnlp.academy.ui.lab

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuralnlp.academy.engine.lab.NnLab
import com.neuralnlp.academy.engine.lab.NnLabConfig
import com.neuralnlp.academy.engine.lab.NnLabResult
import com.neuralnlp.academy.engine.nn.Activation
import com.neuralnlp.academy.engine.nn.Network
import com.neuralnlp.academy.engine.nn.OptimizerType
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.Chips
import com.neuralnlp.academy.ui.components.Heatmap
import com.neuralnlp.academy.ui.components.LabeledSlider
import com.neuralnlp.academy.ui.components.LineChart
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.f3
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.Surface2
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun describe(c: NnLabConfig): String =
    "${c.dataset} • lapisan [2${c.hidden.joinToString("") { ",$it" }},1] • ${c.activation.name} • lr ${c.learningRate} • ${c.optimizer.name} • ${c.epochs} epoch"

/**
 * Laboratorium jaringan saraf: atur arsitektur, jalankan pelatihan sungguhan (engine), lihat loss, batas keputusan, dan bobot.
 * [submit] != null menampilkan tombol untuk mengirim akurasi uji ke asesmen eksperimen.
 */
@Composable
fun NnLabPanel(initial: NnLabConfig, batterySaver: Boolean, onRun: (NnLabConfig, NnLabResult) -> Unit, submit: ((Double) -> Unit)? = null) {
    val maxEpochs = if (batterySaver) 150 else 500
    var dataset by remember { mutableStateOf(initial.dataset) }
    var hiddenLayers by remember { mutableStateOf(initial.hidden.size) }
    var neurons by remember { mutableStateOf((initial.hidden.firstOrNull() ?: 8).toFloat()) }
    var act by remember { mutableStateOf(initial.activation) }
    var lr by remember { mutableStateOf(initial.learningRate) }
    var opt by remember { mutableStateOf(initial.optimizer) }
    var epochs by remember { mutableStateOf(initial.epochs.coerceAtMost(maxEpochs).toFloat()) }
    var result by remember { mutableStateOf<NnLabResult?>(null) }
    var usedConfig by remember { mutableStateOf<NnLabConfig?>(null) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    fun currentConfig(): NnLabConfig {
        val c = NnLabConfig()
        c.dataset = dataset; c.hidden = IntArray(hiddenLayers) { neurons.toInt() }; c.activation = act
        c.learningRate = lr; c.optimizer = opt; c.epochs = epochs.toInt(); c.batchSize = if (batterySaver) 32 else 16
        return c
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dataset", color = TextLo, fontSize = 13.sp)
        Chips(listOf("xor", "and", "blobs", "circles", "moons"), dataset, { it }) { dataset = it }
        Text("Lapisan tersembunyi", color = TextLo, fontSize = 13.sp)
        Chips(listOf(0, 1, 2, 3), hiddenLayers, { it.toString() }) { hiddenLayers = it }
        if (hiddenLayers > 0) LabeledSlider("Neuron per lapisan", neurons, 1f..16f, neurons.toInt().toString()) { neurons = it }
        Text("Fungsi aktivasi", color = TextLo, fontSize = 13.sp)
        Chips(listOf(Activation.TANH, Activation.SIGMOID, Activation.RELU, Activation.LEAKY_RELU), act, { it.name }) { act = it }
        Text("Laju belajar", color = TextLo, fontSize = 13.sp)
        Chips(listOf(0.001, 0.01, 0.03, 0.1, 0.3), lr, { it.toString() }) { lr = it }
        Text("Optimizer", color = TextLo, fontSize = 13.sp)
        Chips(OptimizerType.values().toList(), opt, { it.name }) { opt = it }
        LabeledSlider("Epoch (maks $maxEpochs${if (batterySaver) ", hemat baterai" else ""})", epochs, 20f..maxEpochs.toFloat(), epochs.toInt().toString()) { epochs = it }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = !running, onClick = {
                val cfg = currentConfig(); running = true; progress = 0f
                job = scope.launch {
                    val res = withContext(Dispatchers.Default) {
                        NnLab.run(cfg, Network.EpochListener { e, _, _ -> if (e % 5 == 0) progress = e / cfg.epochs.toFloat(); isActive })
                    }
                    result = res; usedConfig = cfg; running = false; progress = 1f
                    onRun(cfg, res)
                }
            }) { Text(if (running) "Berlatih…" else "Latih jaringan") }
            if (running) OutlinedButton(onClick = { job?.cancel() }) { Text("Hentikan") }
        }
        if (running) Bar(progress)

        val r = result
        if (r != null) {
            val cfg = usedConfig ?: currentConfig()
            Panel(title = "Hasil") {
                Text(describe(cfg), color = TextLo, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Text("Akurasi latih ${pct(r.trainAccuracy)} • akurasi uji ${pct(r.testAccuracy)}${if (NnLab.isTiny(cfg.dataset)) " (dataset 4 titik: uji = latih)" else ""}", color = if (r.testAccuracy >= 0.9) Good else Warn, fontSize = 14.sp)
                Text("Loss latih ${f3(r.trainLoss)} • loss uji ${f3(r.testLoss)} • ${r.network.parameterCount()} parameter${if (r.history.diverged) " • DIVERGEN (loss meledak, turunkan laju belajar)" else ""}", color = TextLo, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Loss per epoch (biru) dan akurasi (hijau)", color = TextLo, fontSize = 12.sp)
                LineChart(listOf(r.history.loss.map { it.toFloat() }, r.history.accuracy.map { it.toFloat() }), listOf(Electric, Good))
                Spacer(Modifier.height(8.dp))
                Text("Batas keputusan (latar) dan data latih", color = TextLo, fontSize = 12.sp)
                BoundaryView(r, batterySaver)
                Spacer(Modifier.height(8.dp))
                for (l in 0 until r.network.layers()) {
                    Text("Bobot lapisan ${l + 1} (baris = neuron keluaran), bias: ${r.network.biases(l).joinToString(" ") { f3(it) }}", color = TextLo, fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState())) { Heatmap(r.network.weights(l)) }
                    Spacer(Modifier.height(6.dp))
                }
                if (submit != null) Button(onClick = { submit(r.testAccuracy) }) { Text("Kirim akurasi uji ke asesmen") }
            }
        }
    }
}

@Composable
private fun BoundaryView(r: NnLabResult, saver: Boolean) {
    val n = if (saver) 20 else 36
    Canvas(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)) {
        var x0 = Double.MAX_VALUE; var x1 = -Double.MAX_VALUE; var y0 = Double.MAX_VALUE; var y1 = -Double.MAX_VALUE
        for (p in r.train.x) { x0 = minOf(x0, p[0]); x1 = maxOf(x1, p[0]); y0 = minOf(y0, p[1]); y1 = maxOf(y1, p[1]) }
        val mx = (x1 - x0) * 0.15 + 0.1; val my = (y1 - y0) * 0.15 + 0.1
        x0 -= mx; x1 += mx; y0 -= my; y1 += my
        val cw = size.width / n; val ch = size.height / n
        for (i in 0 until n) for (j in 0 until n) {
            val x = x0 + (x1 - x0) * (i + 0.5) / n; val y = y1 - (y1 - y0) * (j + 0.5) / n
            val p = r.network.predict(doubleArrayOf(x, y))[0].toFloat()
            drawRect((if (p >= 0.5f) Electric else Bad).copy(alpha = 0.10f + 0.40f * kotlin.math.abs(p - 0.5f) * 2f), Offset(i * cw, j * ch), Size(cw + 1f, ch + 1f))
        }
        for (k in r.train.x.indices) {
            val px = ((r.train.x[k][0] - x0) / (x1 - x0) * size.width).toFloat()
            val py = (size.height - (r.train.x[k][1] - y0) / (y1 - y0) * size.height).toFloat()
            drawCircle(Color.White, 6f, Offset(px, py))
            drawCircle(if (r.train.y[k] > 0.5) Electric else Bad, 4.5f, Offset(px, py))
        }
    }
}
