package com.neuralnlp.academy.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle

private val KEYWORDS = setOf("import", "from", "as", "def", "return", "if", "else", "elif", "for", "while", "in", "and", "or", "not", "lambda", "print", "class", "True", "False", "None")
private val BUILTINS = setOf("round", "len", "sorted", "set", "range", "sum", "max", "min", "abs", "np", "Counter")
private val TOKEN = Regex("(#[^\\n]*)|(\"[^\"\\n]*\"|'[^'\\n]*')|(\\b\\d+(?:\\.\\d+)?(?:e-?\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)")

private val CMT = Color(0xFF6B7FA3)
private val STR = Color(0xFF8BE9A8)
private val NUM = Color(0xFFFFC27A)
private val KEY = Color(0xFF7CB7FF)
private val BLT = Color(0xFFC3A6FF)

/** Pewarnaan sintaks Python sederhana (komentar, string, angka, kata kunci). Panjang teks tidak berubah. */
fun highlightPython(code: String): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in TOKEN.findAll(code)) {
        append(code.substring(last, m.range.first))
        val t = m.value
        val color: Color? = when {
            m.groups[1] != null -> CMT
            m.groups[2] != null -> STR
            m.groups[3] != null -> NUM
            t in KEYWORDS -> KEY
            t in BUILTINS -> BLT
            else -> null
        }
        if (color != null) withStyle(SpanStyle(color = color)) { append(t) } else append(t)
        last = m.range.last + 1
    }
    append(code.substring(last))
}
