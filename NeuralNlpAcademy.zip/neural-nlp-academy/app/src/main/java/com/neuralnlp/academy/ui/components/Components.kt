package com.neuralnlp.academy.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuralnlp.academy.ui.theme.Electric
import com.neuralnlp.academy.ui.theme.Surface1
import com.neuralnlp.academy.ui.theme.Surface2
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import java.util.Locale

fun f2(x: Double): String = String.format(Locale.US, "%.2f", x)
fun f3(x: Double): String = String.format(Locale.US, "%.3f", x)
fun pct(x: Double): String = String.format(Locale.US, "%.0f%%", x * 100)

/** Kartu konten dengan judul opsional. */
@Composable
fun Panel(modifier: Modifier = Modifier, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface1).padding(14.dp)) {
        if (title != null) { Text(title, color = Electric, fontWeight = FontWeight.SemiBold, fontSize = 15.sp); Spacer(Modifier.height(8.dp)) }
        content()
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Text(text, color = color, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 3.dp))
}

@Composable
fun Bar(value: Float, modifier: Modifier = Modifier, color: Color = Electric, height: Dp = 8.dp) {
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(Surface2)) {
        Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).height(height).clip(RoundedCornerShape(50)).background(color))
    }
}

/** Pilihan satu-dari-banyak berbentuk chip yang bisa digulir. */
@Composable
fun <T> Chips(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (o in options) {
            val on = o == selected
            Text(label(o), color = if (on) Color.White else TextLo, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Electric else Surface2).clickable { onSelect(o) }.padding(horizontal = 14.dp, vertical = 7.dp))
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextLo, fontSize = 13.sp); Text(valueText, color = TextHi, fontSize = 13.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** Grafik garis sederhana (beberapa seri) dengan skala otomatis. */
@Composable
fun LineChart(series: List<List<Float>>, colors: List<Color>, modifier: Modifier = Modifier, yMin: Float? = null, yMax: Float? = null) {
    Canvas(modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)) {
        val all = series.flatten()
        if (all.isEmpty()) return@Canvas
        val lo = yMin ?: all.min(); var hi = yMax ?: all.max()
        if (hi - lo < 1e-9f) hi = lo + 1f
        for (g in 1..3) { val y = size.height * g / 4f; drawLine(Color(0x22FFFFFF), Offset(0f, y), Offset(size.width, y), 1f) }
        for ((si, s) in series.withIndex()) {
            if (s.size < 2) continue
            val p = Path()
            for (i in s.indices) {
                val x = size.width * i / (s.size - 1).toFloat()
                val y = size.height - (s[i] - lo) / (hi - lo) * (size.height - 8f) - 4f
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, colors[si % colors.size], style = Stroke(width = 3f))
        }
    }
}

/** Peta panas matriks bobot: biru = positif, merah = negatif, makin pekat makin besar. */
@Composable
fun Heatmap(m: Array<DoubleArray>, modifier: Modifier = Modifier, cell: Dp = 22.dp) {
    val rows = m.size; val cols = if (rows == 0) 0 else m[0].size
    var mx = 1e-9
    for (r in m) for (v in r) mx = maxOf(mx, kotlin.math.abs(v))
    Canvas(modifier.width(cell * cols).height(cell * rows)) {
        val cs = cell.toPx()
        for (r in 0 until rows) for (c in 0 until cols) {
            val v = m[r][c]; val a = (kotlin.math.abs(v) / mx).toFloat().coerceIn(0f, 1f) * 0.9f + 0.1f
            drawRect(if (v >= 0) Color(0xFF2D9CFF).copy(alpha = a) else Color(0xFFFF6B6B).copy(alpha = a), Offset(c * cs, r * cs), Size(cs - 2f, cs - 2f))
        }
    }
}

@Composable
fun CodeBlock(code: String, modifier: Modifier = Modifier) {
    Text(highlightPython(code), color = TextHi, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp,
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF0A1020)).horizontalScroll(rememberScrollState()).padding(12.dp))
}
