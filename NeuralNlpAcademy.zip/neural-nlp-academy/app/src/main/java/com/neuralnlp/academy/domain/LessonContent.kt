package com.neuralnlp.academy.domain

import com.neuralnlp.academy.engine.assessment.Question
import com.neuralnlp.academy.engine.lab.NnLabConfig

data class Viz(val type: String, val title: String)

data class Impl(val language: String, val code: String, val expected: String, val steps: List<String>)

/** kind: "nn" | "nlp" | "none". nnPreset hanya untuk "nn"; nlpTab hanya untuk "nlp". */
data class ExperimentSpec(val kind: String, val instruction: String, val nnPreset: NnLabConfig?, val nlpTab: String?)

data class LessonContent(
    val id: String,
    val title: String,
    val track: String,
    val concept: String,
    val explanation: List<String>,
    val math: List<String>,
    val viz: Viz,
    val impl: Impl,
    val experiment: ExperimentSpec,
    val exercises: List<String>,
    val questions: List<Question>,
)
