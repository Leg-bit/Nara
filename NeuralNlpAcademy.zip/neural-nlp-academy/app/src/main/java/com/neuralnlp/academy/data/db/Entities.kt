package com.neuralnlp.academy.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Hasil asesmen terbaik per pelajaran. Lulus ditentukan skor (>= 0,7), bukan klik. */
@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val attempts: Int,
    val bestScore: Double,
    val lastScore: Double,
    val lastAttemptAt: Long,
)

/** Penguasaan per konsep (model Elo-like di engine) beserta bukti dan hari terakhir diuji. */
@Entity(tableName = "concept_mastery")
data class ConceptMasteryEntity(
    @PrimaryKey val conceptId: String,
    val value: Double,
    val evidence: Int,
    val lastDay: Long,
)

@Entity(tableName = "assessment_attempt", indices = [Index("lessonId")])
data class AssessmentAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lessonId: String,
    val score: Double,
    val passed: Boolean,
    val createdAt: Long,
    val detail: String,
)

/** Riwayat eksperimen laboratorium (konfigurasi dan hasil sebagai teks ringkas). */
@Entity(tableName = "experiment_run")
data class ExperimentRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val config: String,
    val result: String,
    val createdAt: Long,
)

/** Aktivitas harian untuk runtun belajar. day = epoch day. */
@Entity(tableName = "daily_activity")
data class DailyActivityEntity(
    @PrimaryKey val day: Long,
    val questions: Int,
    val lessons: Int,
)
