package com.neuralnlp.academy.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM lesson_progress") fun lessonProgress(): Flow<List<LessonProgressEntity>>
    @Query("SELECT * FROM lesson_progress WHERE lessonId = :id") suspend fun getLesson(id: String): LessonProgressEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLesson(e: LessonProgressEntity)

    @Query("SELECT * FROM concept_mastery") fun mastery(): Flow<List<ConceptMasteryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMastery(list: List<ConceptMasteryEntity>)

    @Insert suspend fun insertAttempt(a: AssessmentAttemptEntity)
    @Query("SELECT * FROM assessment_attempt ORDER BY createdAt DESC LIMIT 50") fun attempts(): Flow<List<AssessmentAttemptEntity>>

    @Insert suspend fun insertExperiment(e: ExperimentRunEntity)
    @Query("SELECT * FROM experiment_run ORDER BY createdAt DESC LIMIT 50") fun experiments(): Flow<List<ExperimentRunEntity>>

    @Query("SELECT * FROM daily_activity WHERE day = :day") suspend fun getDay(day: Long): DailyActivityEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDay(e: DailyActivityEntity)
    @Query("SELECT * FROM daily_activity ORDER BY day DESC LIMIT 400") fun activity(): Flow<List<DailyActivityEntity>>

    @Query("DELETE FROM lesson_progress") suspend fun clearLessons()
    @Query("DELETE FROM concept_mastery") suspend fun clearMastery()
    @Query("DELETE FROM assessment_attempt") suspend fun clearAttempts()
    @Query("DELETE FROM experiment_run") suspend fun clearExperiments()
    @Query("DELETE FROM daily_activity") suspend fun clearActivity()
}
