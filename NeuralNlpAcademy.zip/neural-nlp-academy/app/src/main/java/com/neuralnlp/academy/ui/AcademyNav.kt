package com.neuralnlp.academy.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.AppContainer
import com.neuralnlp.academy.ui.screens.HomeScreen
import com.neuralnlp.academy.ui.screens.LabsScreen
import com.neuralnlp.academy.ui.screens.LessonScreen
import com.neuralnlp.academy.ui.screens.PlaygroundScreen
import com.neuralnlp.academy.ui.screens.ProgressScreen
import com.neuralnlp.academy.ui.screens.SettingsScreen
import com.neuralnlp.academy.ui.screens.TrackScreen
import com.neuralnlp.academy.ui.theme.Surface1

private data class Dest(val route: String, val label: String, val symbol: String)

private val TABS = listOf(Dest("home", "Beranda", "⌂"), Dest("nn", "Neural Net", "◉"), Dest("nlp", "NLP", "✎"), Dest("labs", "Lab", "⚗"), Dest("progress", "Progres", "▤"))

/** Navigasi: Beranda, Neural Network, NLP, Laboratorium, Progres di bar bawah; Playground dan Pengaturan dari pintasan di judul layar. */
@Composable
fun AcademyNav(container: AppContainer) {
    val vm: AcademyViewModel = viewModel(factory = viewModelFactory { initializer { AcademyViewModel(container) } })
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    Scaffold(bottomBar = {
        if (route != null && !route.startsWith("lesson")) NavigationBar(containerColor = Surface1) {
            for (t in TABS) NavigationBarItem(selected = route == t.route, label = { Text(t.label) }, icon = { Text(t.symbol) },
                onClick = { nav.navigate(t.route) { popUpTo("home"); launchSingleTop = true } })
        }
    }) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(vm, nav) }
            composable("nn") { TrackScreen("nn", vm, nav) }
            composable("nlp") { TrackScreen("nlp", vm, nav) }
            composable("labs") { LabsScreen(vm, nav) }
            composable("progress") { ProgressScreen(vm, nav) }
            composable("playground") { PlaygroundScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm, nav) }
            composable("lesson/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                LessonScreen(container, e.arguments?.getString("id") ?: "", vm, nav)
            }
        }
    }
}
