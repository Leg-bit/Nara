package com.neuralnlp.academy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.neuralnlp.academy.data.AppSettings
import com.neuralnlp.academy.data.db.AssessmentAttemptEntity
import com.neuralnlp.academy.data.db.ExperimentRunEntity
import com.neuralnlp.academy.domain.LessonContent
import com.neuralnlp.academy.engine.learning.Curriculum
import com.neuralnlp.academy.engine.learning.LessonRecord
import com.neuralnlp.academy.engine.learning.MasteryModel
import com.neuralnlp.academy.engine.learning.Recommendation
import com.neuralnlp.academy.engine.learning.Recommender
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Status global aplikasi: progres, penguasaan, rekomendasi, riwayat, pengaturan. */
class AcademyViewModel(private val c: AppContainer) : ViewModel() {
    val curriculum: Curriculum = c.curriculum.curriculum

    val records: StateFlow<Map<String, LessonRecord>> = c.progress.records.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
    val mastery: StateFlow<MasteryModel> = c.progress.mastery.stateIn(viewModelScope, SharingStarted.Eagerly, MasteryModel())
    val attempts: StateFlow<List<AssessmentAttemptEntity>> = c.progress.attempts.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val experiments: StateFlow<List<ExperimentRunEntity>> = c.progress.experiments.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val streak: StateFlow<Int> = c.progress.streak.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val settings: StateFlow<AppSettings> = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings(false))

    val recommendation: StateFlow<Recommendation?> = combine(records, mastery) { r, m -> Recommender.next(curriculum, r, m, todayEpochDay()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun lessonContent(id: String): LessonContent? = c.curriculum.lesson(id)
    fun authoredContents(): List<LessonContent> = c.curriculum.authoredContents()

    fun recordExperiment(kind: String, config: String, result: String) { viewModelScope.launch { c.progress.recordExperiment(kind, config, result) } }
    fun setBatterySaver(v: Boolean) { viewModelScope.launch { c.settings.setBatterySaver(v) } }
    fun resetAll() { viewModelScope.launch { c.progress.resetAll() } }
}
