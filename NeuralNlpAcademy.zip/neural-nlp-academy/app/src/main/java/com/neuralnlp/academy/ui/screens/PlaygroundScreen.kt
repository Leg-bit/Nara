package com.neuralnlp.academy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.neuralnlp.academy.AcademyViewModel
import com.neuralnlp.academy.engine.assessment.Answer
import com.neuralnlp.academy.engine.assessment.AssessmentEngine
import com.neuralnlp.academy.engine.assessment.QuestionType
import com.neuralnlp.academy.ui.components.CodeBlock
import com.neuralnlp.academy.ui.components.Chips
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.highlightPython
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.theme.Warn

private val HighlightTransformation = object : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText = TransformedText(highlightPython(text.text), OffsetMapping.Identity)
}

/**
 * Playground kode: penampil dengan pewarnaan sintaks, kode yang bisa diedit, perbandingan dengan aslinya, keluaran yang diharapkan,
 * dan tantangan keluaran. Python TIDAK dieksekusi di aplikasi; keluaran yang diharapkan berasal dari eksekusi nyata saat kurikulum dibangun.
 */
@Composable
fun PlaygroundScreen(vm: AcademyViewModel, nav: NavController) {
    val contents = remember { vm.authoredContents() }
    var selectedId by remember { mutableStateOf(contents.firstOrNull()?.id ?: "") }
    val sel = contents.firstOrNull { it.id == selectedId }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Code Playground", nav)
        Panel {
            Text("Eksekusi Python belum tersedia di versi ini. Kode di sini adalah demonstrasi yang bisa diedit dan dibandingkan; keluaran yang diharapkan sudah dijalankan sungguhan di PC saat kurikulum dibangun. Eksperimen yang benar-benar berjalan di HP ada di tab Laboratorium.", color = Warn, fontSize = 12.sp)
        }
        if (sel == null) { Text("Belum ada contoh kode.", color = TextLo); return@Column }
        Chips(contents.map { it.id }, selectedId, { id -> contents.first { it.id == id }.title }) { selectedId = it }
        var code by remember(selectedId) { mutableStateOf(sel.impl.code) }
        Panel(title = "Kode (bisa diedit)") {
            OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth(), visualTransformation = HighlightTransformation,
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextHi), minLines = 6)
            Spacer(Modifier.height(6.dp))
            Button(onClick = { code = sel.impl.code }) { Text("Kembalikan ke asli") }
        }
        Panel(title = "Perbandingan dengan kode asli") {
            val a = sel.impl.code.lines(); val b = code.lines(); var changed = 0
            for (i in 0 until maxOf(a.size, b.size)) {
                val x = a.getOrNull(i); val y = b.getOrNull(i)
                if (x != y) { changed++; if (x != null) Text("- $x", color = Bad, fontSize = 12.sp, fontFamily = FontFamily.Monospace); if (y != null) Text("+ $y", color = Good, fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
            }
            if (changed == 0) Text("Tidak ada perubahan.", color = TextLo, fontSize = 13.sp)
        }
        Panel(title = "Penjelasan langkah demi langkah") { sel.impl.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", color = TextHi, fontSize = 13.sp) } }
        Panel(title = "Keluaran yang diharapkan (kode asli)") { CodeBlock(sel.impl.expected) }
        for (q in sel.questions.filter { it.type == QuestionType.CODE_OUTPUT }) {
            var ans by remember(q.id) { mutableStateOf("") }
            var fb by remember(q.id) { mutableStateOf<String?>(null) }
            Panel(title = "Tantangan (latihan, tidak memengaruhi nilai)") {
                Text(q.prompt, color = TextHi, fontSize = 14.sp)
                OutlinedTextField(ans, { ans = it }, Modifier.fillMaxWidth(), label = { Text("Keluaran menurutmu") }, minLines = 2, textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextHi))
                Spacer(Modifier.height(6.dp))
                Button(enabled = ans.isNotBlank(), onClick = { val g = AssessmentEngine.grade(q, Answer.text(ans)); fb = (if (g.correct()) "Benar. " else "${pct(g.score)}. ") + g.feedback }) { Text("Periksa") }
                fb?.let { Text(it, color = TextLo, fontSize = 13.sp) }
            }
        }
    }
}
