package com.neuralnlp.academy.data

import androidx.room.withTransaction
import com.neuralnlp.academy.data.db.AcademyDatabase
import com.neuralnlp.academy.data.db.AssessmentAttemptEntity
import com.neuralnlp.academy.data.db.ConceptMasteryEntity
import com.neuralnlp.academy.data.db.DailyActivityEntity
import com.neuralnlp.academy.data.db.ExperimentRunEntity
import com.neuralnlp.academy.data.db.LessonProgressEntity
import com.neuralnlp.academy.engine.assessment.ExamResult
import com.neuralnlp.academy.engine.learning.LessonRecord
import com.neuralnlp.academy.engine.learning.MasteryModel
import com.neuralnlp.academy.engine.learning.Streak
import com.neuralnlp.academy.todayEpochDay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

/** Seluruh penyimpanan progres lokal (Room). Model engine dibangun ulang dari baris database sehingga UI selalu menerima salinan baru. */
class ProgressRepository(private val db: AcademyDatabase) {
    private val dao = db.progressDao()

    val records: Flow<Map<String, LessonRecord>> = dao.lessonProgress().map { rows -> rows.associate { it.lessonId to LessonRecord(it.lessonId, it.attempts, it.bestScore) } }

    val mastery: Flow<MasteryModel> = dao.mastery().map { rows ->
        val m = MasteryModel()
        for (r in rows) m.put(r.conceptId, MasteryModel.Mastery(r.value, r.evidence, r.lastDay))
        m
    }

    val attempts: Flow<List<AssessmentAttemptEntity>> = dao.attempts()
    val experiments: Flow<List<ExperimentRunEntity>> = dao.experiments()
    val streak: Flow<Int> = dao.activity().map { rows -> Streak.compute(rows.map { it.day }, todayEpochDay()) }

    /** Simpan hasil satu asesmen: skor pelajaran, penguasaan konsep, riwayat, dan aktivitas harian (satu transaksi). */
    suspend fun recordAssessment(lessonId: String, result: ExamResult, mastery: MasteryModel, answered: Int, today: Long) {
        db.withTransaction {
            val prev = dao.getLesson(lessonId)
            val now = System.currentTimeMillis()
            dao.upsertLesson(LessonProgressEntity(lessonId, (prev?.attempts ?: 0) + 1, maxOf(prev?.bestScore ?: 0.0, result.score), result.score, now))
            val rows = result.conceptScores.keys.mapNotNull { c -> mastery.get(c)?.let { ConceptMasteryEntity(c, it.value, it.evidence, it.lastDay) } }
            dao.upsertMastery(rows)
            dao.insertAttempt(AssessmentAttemptEntity(lessonId = lessonId, score = result.score, passed = result.passed(), createdAt = now, detail = JSONObject(result.conceptScores as Map<*, *>).toString()))
            val day = dao.getDay(today)
            dao.upsertDay(DailyActivityEntity(today, (day?.questions ?: 0) + answered, (day?.lessons ?: 0) + 1))
        }
    }

    suspend fun recordExperiment(kind: String, config: String, result: String) {
        dao.insertExperiment(ExperimentRunEntity(kind = kind, config = config, result = result, createdAt = System.currentTimeMillis()))
        val today = todayEpochDay()
        val day = dao.getDay(today)
        dao.upsertDay(DailyActivityEntity(today, day?.questions ?: 0, day?.lessons ?: 0))   // eksperimen juga menjaga runtun belajar
    }

    suspend fun resetAll() {
        db.withTransaction { dao.clearLessons(); dao.clearMastery(); dao.clearAttempts(); dao.clearExperiments(); dao.clearActivity() }
    }
}
