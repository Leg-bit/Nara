package com.neuralnlp.academy.ui.lab

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuralnlp.academy.engine.lab.NlpLab
import com.neuralnlp.academy.ui.components.Bar
import com.neuralnlp.academy.ui.components.Chips
import com.neuralnlp.academy.ui.components.Panel
import com.neuralnlp.academy.ui.components.f3
import com.neuralnlp.academy.ui.components.pct
import com.neuralnlp.academy.ui.theme.Bad
import com.neuralnlp.academy.ui.theme.Good
import com.neuralnlp.academy.ui.theme.Midnight
import com.neuralnlp.academy.ui.theme.Surface1
import com.neuralnlp.academy.ui.theme.TextHi
import com.neuralnlp.academy.ui.theme.TextLo
import com.neuralnlp.academy.ui.viz.LessonViz

private val TABS = listOf("tokenize" to "Tokenisasi", "normalize" to "Normalisasi", "tfidf" to "TF-IDF", "classify" to "Klasifikasi", "langid" to "Bahasa")

/** Laboratorium NLP: semua hasil dihitung engine lokal pada dataset kecil bawaan. */
@Composable
fun NlpLabPanel(initialTab: String? = null) {
    var tab by remember { mutableStateOf(TABS.indexOfFirst { it.first == initialTab }.coerceAtLeast(0)) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TabRow(selectedTabIndex = tab, containerColor = Surface1) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t.second, fontSize = 11.sp) }) }
        }
        when (TABS[tab].first) {
            "tokenize" -> Panel(title = "Bandingkan tokenisasi") { LessonViz("tokenization") }
            "normalize" -> Panel(title = "Bandingkan normalisasi") { LessonViz("norm_steps") }
            "tfidf" -> TfIdfTab()
            "classify" -> ClassifyTab()
            else -> Panel(title = "Identifikasi bahasa") { LessonViz("lang_id") }
        }
    }
}

@Composable
private fun TfIdfTab() {
    var lang by remember { mutableStateOf("id") }
    var d1 by remember { mutableStateOf("kucing makan ikan di dapur") }
    var d2 by remember { mutableStateOf("anjing makan tulang di halaman") }
    var d3 by remember { mutableStateOf("kucing tidur di sofa") }
    val top = remember(lang, d1, d2, d3) { NlpLab.tfidfTop(listOf(d1, d2, d3), lang, 3) }
    Panel(title = "TF-IDF: kata paling khas tiap dokumen") {
        Chips(listOf("id", "en"), lang, { if (it == "id") "Indonesia" else "Inggris" }) { lang = it }
        OutlinedTextField(d1, { d1 = it }, Modifier.fillMaxWidth(), label = { Text("Dokumen 1") })
        OutlinedTextField(d2, { d2 = it }, Modifier.fillMaxWidth(), label = { Text("Dokumen 2") })
        OutlinedTextField(d3, { d3 = it }, Modifier.fillMaxWidth(), label = { Text("Dokumen 3") })
        top.forEachIndexed { i, l -> Text("Dok ${i + 1}: " + l.joinToString("   ") { "${it.key} (${f3(it.value)})" }, color = TextHi, fontSize = 13.sp) }
        val bow = remember(lang, d1, d2, d3) { NlpLab.bagOfWords(listOf(d1, d2, d3), lang) }
        Text("Bag of Words — kosakata (${bow.vocabulary.size}): ${bow.vocabulary.joinToString(" ")}", color = TextLo, fontSize = 12.sp)
        bow.vectors.forEachIndexed { i, v -> Text("Dok ${i + 1}: [${v.joinToString(" ")}]", color = TextLo, fontSize = 12.sp) }
        Text("Kata yang muncul di banyak dokumen (mis. \"makan\", \"di\") bobotnya rendah; kata yang khas satu dokumen bobotnya tinggi. Stopword dibuang sebelum dihitung.", color = TextLo, fontSize = 12.sp)
    }
}

@Composable
private fun ClassifyTab() {
    var lang by remember { mutableStateOf("id") }
    var text by remember { mutableStateOf("pelayanannya ramah dan makanannya enak") }
    val probs = remember(lang, text) { NlpLab.classify(text, lang) }
    val acc = remember(lang) { NlpLab.heldOutAccuracy(lang) }
    Panel(title = "Klasifikasi sentimen (Naive Bayes)") {
        Chips(listOf("id", "en"), lang, { if (it == "id") "Indonesia" else "Inggris" }) { lang = it }
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Kalimat ulasan") })
        for ((k, v) in probs) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(k, color = TextHi, fontSize = 13.sp, modifier = Modifier.size(width = 64.dp, height = 20.dp))
            Column(Modifier.weight(1f)) { Bar(v.toFloat(), color = if (k == "positif") Good else Bad) }
            Text(pct(v), color = TextLo, fontSize = 13.sp)
        }
        Text("Akurasi pada data yang tidak ikut dilatih: ${pct(acc)} (hanya ${if (lang == "id") "12" else "10"} contoh uji — angka ini kasar). Model dilatih pada ${if (lang == "id") "48" else "40"} kalimat bawaan.", color = TextLo, fontSize = 12.sp)
    }
}
