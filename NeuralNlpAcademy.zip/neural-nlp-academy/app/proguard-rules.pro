# Room dan Compose membawa aturan konsumen sendiri. Kelas engine dipanggil langsung (tanpa refleksi).
-keep class com.neuralnlp.academy.engine.** { *; }
