# Neural & NLP Academy

Aplikasi Android untuk belajar jaringan saraf dan NLP secara interaktif, offline. Lihat `docs/ARCHITECTURE.md` untuk desain dan **status jujur** (apa yang sudah/belum ada dan diuji).

## Membangun

Prasyarat: JDK 17, Android SDK 34 (Android Studio Koala atau lebih baru), Python 3 + NumPy (hanya untuk alat kurikulum).

```bash
# 1. buka folder ini di Android Studio (membuat Gradle wrapper otomatis), atau:
gradle wrapper --gradle-version 8.9
# 2. uji engine dan uji aplikasi
./gradlew :engine:test :app:testDebugUnitTest
# 3. verifikasi kurikulum
pip install numpy && python3 tools/verify_lessons.py && python3 tools/check_schema.py
# 4. APK
./gradlew :app:assembleDebug      # app/build/outputs/apk/debug/
./gradlew :app:assembleRelease    # app/build/outputs/apk/release/ (ditandatangani kunci tetap proyek)
```

CI (`.github/workflows/build.yml`) menjalankan langkah 2–4 dan mengunggah kedua APK. Repo bisa berisi proyek ini langsung di root, atau satu berkas `.zip` berisi proyek.

## Menambah pelajaran

1. Edit `tools/gen_curriculum.py` (tambahkan isi pelajaran dan tandai `authored=True`).
2. `python3 tools/gen_curriculum.py` (menjalankan kode pelajaran untuk keluaran asli) lalu `verify_lessons.py` dan `check_schema.py`.
3. `./gradlew :engine:test` (LessonDataTest memeriksa semua soal terhadap mesin penilai).

Pelajaran yang `authored=False` tampil "Segera hadir" dan tidak bisa dibuka atau direkomendasikan.
